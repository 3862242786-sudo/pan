/************************************************************
 * 青柠OS 桌面环境 v1.0
 * 基于 Linux Framebuffer 的轻量图形界面
 * 无需 X11/Wayland，直接操作显卡帧缓冲
 ************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <linux/fb.h>
#include <linux/input.h>
#include <errno.h>
#include <signal.h>
#include <time.h>

/* 颜色定义 (ARGB8888) */
#define COLOR_BG        0xFF0F172A  /* 深蓝灰背景 */
#define COLOR_BG_LIGHT  0xFF1E293B  /* 浅蓝灰 */
#define COLOR_ACCENT    0xFF22C55E  /* 青柠绿 */
#define COLOR_ACCENT_HL 0xFF4ADE80  /* 亮青柠绿 */
#define COLOR_TEXT      0xFFE2E8F0  /* 主文字 */
#define COLOR_TEXT_DIM  0xFF94A3B8  /* 次要文字 */
#define COLOR_PANEL     0xFF334155  /* 面板 */
#define COLOR_WHITE     0xFFFFFFFF
#define COLOR_BLACK     0xFF000000

/* 桌面元素 */
#define TASKBAR_HEIGHT  40
#define ICON_SIZE       48
#define ICON_MARGIN     16
#define WINDOW_TITLE_H  32
#define WINDOW_BORDER   2
#define DOCK_HEIGHT     64
#define DOCK_ICON_SIZE  40

/* 帧缓冲 */
static int fb_fd = -1;
static unsigned int *fb_mem = NULL;
static struct fb_var_screeninfo vinfo;
static struct fb_fix_screeninfo finfo;
static int screen_width, screen_height;
static int fb_size;

/* 鼠标 */
static int mouse_x = 0, mouse_y = 0;
static int mouse_fd = -1;
static int mouse_visible = 1;

/* 桌面状态 */
static int running = 1;
static int active_window = -1;
static int window_count = 0;

/* 窗口结构 */
#define MAX_WINDOWS 8
#define MAX_TITLE_LEN 64

typedef struct {
    int x, y;
    int width, height;
    int visible;
    int minimized;
    char title[MAX_TITLE_LEN];
    unsigned int *content;  /* 窗口内容缓冲 */
} Window;

static Window windows[MAX_WINDOWS];

/* 图标结构 */
typedef struct {
    int x, y;
    int width, height;
    const char *label;
    unsigned int color;
    void (*onclick)(void);
} Icon;

/* 应用启动回调 */
static void launch_terminal(void);
static void launch_browser(void);
static void launch_filemanager(void);
static void launch_settings(void);
static void launch_info(void);

/* Dock图标 */
static Icon dock_icons[] = {
    {0, 0, DOCK_ICON_SIZE, DOCK_ICON_SIZE, "终端", COLOR_ACCENT, launch_terminal},
    {0, 0, DOCK_ICON_SIZE, DOCK_ICON_SIZE, "浏览器", COLOR_ACCENT_HL, launch_browser},
    {0, 0, DOCK_ICON_SIZE, DOCK_ICON_SIZE, "文件", 0xFF3B82F6, launch_filemanager},
    {0, 0, DOCK_ICON_SIZE, DOCK_ICON_SIZE, "设置", 0xFFA855F7, launch_settings},
    {0, 0, DOCK_ICON_SIZE, DOCK_ICON_SIZE, "关于", 0xFFF97316, launch_info},
};
#define DOCK_ICON_COUNT (sizeof(dock_icons)/sizeof(dock_icons[0]))

/* 桌面图标 */
static Icon desktop_icons[] = {
    {40, 80, ICON_SIZE, ICON_SIZE, "青柠网盘", COLOR_ACCENT, launch_browser},
    {40, 160, ICON_SIZE, ICON_SIZE, "应用商店", COLOR_ACCENT_HL, launch_browser},
    {40, 240, ICON_SIZE, ICON_SIZE, "使用教程", 0xFF3B82F6, launch_browser},
    {40, 320, ICON_SIZE, ICON_SIZE, "系统信息", 0xFFF97316, launch_info},
};
#define DESKTOP_ICON_COUNT (sizeof(desktop_icons)/sizeof(desktop_icons[0]))

/* ============================================================
 * 帧缓冲操作
 * ============================================================ */

int fb_init(void) {
    fb_fd = open("/dev/fb0", O_RDWR);
    if (fb_fd < 0) {
        fb_fd = open("/dev/fb1", O_RDWR);
        if (fb_fd < 0) {
            perror("无法打开帧缓冲设备");
            return -1;
        }
    }

    if (ioctl(fb_fd, FBIOGET_FSCREENINFO, &finfo) < 0) {
        perror("FBIOGET_FSCREENINFO");
        return -1;
    }

    if (ioctl(fb_fd, FBIOGET_VSCREENINFO, &vinfo) < 0) {
        perror("FBIOGET_VSCREENINFO");
        return -1;
    }

    screen_width = vinfo.xres;
    screen_height = vinfo.yres;
    fb_size = finfo.line_length * screen_height;

    fb_mem = (unsigned int *)mmap(NULL, fb_size, PROT_READ | PROT_WRITE, MAP_SHARED, fb_fd, 0);
    if (fb_mem == MAP_FAILED) {
        perror("mmap");
        return -1;
    }

    printf("[青柠OS] 帧缓冲: %dx%d, %dbpp\n", screen_width, screen_height, vinfo.bits_per_pixel);
    return 0;
}

void fb_close(void) {
    if (fb_mem && fb_mem != MAP_FAILED) {
        munmap(fb_mem, fb_size);
    }
    if (fb_fd >= 0) close(fb_fd);
}

/* 绘制像素 */
static inline void draw_pixel(int x, int y, unsigned int color) {
    if (x < 0 || x >= screen_width || y < 0 || y >= screen_height) return;
    fb_mem[y * (finfo.line_length / 4) + x] = color;
}

/* 填充矩形 */
void fill_rect(int x, int y, int w, int h, unsigned int color) {
    int i, j;
    for (j = y; j < y + h && j < screen_height; j++) {
        for (i = x; i < x + w && i < screen_width; i++) {
            if (i >= 0 && j >= 0) draw_pixel(i, j, color);
        }
    }
}

/* 绘制圆角矩形 */
void fill_round_rect(int x, int y, int w, int h, int r, unsigned int color) {
    int i, j;
    for (j = y; j < y + h && j < screen_height; j++) {
        for (i = x; i < x + w && i < screen_width; i++) {
            if (i >= 0 && j >= 0) {
                int dx = (i < x + r) ? (x + r - i) : ((i > x + w - r) ? (i - (x + w - r)) : 0);
                int dy = (j < y + r) ? (y + r - j) : ((j > y + h - r) ? (j - (y + h - r)) : 0);
                if (dx * dx + dy * dy <= r * r || (dx == 0 && dy == 0)) {
                    draw_pixel(i, j, color);
                }
            }
        }
    }
}

/* 绘制边框 */
void draw_rect_border(int x, int y, int w, int h, int border, unsigned int color) {
    fill_rect(x, y, w, border, color);
    fill_rect(x, y + h - border, w, border, color);
    fill_rect(x, y, border, h, color);
    fill_rect(x + w - border, y, border, h, color);
}

/* 绘制简单文字（位图字体） */
void draw_char(int x, int y, char c, unsigned int color, int scale) {
    /* 5x7 位图字体 */
    static const unsigned char font[128][5] = {
        ['A'] = {0x7E, 0x09, 0x09, 0x09, 0x7E},
        ['B'] = {0x7F, 0x49, 0x49, 0x49, 0x36},
        ['C'] = {0x3E, 0x41, 0x41, 0x41, 0x22},
        ['D'] = {0x7F, 0x41, 0x41, 0x22, 0x1C},
        ['E'] = {0x7F, 0x49, 0x49, 0x49, 0x41},
        ['F'] = {0x7F, 0x09, 0x09, 0x09, 0x01},
        ['G'] = {0x3E, 0x41, 0x49, 0x49, 0x7A},
        ['H'] = {0x7F, 0x08, 0x08, 0x08, 0x7F},
        ['I'] = {0x00, 0x41, 0x7F, 0x41, 0x00},
        ['J'] = {0x20, 0x40, 0x41, 0x3F, 0x01},
        ['K'] = {0x7F, 0x08, 0x14, 0x22, 0x41},
        ['L'] = {0x7F, 0x40, 0x40, 0x40, 0x40},
        ['M'] = {0x7F, 0x02, 0x0C, 0x02, 0x7F},
        ['N'] = {0x7F, 0x04, 0x08, 0x10, 0x7F},
        ['O'] = {0x3E, 0x41, 0x41, 0x41, 0x3E},
        ['P'] = {0x7F, 0x09, 0x09, 0x09, 0x06},
        ['Q'] = {0x3E, 0x41, 0x51, 0x21, 0x5E},
        ['R'] = {0x7F, 0x09, 0x19, 0x29, 0x46},
        ['S'] = {0x46, 0x49, 0x49, 0x49, 0x31},
        ['T'] = {0x01, 0x01, 0x7F, 0x01, 0x01},
        ['U'] = {0x3F, 0x40, 0x40, 0x40, 0x3F},
        ['V'] = {0x1F, 0x20, 0x40, 0x20, 0x1F},
        ['W'] = {0x3F, 0x40, 0x38, 0x40, 0x3F},
        ['X'] = {0x63, 0x14, 0x08, 0x14, 0x63},
        ['Y'] = {0x07, 0x08, 0x70, 0x08, 0x07},
        ['Z'] = {0x61, 0x51, 0x49, 0x45, 0x43},
        ['a'] = {0x20, 0x54, 0x54, 0x54, 0x78},
        ['b'] = {0x7F, 0x48, 0x44, 0x44, 0x38},
        ['c'] = {0x38, 0x44, 0x44, 0x44, 0x20},
        ['d'] = {0x38, 0x44, 0x44, 0x48, 0x7F},
        ['e'] = {0x38, 0x54, 0x54, 0x54, 0x18},
        ['f'] = {0x08, 0x7E, 0x09, 0x01, 0x02},
        ['g'] = {0x0C, 0x52, 0x52, 0x52, 0x3E},
        ['h'] = {0x7F, 0x08, 0x04, 0x04, 0x78},
        ['i'] = {0x00, 0x44, 0x7D, 0x40, 0x00},
        ['j'] = {0x20, 0x40, 0x44, 0x3D, 0x00},
        ['k'] = {0x7F, 0x10, 0x28, 0x44, 0x00},
        ['l'] = {0x00, 0x41, 0x7F, 0x40, 0x00},
        ['m'] = {0x7C, 0x04, 0x18, 0x04, 0x78},
        ['n'] = {0x7C, 0x08, 0x04, 0x04, 0x78},
        ['o'] = {0x38, 0x44, 0x44, 0x44, 0x38},
        ['p'] = {0x7C, 0x14, 0x14, 0x14, 0x08},
        ['q'] = {0x08, 0x14, 0x14, 0x18, 0x7C},
        ['r'] = {0x7C, 0x08, 0x04, 0x04, 0x08},
        ['s'] = {0x48, 0x54, 0x54, 0x54, 0x20},
        ['t'] = {0x04, 0x3F, 0x44, 0x40, 0x20},
        ['u'] = {0x3C, 0x40, 0x40, 0x20, 0x7C},
        ['v'] = {0x1C, 0x20, 0x40, 0x20, 0x1C},
        ['w'] = {0x3C, 0x40, 0x30, 0x40, 0x3C},
        ['x'] = {0x44, 0x28, 0x10, 0x28, 0x44},
        ['y'] = {0x0C, 0x50, 0x50, 0x50, 0x3C},
        ['z'] = {0x44, 0x64, 0x54, 0x4C, 0x44},
        ['0'] = {0x3E, 0x51, 0x49, 0x45, 0x3E},
        ['1'] = {0x00, 0x42, 0x7F, 0x40, 0x00},
        ['2'] = {0x42, 0x61, 0x51, 0x49, 0x46},
        ['3'] = {0x21, 0x41, 0x45, 0x4B, 0x31},
        ['4'] = {0x18, 0x14, 0x12, 0x7F, 0x10},
        ['5'] = {0x27, 0x45, 0x45, 0x45, 0x39},
        ['6'] = {0x3C, 0x4A, 0x49, 0x49, 0x30},
        ['7'] = {0x01, 0x71, 0x09, 0x05, 0x03},
        ['8'] = {0x36, 0x49, 0x49, 0x49, 0x36},
        ['9'] = {0x06, 0x49, 0x49, 0x29, 0x1E},
        ['.'] = {0x00, 0x60, 0x60, 0x00, 0x00},
        [','] = {0x00, 0x80, 0x60, 0x00, 0x00},
        ['!'] = {0x00, 0x00, 0x5F, 0x00, 0x00},
        ['?'] = {0x02, 0x01, 0x51, 0x09, 0x06},
        ['-'] = {0x08, 0x08, 0x08, 0x08, 0x08},
        ['_'] = {0x40, 0x40, 0x40, 0x40, 0x40},
        [' '] = {0x00, 0x00, 0x00, 0x00, 0x00},
        ['/'] = {0x20, 0x10, 0x08, 0x04, 0x02},
        ['('] = {0x00, 0x1E, 0x41, 0x00, 0x00},
        [')'] = {0x00, 0x41, 0x1E, 0x00, 0x00},
        ['['] = {0x00, 0x7F, 0x41, 0x41, 0x00},
        [']'] = {0x00, 0x41, 0x41, 0x7F, 0x00},
        ['{'] = {0x08, 0x36, 0x41, 0x00, 0x00},
        ['}'] = {0x00, 0x41, 0x36, 0x08, 0x00},
        ['<'] = {0x08, 0x14, 0x22, 0x41, 0x00},
        ['>'] = {0x00, 0x41, 0x22, 0x14, 0x08},
        ['='] = {0x14, 0x14, 0x14, 0x14, 0x14},
        ['+'] = {0x08, 0x08, 0x3E, 0x08, 0x08},
        ['*'] = {0x08, 0x2A, 0x1C, 0x2A, 0x08},
        ['%'] = {0x46, 0x26, 0x10, 0x4C, 0x62},
        ['@'] = {0x3E, 0x41, 0x5D, 0x55, 0x1E},
        ['#'] = {0x14, 0x7F, 0x14, 0x7F, 0x14},
        ['$'] = {0x24, 0x2A, 0x7F, 0x2A, 0x12},
        ['&'] = {0x30, 0x4E, 0x59, 0x26, 0x50},
        ['"'] = {0x00, 0x03, 0x00, 0x03, 0x00},
        ['\''] = {0x00, 0x01, 0x00, 0x00, 0x00},
        [':'] = {0x00, 0x36, 0x36, 0x00, 0x00},
        [';'] = {0x00, 0x80, 0x36, 0x36, 0x00},
    };

    unsigned char ch = (unsigned char)c;
    if (ch >= 128) ch = '?';

    int cx, cy;
    for (cx = 0; cx < 5; cx++) {
        unsigned char col = font[ch][cx];
        for (cy = 0; cy < 7; cy++) {
            if (col & (1 << cy)) {
                int px = x + cx * scale;
                int py = y + cy * scale;
                int sx, sy;
                for (sx = 0; sx < scale; sx++) {
                    for (sy = 0; sy < scale; sy++) {
                        draw_pixel(px + sx, py + sy, color);
                    }
                }
            }
        }
    }
}

void draw_text(int x, int y, const char *text, unsigned int color, int scale) {
    int i;
    int len = strlen(text);
    for (i = 0; i < len; i++) {
        draw_char(x + i * (6 * scale), y, text[i], color, scale);
    }
}

/* 绘制居中文字 */
void draw_text_center(int x, int y, int w, const char *text, unsigned int color, int scale) {
    int text_w = strlen(text) * 6 * scale;
    draw_text(x + (w - text_w) / 2, y, text, color, scale);
}

/* ============================================================
 * 绘制桌面元素
 * ============================================================ */

/* 绘制青柠Logo */
void draw_logo(int cx, int cy, int size) {
    int r = size / 2;
    int x, y;
    for (y = -r; y <= r; y++) {
        for (x = -r; x <= r; x++) {
            int d = x * x + y * y;
            if (d <= r * r) {
                /* 简单的云形状 */
                float nx = (float)x / r;
                float ny = (float)y / r;
                float cloud = 1.0f - (nx * nx + ny * ny);
                if (cloud > 0.3f) {
                    unsigned int color = COLOR_ACCENT;
                    if (cloud > 0.7f) color = COLOR_ACCENT_HL;
                    draw_pixel(cx + x, cy + y, color);
                }
            }
        }
    }
}

/* 绘制图标 */
void draw_icon(Icon *icon, int selected) {
    int x = icon->x;
    int y = icon->y;
    int s = icon->width;

    /* 图标背景 */
    if (selected) {
        fill_round_rect(x - 4, y - 4, s + 8, s + 8, 8, 0x40FFFFFF);
    }

    /* 图标主体（圆角方块） */
    fill_round_rect(x, y, s, s, 10, icon->color);

    /* 图标高光 */
    fill_round_rect(x + 2, y + 2, s - 4, s / 3, 6, 0x40FFFFFF);

    /* 标签 */
    int label_y = y + s + 6;
    int label_w = strlen(icon->label) * 6 * 1;
    int label_x = x + (s - label_w) / 2;
    draw_text(label_x, label_y, icon->label, COLOR_TEXT, 1);
}

/* 绘制任务栏 */
void draw_taskbar(void) {
    /* 背景 */
    fill_rect(0, 0, screen_width, TASKBAR_HEIGHT, COLOR_PANEL);

    /* 底部边框 */
    fill_rect(0, TASKBAR_HEIGHT - 1, screen_width, 1, COLOR_ACCENT);

    /* 左侧Logo */
    fill_round_rect(8, 6, 28, 28, 6, COLOR_ACCENT);
    draw_text(42, 10, "青柠OS", COLOR_TEXT, 2);

    /* 右侧时间 */
    time_t now = time(NULL);
    struct tm *tm_info = localtime(&now);
    char time_str[32];
    snprintf(time_str, sizeof(time_str), "%02d:%02d", tm_info->tm_hour, tm_info->tm_min);
    draw_text(screen_width - 60, 10, time_str, COLOR_TEXT_DIM, 2);
}

/* 绘制Dock */
void draw_dock(void) {
    int dock_y = screen_height - DOCK_HEIGHT - 8;
    int total_width = DOCK_ICON_COUNT * DOCK_ICON_SIZE + (DOCK_ICON_COUNT + 1) * 12;
    int dock_x = (screen_width - total_width) / 2;

    /* Dock背景 */
    fill_round_rect(dock_x, dock_y, total_width, DOCK_HEIGHT, 16, 0xE6334155);

    /* 图标 */
    int i;
    int icon_x = dock_x + 12;
    for (i = 0; i < DOCK_ICON_COUNT; i++) {
        dock_icons[i].x = icon_x;
        dock_icons[i].y = dock_y + (DOCK_HEIGHT - DOCK_ICON_SIZE) / 2;
        draw_icon(&dock_icons[i], 0);
        icon_x += DOCK_ICON_SIZE + 12;
    }
}

/* 绘制桌面 */
void draw_desktop(void) {
    /* 背景 */
    fill_rect(0, TASKBAR_HEIGHT, screen_width, screen_height - TASKBAR_HEIGHT, COLOR_BG);

    /* 中央Logo */
    int logo_x = screen_width / 2;
    int logo_y = screen_height / 2 - 40;
    draw_logo(logo_x, logo_y, 80);

    /* 中央文字 */
    draw_text_center(0, logo_y + 60, screen_width, "青柠OS 2.0.0", COLOR_TEXT, 3);
    draw_text_center(0, logo_y + 100, screen_width, "Linux Kernel + 自主系统层", COLOR_TEXT_DIM, 1);
    draw_text_center(0, logo_y + 130, screen_width, "内核: Linux 6.12 (Alpine virt)", COLOR_TEXT_DIM, 1);

    /* 桌面图标 */
    int i;
    for (i = 0; i < DESKTOP_ICON_COUNT; i++) {
        draw_icon(&desktop_icons[i], 0);
    }

    /* 任务栏 */
    draw_taskbar();

    /* Dock */
    draw_dock();
}

/* 绘制窗口 */
void draw_window(Window *win, int active) {
    if (!win->visible || win->minimized) return;

    int x = win->x, y = win->y;
    int w = win->width, h = win->height;

    /* 阴影 */
    fill_rect(x + 4, y + 4, w, h, 0x40000000);

    /* 窗口背景 */
    fill_rect(x, y, w, h, COLOR_BG_LIGHT);

    /* 标题栏 */
    unsigned int title_color = active ? COLOR_ACCENT : COLOR_PANEL;
    fill_rect(x, y, w, WINDOW_TITLE_H, title_color);

    /* 标题文字 */
    draw_text(x + 10, y + 8, win->title, COLOR_WHITE, 1);

    /* 关闭按钮 */
    fill_round_rect(x + w - 28, y + 4, 24, 24, 4, 0xFFEF4444);
    draw_text(x + w - 22, y + 8, "X", COLOR_WHITE, 1);

    /* 边框 */
    draw_rect_border(x, y, w, h, WINDOW_BORDER, active ? COLOR_ACCENT : COLOR_PANEL);
}

/* ============================================================
 * 应用启动
 * ============================================================ */

static void launch_terminal(void) {
    printf("[青柠OS] 启动终端...\n");
    /* 在后台启动终端 */
    if (fork() == 0) {
        execlp("/bin/sh", "sh", "-c", "exec /bin/sh", NULL);
        exit(0);
    }
}

static void launch_browser(void) {
    printf("[青柠OS] 启动浏览器...\n");
    /* 尝试启动 lynx/links 文本浏览器 */
    if (fork() == 0) {
        execlp("lynx", "lynx", "https://3862242786-sudo.github.io/pan/", NULL);
        execlp("links", "links", "https://3862242786-sudo.github.io/pan/", NULL);
        exit(0);
    }
}

static void launch_filemanager(void) {
    printf("[青柠OS] 启动文件管理器...\n");
    /* 简单的文件浏览窗口 */
    if (window_count < MAX_WINDOWS) {
        Window *w = &windows[window_count++];
        w->x = 100 + window_count * 30;
        w->y = 100 + window_count * 30;
        w->width = 400;
        w->height = 300;
        w->visible = 1;
        w->minimized = 0;
        strncpy(w->title, "文件管理器", MAX_TITLE_LEN);
        active_window = window_count - 1;
    }
}

static void launch_settings(void) {
    printf("[青柠OS] 启动设置...\n");
    if (window_count < MAX_WINDOWS) {
        Window *w = &windows[window_count++];
        w->x = 150 + window_count * 30;
        w->y = 120 + window_count * 30;
        w->width = 350;
        w->height = 250;
        w->visible = 1;
        w->minimized = 0;
        strncpy(w->title, "系统设置", MAX_TITLE_LEN);
        active_window = window_count - 1;
    }
}

static void launch_info(void) {
    printf("[青柠OS] 显示系统信息...\n");
    if (window_count < MAX_WINDOWS) {
        Window *w = &windows[window_count++];
        w->x = 200 + window_count * 30;
        w->y = 150 + window_count * 30;
        w->width = 380;
        w->height = 280;
        w->visible = 1;
        w->minimized = 0;
        strncpy(w->title, "关于青柠OS", MAX_TITLE_LEN);
        active_window = window_count - 1;
    }
}

/* ============================================================
 * 输入处理
 * ============================================================ */

int mouse_init(void) {
    mouse_fd = open("/dev/input/mice", O_RDONLY | O_NONBLOCK);
    if (mouse_fd < 0) {
        mouse_fd = open("/dev/input/mouse0", O_RDONLY | O_NONBLOCK);
    }
    return mouse_fd;
}

void mouse_poll(void) {
    if (mouse_fd < 0) return;

    unsigned char buf[3];
    while (read(mouse_fd, buf, 3) == 3) {
        int dx = (signed char)buf[1];
        int dy = (signed char)buf[2];

        mouse_x += dx;
        mouse_y -= dy;  /* Y轴翻转 */

        if (mouse_x < 0) mouse_x = 0;
        if (mouse_x >= screen_width) mouse_x = screen_width - 1;
        if (mouse_y < 0) mouse_y = 0;
        if (mouse_y >= screen_height) mouse_y = screen_height - 1;

        /* 左键点击 */
        if (buf[0] & 0x01) {
            int i;
            /* 检查Dock图标 */
            int dock_y = screen_height - DOCK_HEIGHT - 8;
            int total_width = DOCK_ICON_COUNT * DOCK_ICON_SIZE + (DOCK_ICON_COUNT + 1) * 12;
            int dock_x = (screen_width - total_width) / 2;

            for (i = 0; i < DOCK_ICON_COUNT; i++) {
                int ix = dock_x + 12 + i * (DOCK_ICON_SIZE + 12);
                int iy = dock_y + (DOCK_HEIGHT - DOCK_ICON_SIZE) / 2;
                if (mouse_x >= ix && mouse_x < ix + DOCK_ICON_SIZE &&
                    mouse_y >= iy && mouse_y < iy + DOCK_ICON_SIZE) {
                    if (dock_icons[i].onclick) dock_icons[i].onclick();
                    usleep(200000);
                    return;
                }
            }

            /* 检查桌面图标 */
            for (i = 0; i < DESKTOP_ICON_COUNT; i++) {
                if (mouse_x >= desktop_icons[i].x && mouse_x < desktop_icons[i].x + ICON_SIZE &&
                    mouse_y >= desktop_icons[i].y && mouse_y < desktop_icons[i].y + ICON_SIZE) {
                    if (desktop_icons[i].onclick) desktop_icons[i].onclick();
                    usleep(200000);
                    return;
                }
            }
        }
    }
}

/* 绘制鼠标 */
void draw_mouse(void) {
    if (!mouse_visible) return;
    int x = mouse_x, y = mouse_y;
    /* 简单箭头 */
    draw_pixel(x, y, COLOR_WHITE);
    draw_pixel(x+1, y, COLOR_WHITE);
    draw_pixel(x+2, y, COLOR_WHITE);
    draw_pixel(x, y+1, COLOR_WHITE);
    draw_pixel(x, y+2, COLOR_WHITE);
    draw_pixel(x+1, y+1, COLOR_BLACK);
}

/* ============================================================
 * 主循环
 * ============================================================ */

void signal_handler(int sig) {
    running = 0;
}

int main(int argc, char *argv[]) {
    printf("[青柠OS] 启动桌面环境...\n");

    /* 信号处理 */
    signal(SIGINT, signal_handler);
    signal(SIGTERM, signal_handler);

    /* 初始化帧缓冲 */
    if (fb_init() < 0) {
        printf("[青柠OS] 无法初始化帧缓冲，回退到文本模式\n");
        /* 启动文本shell */
        execlp("/bin/sh", "sh", NULL);
        return 1;
    }

    /* 初始化鼠标 */
    mouse_init();

    /* 初始化窗口 */
    memset(windows, 0, sizeof(windows));

    printf("[青柠OS] 桌面环境就绪 (%dx%d)\n", screen_width, screen_height);

    /* 主循环 */
    while (running) {
        /* 绘制桌面 */
        draw_desktop();

        /* 绘制窗口 */
        int i;
        for (i = 0; i < window_count; i++) {
            draw_window(&windows[i], i == active_window);
        }

        /* 处理输入 */
        mouse_poll();

        /* 绘制鼠标 */
        draw_mouse();

        /* 刷新 */
        usleep(16666);  /* ~60fps */
    }

    /* 清理 */
    if (mouse_fd >= 0) close(mouse_fd);
    fb_close();

    printf("[青柠OS] 桌面环境已退出\n");
    return 0;
}
