# ============================================================
# 青柠OS GUI 版构建脚本 v2.0
# PowerShell 脚本 - 构建带图形界面的青柠OS
# ============================================================

#Requires -RunAsAdministrator

param(
    [string]$OutputPath = ".\output\QingningOS-GUI-v2.0.iso"
)

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$Host.UI.RawUI.BackgroundColor = "Black"
$Host.UI.RawUI.ForegroundColor = "Green"
Clear-Host

function Write-Logo {
    Write-Host ""
    Write-Host "  ╔══════════════════════════════════════════════════════════════╗" -ForegroundColor Green
    Write-Host "  ║                                                              ║" -ForegroundColor Green
    Write-Host "  ║       青柠OS GUI 版构建工具 v2.0                             ║" -ForegroundColor Green
    Write-Host "  ║       Linux内核 + 自主图形界面 + Windows构建                  ║" -ForegroundColor Green
    Write-Host "  ║                                                              ║" -ForegroundColor Green
    Write-Host "  ╚══════════════════════════════════════════════════════════════╝" -ForegroundColor Green
    Write-Host ""
    Write-Host "  新特性:" -ForegroundColor Cyan
    Write-Host "    图形界面 (Framebuffer直接渲染)" -ForegroundColor Cyan
    Write-Host "    任务栏 + Dock栏 + 桌面图标" -ForegroundColor Cyan
    Write-Host "    窗口管理器 (多窗口支持)" -ForegroundColor Cyan
    Write-Host "    鼠标支持" -ForegroundColor Cyan
    Write-Host ""
}

function Write-Info { param([string]$m) Write-Host "  [信息] $m" -ForegroundColor Cyan }
function Write-OK   { param([string]$m) Write-Host "  [OK] $m" -ForegroundColor Green }
function Write-Warn { param([string]$m) Write-Host "  [警告] $m" -ForegroundColor Yellow }
function Write-Err  { param([string]$m) Write-Host "  [错误] $m" -ForegroundColor Red }

Write-Logo

# ============================================================
# 1. 检查依赖
# ============================================================
Write-Info "检查构建依赖..."

# 7-Zip
$7zip = $null
@("C:\Program Files\7-Zip\7z.exe", "C:\Program Files (x86)\7-Zip\7z.exe", ".\tools\7z.exe") | ForEach-Object {
    if (Test-Path $_) { $7zip = $_ }
}
if (-not $7zip) {
    Write-Err "未找到 7-Zip！请安装: https://www.7-zip.org/"
    Read-Host "按回车退出"; exit 1
}
Write-OK "7-Zip"

# curl
$curl = Get-Command curl -ErrorAction SilentlyContinue
if (-not $curl) {
    Write-Err "未找到 curl！"
    Read-Host "按回车退出"; exit 1
}
Write-OK "curl"

# 检查 musl 交叉编译器 (可选)
$musl_cc = Get-Command x86_64-linux-musl-gcc -ErrorAction SilentlyContinue
if ($musl_cc) {
    Write-OK "musl 交叉编译器"
} else {
    Write-Warn "未找到 musl 交叉编译器，将使用系统 gcc"
    Write-Info "如需静态链接，请安装 musl 工具链"
}

# ============================================================
# 2. 准备目录
# ============================================================
$buildDir = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
$workDir   = Join-Path $buildDir "work"
$isoDir    = Join-Path $workDir "iso"
$kernelDir = Join-Path $workDir "kernel"
$overlayDir = Join-Path $workDir "overlay"
$outputDir = Join-Path $buildDir "output"
$srcDir    = Join-Path $buildDir "src"

Remove-Item -Path $workDir -Recurse -Force -ErrorAction SilentlyContinue
@($isoDir, $kernelDir, $overlayDir, $outputDir) | ForEach-Object { New-Item -ItemType Directory -Path $_ -Force | Out-Null }
Write-OK "工作目录准备完成"

# ============================================================
# 3. 下载 Linux 内核和 initramfs
# ============================================================
$alpineVer = "3.22"
$alpineMirror = "https://dl-cdn.alpinelinux.org/alpine/v${alpineVer}/releases/x86_64/netboot"

$files = @(
    @{Name="vmlinuz-virt"; URL="$alpineMirror/vmlinuz-virt"; Size="11MB"},
    @{Name="initramfs-virt"; URL="$alpineMirror/initramfs-virt"; Size="9MB"}
)

foreach ($file in $files) {
    Write-Info "下载 $($file.Name) (约 $($file.Size))..."
    $dest = Join-Path $kernelDir $file.Name
    try {
        curl.exe -L -o "$dest" $file.URL --connect-timeout 30 --max-time 300 2>$null
        if (Test-Path $dest) {
            $size = (Get-Item $dest).Length / 1MB
            Write-OK "$($file.Name) 下载完成 ($([math]::Round($size,1)) MB)"
        } else {
            throw "下载失败"
        }
    }
    catch {
        Write-Err "下载失败: $_"
        Write-Info "请手动下载 $($file.URL) 到 $dest"
        Read-Host "按回车退出"; exit 1
    }
}

# ============================================================
# 4. 编译青柠桌面环境
# ============================================================
Write-Info "编译青柠桌面环境..."

$desktopBin = Join-Path $srcDir "qingning-desktop"

if (Test-Path (Join-Path $srcDir "qingning-desktop.c")) {
    Push-Location $srcDir
    try {
        if ($musl_cc) {
            & x86_64-linux-musl-gcc -O2 -Wall -std=c99 -D_GNU_SOURCE -o qingning-desktop qingning-desktop.c -static 2>&1 | Out-Null
        } else {
            & gcc -O2 -Wall -std=c99 -D_GNU_SOURCE -o qingning-desktop qingning-desktop.c 2>&1 | Out-Null
        }

        if (Test-Path $desktopBin) {
            $binSize = (Get-Item $desktopBin).Length / 1KB
            Write-OK "编译成功 ($([math]::Round($binSize,1)) KB)"
        } else {
            throw "编译失败"
        }
    }
    catch {
        Write-Warn "编译失败: $_"
        Write-Warn "将使用预编译二进制或跳过图形界面"
    }
    Pop-Location
} else {
    Write-Warn "未找到源代码"
}

# ============================================================
# 5. 创建青柠OS系统层 (overlay)
# ============================================================
Write-Info "创建青柠OS系统层..."

# 5.1 系统标识
$etcDir = Join-Path $overlayDir "etc"
New-Item -ItemType Directory -Path $etcDir -Force | Out-Null

@"
NAME="青柠OS"
VERSION="2.0.0-GUI"
ID=qingning-os
ID_LIKE=alpine
PRETTY_NAME="青柠OS 2.0.0 GUI (Linux)"
HOME_URL="https://3862242786-sudo.github.io/pan/qingning-os.html"
SUPPORT_URL="https://3862242786-sudo.github.io/pan/qingning-guide.html"
BUG_REPORT_URL="https://github.com/3862242786-sudo/qingning-os/issues"
LOGO=qingning-os
"@ | Set-Content -Path (Join-Path $etcDir "os-release") -Encoding UTF8 -Force

@"
DISTRIB_ID=QingningOS
DISTRIB_RELEASE=2.0.0-GUI
DISTRIB_CODENAME=Linux
DISTRIB_DESCRIPTION="青柠OS 2.0.0 GUI (Linux)"
"@ | Set-Content -Path (Join-Path $etcDir "lsb-release") -Encoding UTF8 -Force

# 5.2 主机名和网络
"qingning-os" | Set-Content -Path (Join-Path $etcDir "hostname") -Encoding UTF8 -Force
@"
127.0.0.1	localhost qingning-os
::1		localhost qingning-os
"@ | Set-Content -Path (Join-Path $etcDir "hosts") -Encoding UTF8 -Force

# 5.3 初始化系统 (启动图形界面)
$sbinDir = Join-Path $overlayDir "sbin"
New-Item -ItemType Directory -Path $sbinDir -Force | Out-Null

@"
#!/bin/sh
# 青柠OS GUI init 系统 v2.0

echo '[青柠OS] 启动中...'

# 挂载基本文件系统
mount -t proc proc /proc 2>/dev/null
mount -t sysfs sysfs /sys 2>/dev/null
mount -t devtmpfs devtmpfs /dev 2>/dev/null
mkdir -p /dev/pts
mount -t devpts devpts /dev/pts 2>/dev/null
mount -t tmpfs tmpfs /tmp 2>/dev/null
mount -t tmpfs tmpfs /run 2>/dev/null

# 设置主机名
hostname qingning-os 2>/dev/null

# 加载显卡驱动
modprobe bochs_drm 2>/dev/null
modprobe virtio_gpu 2>/dev/null
modprobe vmwgfx 2>/dev/null
modprobe cirrus 2>/dev/null
modprobe vboxvideo 2>/dev/null

# 等待帧缓冲设备
sleep 1

# 检查帧缓冲
if [ -c /dev/fb0 ]; then
    echo '[青柠OS] 检测到帧缓冲设备，启动图形界面...'
    # 设置字体
    setfont /usr/share/consolefonts/lat9w-16.psf.gz 2>/dev/null
    # 启动图形桌面
    if [ -x /usr/bin/qingning-desktop ]; then
        /usr/bin/qingning-desktop
    else
        echo '[青柠OS] 图形界面未找到，进入文本模式'
        exec /bin/sh
    fi
else
    echo '[青柠OS] 未检测到帧缓冲，进入文本模式'
    echo '提示: 在虚拟机中启用显卡3D加速可获得图形界面'
    exec /bin/sh
fi
"@ | Set-Content -Path (Join-Path $sbinDir "init") -Encoding UTF8 -Force

# 5.4 Shell 配置
$profileDir = Join-Path $overlayDir "etc/profile.d"
New-Item -ItemType Directory -Path $profileDir -Force | Out-Null

@"
# 青柠OS Shell 配置
export PS1='\[\033[0;32m\]\u@青柠OS\[\033[0m\]:\[\033[0;34m\]\w\[\033[0m\]# '
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export TERM=linux
export HOME=/root
export LANG=zh_CN.UTF-8

alias ll='ls -la --color=auto'
alias la='ls -a --color=auto'
alias cls='clear'

# 欢迎信息
echo ''
echo '  ╔══════════════════════════════════════════╗'
echo '  ║      青柠OS 2.0.0 GUI (Linux)           ║'
echo '  ║   Linux Kernel + 自主图形界面            ║'
echo '  ╚══════════════════════════════════════════╝'
echo ''
echo '  系统: 青柠OS 2.0.0 GUI'
echo '  内核: Linux (Alpine virt)'
echo '  界面: Framebuffer直接渲染'
echo '  官网: https://3862242786-sudo.github.io/pan/'
echo ''
echo '  命令:'
echo '    qingning-desktop  启动图形界面'
echo '    qingning-info     系统信息'
echo '    ifconfig          网络信息'
echo '    ping <地址>       网络测试'
echo ''
"@ | Set-Content -Path (Join-Path $profileDir "qingning.sh") -Encoding UTF8 -Force

# 5.5 系统信息命令
$usrBinDir = Join-Path $overlayDir "usr/bin"
New-Item -ItemType Directory -Path $usrBinDir -Force | Out-Null

@"
#!/bin/sh
echo ''
echo '  ╔══════════════════════════════════════════════════════════════╗'
echo '  ║                    青柠OS 系统信息                          ║'
echo '  ╚══════════════════════════════════════════════════════════════╝'
echo ''
echo '  操作系统: 青柠OS 2.0.0 GUI (Linux)'
echo '  内核:    ' \$(uname -r)
echo '  架构:    ' \$(uname -m)
echo '  主机名:  ' \$(hostname)
echo '  运行时间:' \$(uptime)
echo ''
echo '  图形界面: Framebuffer直接渲染'
echo '  窗口管理: 青柠WM (自主开发)'
echo '  渲染引擎: 软件渲染 (CPU)'
echo ''
echo '  官网: https://3862242786-sudo.github.io/pan/'
echo '  网盘: https://3862242786-sudo.github.io/pan/'
echo '  商店: https://3862242786-sudo.github.io/pan/qingning-store.html'
echo ''
"@ | Set-Content -Path (Join-Path $usrBinDir "qingning-info") -Encoding UTF8 -Force

# 5.6 复制编译好的桌面环境
if (Test-Path $desktopBin) {
    Copy-Item $desktopBin $usrBinDir -Force
    Write-OK "复制图形界面二进制文件"
}

# 5.7 创建启动脚本
@"
#!/bin/sh
# 启动青柠桌面环境
if [ -c /dev/fb0 ]; then
    echo '[青柠OS] 启动图形界面...'
    /usr/bin/qingning-desktop
else
    echo '[青柠OS] 无帧缓冲设备，无法启动图形界面'
    echo '请在虚拟机设置中启用显卡支持'
fi
"@ | Set-Content -Path (Join-Path $usrBinDir "start-gui") -Encoding UTF8 -Force

Write-OK "青柠OS系统层创建完成"

# ============================================================
# 6. 创建 ISO 启动结构
# ============================================================
Write-Info "创建 ISO 启动结构..."

$bootDir = Join-Path $isoDir "boot"
New-Item -ItemType Directory -Path $bootDir -Force | Out-Null

Copy-Item "$kernelDir\vmlinuz-virt" "$bootDir\vmlinuz" -Force
Copy-Item "$kernelDir\initramfs-virt" "$bootDir\initramfs" -Force
Write-OK "复制内核和initramfs"

# ISOLINUX配置
$isolinuxDir = Join-Path $isoDir "isolinux"
New-Item -ItemType Directory -Path $isolinuxDir -Force | Out-Null

@"
DEFAULT qingning
PROMPT 0
TIMEOUT 30

LABEL qingning
    KERNEL /boot/vmlinuz
    INITRD /boot/initramfs
    APPEND modules=loop,squashfs,sd-mod,usb-storage,bochs_drm,virtio_gpu,vmwgfx quiet nomodeset
    MENU LABEL 青柠OS 2.0.0 GUI (图形界面)
    MENU DEFAULT

LABEL qingning-text
    KERNEL /boot/vmlinuz
    INITRD /boot/initramfs
    APPEND modules=loop,squashfs,sd-mod,usb-storage quiet nomodeset 3
    MENU LABEL 青柠OS 2.0.0 (文本模式)

LABEL rescue
    KERNEL /boot/vmlinuz
    INITRD /boot/initramfs
    APPEND modules=loop,squashfs,sd-mod,usb-storage single
    MENU LABEL 青柠OS 救援模式
"@ | Set-Content -Path (Join-Path $isolinuxDir "isolinux.cfg") -Encoding UTF8 -Force

# 下载ISOLINUX引导文件
Write-Info "下载 ISOLINUX 引导文件..."
$isolinuxBin = Join-Path $isolinuxDir "isolinux.bin"
$ldlinuxC32 = Join-Path $isolinuxDir "ldlinux.c32"

try {
    $isolinuxURL = "https://raw.githubusercontent.com/coreboot/syslinux/syslinux-6.04/bios/core/isolinux.bin"
    $ldlinuxURL = "https://raw.githubusercontent.com/coreboot/syslinux/syslinux-6.04/bios/com32/elflink/ldlinux/ldlinux.c32"
    curl.exe -L -o "$isolinuxBin" "$isolinuxURL" --connect-timeout 15 --max-time 60 2>$null
    curl.exe -L -o "$ldlinuxC32" "$ldlinuxURL" --connect-timeout 15 --max-time 60 2>$null
    if ((Test-Path $isolinuxBin) -and (Test-Path $ldlinuxC32)) {
        Write-OK "ISOLINUX 引导文件下载完成"
    } else {
        throw "下载失败"
    }
}
catch {
    Write-Warn "GitHub下载失败，尝试从Alpine ISO提取..."
    $alpineISO = Join-Path $workDir "alpine-temp.iso"
    curl.exe -L -o "$alpineISO" "https://dl-cdn.alpinelinux.org/alpine/v3.22/releases/x86_64/alpine-virt-3.22.0-x86_64.iso" --connect-timeout 30 --max-time 600 2>$null
    if (Test-Path $alpineISO) {
        & $7zip e "$alpineISO" "-o$isolinuxDir" "isolinux/isolinux.bin" "isolinux/ldlinux.c32" -y 2>$null | Out-Null
        Remove-Item $alpineISO -Force -ErrorAction SilentlyContinue
        if ((Test-Path $isolinuxBin) -and (Test-Path $ldlinuxC32)) {
            Write-OK "从Alpine ISO提取成功"
        }
    }
}

# ============================================================
# 7. 生成 ISO
# ============================================================
Write-Info "生成青柠OS GUI版 ISO..."

$finalIso = Join-Path $outputDir "QingningOS-GUI-v2.0.iso"

# .disk信息
$diskDir = Join-Path $isoDir ".disk"
New-Item -ItemType Directory -Path $diskDir -Force | Out-Null
"青柠OS 2.0.0 GUI - Release amd64 ($(Get-Date -Format 'yyyyMMdd'))" | Set-Content -Path (Join-Path $diskDir "info") -Encoding UTF8 -Force

# 使用oscdimg或7-Zip
$oscdimg = $null
@(".\tools\oscdimg.exe", "C:\Program Files (x86)\Windows Kits\10\Assessment and Deployment Kit\Deployment Tools\amd64\Oscdimg\oscdimg.exe") | ForEach-Object {
    if (Test-Path $_) { $oscdimg = $_ }
}

if ($oscdimg -and (Test-Path $isolinuxBin) -and (Get-Item $isolinuxBin).Length -gt 0) {
    & $oscdimg -m -o -u2 -udfver102 -bootdata:"2#p0,e,b`"$isolinuxBin`"" -l"QingningOS-GUI-2.0" "$isoDir" "$finalIso" 2>&1 | Out-Null
}

if (-not (Test-Path $finalIso) -or (Get-Item $finalIso).Length -lt 1MB) {
    & $7zip a -tiso "$finalIso" "$isoDir\*" 2>&1 | Out-Null
}

# ============================================================
# 8. 完成
# ============================================================
Write-Host ""
Write-Host "  ╔══════════════════════════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "  ║                     构建完成！                               ║" -ForegroundColor Green
Write-Host "  ╚══════════════════════════════════════════════════════════════╝" -ForegroundColor Green
Write-Host ""

if (Test-Path $finalIso) {
    $sizeMB = [math]::Round((Get-Item $finalIso).Length / 1MB, 2)
    Write-OK "输出: $finalIso"
    Write-OK "大小: $sizeMB MB"
    Write-Host ""
    Write-Host "  ════════════════════════════════════════════════════════════" -ForegroundColor Cyan
    Write-Host "  虚拟机设置:" -ForegroundColor Cyan
    Write-Host "  ════════════════════════════════════════════════════════════" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "  VMware/VirtualBox:" -ForegroundColor White
    Write-Host "    Linux → Other Linux 5.x kernel 64-bit" -ForegroundColor Gray
    Write-Host "    1核 / 512MB内存 / 4GB磁盘" -ForegroundColor Gray
    Write-Host "    显卡: 启用3D加速 (推荐)" -ForegroundColor Gray
    Write-Host "    CD/DVD → 选择此ISO" -ForegroundColor Gray
    Write-Host ""
    Write-Host "  ════════════════════════════════════════════════════════════" -ForegroundColor Cyan
    Write-Host "  图形界面特性:" -ForegroundColor Cyan
    Write-Host "  ════════════════════════════════════════════════════════════" -ForegroundColor Cyan
    Write-Host "  任务栏: 顶部，显示Logo和时间" -ForegroundColor White
    Write-Host "  Dock栏: 底部居中，5个应用图标" -ForegroundColor White
    Write-Host "  桌面: 中央Logo + 4个快捷方式" -ForegroundColor White
    Write-Host "  窗口: 支持多窗口、标题栏、关闭按钮" -ForegroundColor White
    Write-Host "  鼠标: 支持移动和点击" -ForegroundColor White
    Write-Host ""
}

$clean = Read-Host "  清理临时文件? (Y/N)"
if ($clean -eq "Y" -or $clean -eq "y") {
    Remove-Item -Path $workDir -Recurse -Force -ErrorAction SilentlyContinue
    Write-OK "已清理"
}

Read-Host "  按回车退出"
exit 0
