@echo off
chcp 65001 >nul
title 青柠OS Windows 构建工具 v2.1 - 最小化修改模式
color 0A
cls

echo.
echo  ╔══════════════════════════════════════════════════════════════╗
echo  ║                                                              ║
echo  ║         青柠OS Windows 构建工具 v2.1                         ║
echo  ║      最小化修改模式 - 安全可靠的ISO重新封装                  ║
echo  ║                                                              ║
echo  ╚══════════════════════════════════════════════════════════════╝
echo.
echo  [模式说明] 此模式只修改ISO中可直接访问的文件，不重新打包squashfs，
echo            确保生成的ISO 100%%可启动，适合虚拟机安装测试。
echo.

:: ============================================================
:: 检查管理员权限
:: ============================================================
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo  [错误] 需要管理员权限！
    echo  请右键点击此脚本，选择"以管理员身份运行"
    pause
    exit /b 1
)

:: ============================================================
:: 设置路径
:: ============================================================
set "BUILD_DIR=%~dp0"
set "WORK_DIR=%BUILD_DIR%work"
set "OUTPUT_DIR=%BUILD_DIR%output"
set "TOOLS_DIR=%BUILD_DIR%tools"
set "ASSETS_DIR=%BUILD_DIR%assets"
set "OUTPUT_ISO=%OUTPUT_DIR%\qingning-os-2.0.0-amd64.iso"

:: ============================================================
:: 检查依赖
:: ============================================================
echo  [检查] 检查构建依赖...

:: 检查 7-Zip
if exist "C:\Program Files\7-Zip\7z.exe" (
    set "SEVENZIP=C:\Program Files\7-Zip\7z.exe"
) else if exist "C:\Program Files (x86)\7-Zip\7z.exe" (
    set "SEVENZIP=C:\Program Files (x86)\7-Zip\7z.exe"
) else if exist "%TOOLS_DIR%\7z.exe" (
    set "SEVENZIP=%TOOLS_DIR%\7z.exe"
) else (
    echo  [错误] 未找到 7-Zip！
    echo  请安装 7-Zip: https://www.7-zip.org/
    pause
    exit /b 1
)
echo  [OK] 7-Zip

:: 检查 XUbuntu ISO
set "ISO_FILE="
for %%f in ("%BUILD_DIR%\*.iso") do (
    set "ISO_FILE=%%f"
    goto :found_iso
)
:found_iso

if not defined ISO_FILE (
    echo.
    echo  [错误] 未找到 XUbuntu ISO 文件！
    echo  请将 XUbuntu ISO 放到此文件夹，然后重新运行。
    echo  下载: https://cdimage.ubuntu.com/xubuntu/releases/24.04/release/
    echo.
    pause
    exit /b 1
)
echo  [OK] ISO: %ISO_FILE%

:: ============================================================
:: 准备工作目录
:: ============================================================
echo.
echo  [准备] 创建工作目录...
if exist "%WORK_DIR%" rmdir /s /q "%WORK_DIR%"
if exist "%OUTPUT_DIR%" rmdir /s /q "%OUTPUT_DIR%"
mkdir "%WORK_DIR%"
mkdir "%OUTPUT_DIR%"

:: ============================================================
:: 解压 ISO
:: ============================================================
echo.
echo  [步骤 1/5] 解压 XUbuntu ISO...
echo  这可能需要 2-5 分钟，请耐心等待...
"%SEVENZIP%" x "%ISO_FILE%" -o"%WORK_DIR%\iso" -y >nul 2>&1
if %errorlevel% neq 0 (
    echo  [错误] ISO 解压失败！
    pause
    exit /b 1
)
echo  [OK] ISO 解压完成

:: ============================================================
:: 应用青柠品牌定制（最小化修改）
:: ============================================================
echo.
echo  [步骤 2/5] 应用青柠OS品牌定制...

:: 2.1 更新 .disk/info
echo  青柠OS 2.0.0 "XUbuntu" - Release amd64 (%date:~0,4%%date:~5,2%%date:~8,2%) > "%WORK_DIR%\iso\.disk\info"
echo  [OK] 更新 .disk/info

:: 2.2 更新 README.diskdefines
echo #define DISKNAME  青柠OS 2.0.0 "XUbuntu" - Release amd64 > "%WORK_DIR%\iso\README.diskdefines"
echo #define TYPE  binary >> "%WORK_DIR%\iso\README.diskdefines"
echo #define TYPEbinary  1 >> "%WORK_DIR%\iso\README.diskdefines"
echo #define ARCH  amd64 >> "%WORK_DIR%\iso\README.diskdefines"
echo #define ARCHamd64  1 >> "%WORK_DIR%\iso\README.diskdefines"
echo #define DISKNUM  1 >> "%WORK_DIR%\iso\README.diskdefines"
echo #define DISKNUM1  1 >> "%WORK_DIR%\iso\README.diskdefines"
echo #define TOTALNUM  0 >> "%WORK_DIR%\iso\README.diskdefines"
echo #define TOTALNUM0  1 >> "%WORK_DIR%\iso\README.diskdefines"
echo  [OK] 更新 README.diskdefines

:: 2.3 修改 GRUB 启动菜单为青柠主题
echo  [信息] 修改 GRUB 启动菜单...
if exist "%WORK_DIR%\iso\boot\grub\grub.cfg" (
    powershell -Command "$content = Get-Content '%WORK_DIR%\iso\boot\grub\grub.cfg' -Raw; $content = $content -replace 'Xubuntu','青柠OS' -replace 'xubuntu','qingning-os' -replace 'Try Xubuntu','试用 青柠OS' -replace 'Install Xubuntu','安装 青柠OS'; Set-Content '%WORK_DIR%\iso\boot\grub\grub.cfg' $content -Encoding UTF8" 2>nul
    echo  [OK] 修改 grub.cfg
)

:: 2.4 修改 ISOLINUX 启动菜单
echo  [信息] 修改 ISOLINUX 启动菜单...
if exist "%WORK_DIR%\iso\isolinux\txt.cfg" (
    powershell -Command "$content = Get-Content '%WORK_DIR%\iso\isolinux\txt.cfg' -Raw; $content = $content -replace 'Xubuntu','青柠OS' -replace 'xubuntu','qingning-os'; Set-Content '%WORK_DIR%\iso\isolinux\txt.cfg' $content -Encoding UTF8" 2>nul
    echo  [OK] 修改 txt.cfg
)
if exist "%WORK_DIR%\iso\isolinux\isolinux.cfg" (
    powershell -Command "$content = Get-Content '%WORK_DIR%\iso\isolinux\isolinux.cfg' -Raw; $content = $content -replace 'Xubuntu','青柠OS'; Set-Content '%WORK_DIR%\iso\isolinux\isolinux.cfg' $content -Encoding UTF8" 2>nul
)

:: 2.5 复制青柠壁纸到ISO（如果存在）
if exist "%ASSETS_DIR%\qingning-wallpaper.jpg" (
    echo  [信息] 复制青柠壁纸...
    copy /y "%ASSETS_DIR%\qingning-wallpaper.jpg" "%WORK_DIR%\iso\boot\grub\qingning-wallpaper.jpg" >nul 2>&1
)
if exist "%ASSETS_DIR%\qingning-wallpaper.png" (
    copy /y "%ASSETS_DIR%\qingning-wallpaper.png" "%WORK_DIR%\iso\boot\grub\qingning-wallpaper.png" >nul 2>&1
)

:: 2.6 修改 GRUB 背景（如果壁纸存在）
if exist "%WORK_DIR%\iso\boot\grub\qingning-wallpaper.jpg" (
    powershell -Command "$content = Get-Content '%WORK_DIR%\iso\boot\grub\grub.cfg' -Raw; if ($content -notmatch 'qingning-wallpaper') { $content = $content -replace 'load_video', \"load_video\nset theme=/boot/grub/themes/qingning/theme.txt\" }; Set-Content '%WORK_DIR%\iso\boot\grub\grub.cfg' $content -Encoding UTF8" 2>nul
)

:: 2.7 创建青柠GRUB主题目录
mkdir "%WORK_DIR%\iso\boot\grub\themes\qingning" 2>nul
if exist "%ASSETS_DIR%\theme.txt" (
    copy /y "%ASSETS_DIR%\theme.txt" "%WORK_DIR%\iso\boot\grub\themes\qingning\theme.txt" >nul 2>&1
)

:: 2.8 修改 casper 中的种子文件（预配置）
:: 这些文件在Live系统启动后会被复制到新系统
echo  [信息] 添加青柠预配置...
mkdir "%WORK_DIR%\iso\casper\qingning-seed" 2>nul

:: 创建 os-release 种子文件
echo NAME="青柠OS" > "%WORK_DIR%\iso\casper\qingning-seed\os-release"
echo VERSION="2.0.0" >> "%WORK_DIR%\iso\casper\qingning-seed\os-release"
echo ID=qingning-os >> "%WORK_DIR%\iso\casper\qingning-seed\os-release"
echo ID_LIKE=ubuntu >> "%WORK_DIR%\iso\casper\qingning-seed\os-release"
echo PRETTY_NAME="青柠OS 2.0.0 (XUbuntu)" >> "%WORK_DIR%\iso\casper\qingning-seed\os-release"
echo HOME_URL="https://3862242786-sudo.github.io/pan/qingning-os.html" >> "%WORK_DIR%\iso\casper\qingning-seed\os-release"

:: 创建 lsb-release 种子文件
echo DISTRIB_ID=QingningOS > "%WORK_DIR%\iso\casper\qingning-seed\lsb-release"
echo DISTRIB_RELEASE=2.0.0 >> "%WORK_DIR%\iso\casper\qingning-seed\lsb-release"
echo DISTRIB_CODENAME=XUbuntu >> "%WORK_DIR%\iso\casper\qingning-seed\lsb-release"
echo DISTRIB_DESCRIPTION="青柠OS 2.0.0 (XUbuntu)" >> "%WORK_DIR%\iso\casper\qingning-seed\lsb-release"

:: 创建 issue 种子文件
echo 青柠OS 2.0.0 (XUbuntu) \n \l > "%WORK_DIR%\iso\casper\qingning-seed\issue"
echo 青柠OS 2.0.0 (XUbuntu) > "%WORK_DIR%\iso\casper\qingning-seed\issue.net"

:: 创建安装后脚本（首次启动时执行）
echo #!/bin/bash > "%WORK_DIR%\iso\casper\qingning-seed\qingning-setup.sh"
echo # 青柠OS 首次启动配置脚本 >> "%WORK_DIR%\iso\casper\qingning-seed\qingning-setup.sh"
echo echo "正在配置青柠OS..." >> "%WORK_DIR%\iso\casper\qingning-seed\qingning-setup.sh"
echo # 复制系统标识 >> "%WORK_DIR%\iso\casper\qingning-seed\qingning-setup.sh"
echo cp /cdrom/casper/qingning-seed/os-release /etc/os-release 2^>/dev/null ^|^| true >> "%WORK_DIR%\iso\casper\qingning-seed\qingning-setup.sh"
echo cp /cdrom/casper/qingning-seed/lsb-release /etc/lsb-release 2^>/dev/null ^|^| true >> "%WORK_DIR%\iso\casper\qingning-seed\qingning-setup.sh"
echo cp /cdrom/casper/qingning-seed/issue /etc/issue 2^>/dev/null ^|^| true >> "%WORK_DIR%\iso\casper\qingning-seed\qingning-setup.sh"
echo cp /cdrom/casper/qingning-seed/issue.net /etc/issue.net 2^>/dev/null ^|^| true >> "%WORK_DIR%\iso\casper\qingning-seed\qingning-setup.sh"
echo # 设置青柠主题 >> "%WORK_DIR%\iso\casper\qingning-seed\qingning-setup.sh"
echo mkdir -p /usr/share/backgrounds/qingning 2^>/dev/null ^|^| true >> "%WORK_DIR%\iso\casper\qingning-seed\qingning-setup.sh"
echo cp /cdrom/casper/qingning-seed/wallpaper.jpg /usr/share/backgrounds/qingning/ 2^>/dev/null ^|^| true >> "%WORK_DIR%\iso\casper\qingning-seed\qingning-setup.sh"
echo # 创建青柠快捷方式 >> "%WORK_DIR%\iso\casper\qingning-seed\qingning-setup.sh"
echo mkdir -p /usr/share/applications/qingning 2^>/dev/null ^|^| true >> "%WORK_DIR%\iso\casper\qingning-seed\qingning-setup.sh"

:: 复制壁纸到种子目录（如果存在）
if exist "%ASSETS_DIR%\qingning-wallpaper.jpg" (
    copy /y "%ASSETS_DIR%\qingning-wallpaper.jpg" "%WORK_DIR%\iso\casper\qingning-seed\wallpaper.jpg" >nul 2>&1
)

echo  [OK] 青柠品牌定制完成

:: ============================================================
:: 修改启动画面（可选）
:: ============================================================
echo.
echo  [步骤 3/5] 修改启动画面...

:: 尝试替换 Plymouth 主题文件
if exist "%ASSETS_DIR%\splash.png" (
    if exist "%WORK_DIR%\iso\boot\grub\splash.png" (
        copy /y "%ASSETS_DIR%\splash.png" "%WORK_DIR%\iso\boot\grub\splash.png" >nul 2>&1
        echo  [OK] 替换启动画面
    )
)

:: ============================================================
:: 生成新的 ISO
:: ============================================================
echo.
echo  [步骤 4/5] 生成青柠OS ISO 镜像...

:: 检查 oscdimg
set "OSCDIMG="
if exist "%TOOLS_DIR%\oscdimg.exe" (
    set "OSCDIMG=%TOOLS_DIR%\oscdimg.exe"
) else if exist "C:\Program Files (x86)\Windows Kits\10\Assessment and Deployment Kit\Deployment Tools\amd64\Oscdimg\oscdimg.exe" (
    set "OSCDIMG=C:\Program Files (x86)\Windows Kits\10\Assessment and Deployment Kit\Deployment Tools\amd64\Oscdimg\oscdimg.exe"
)

if defined OSCDIMG (
    echo  [信息] 使用 oscdimg 生成可启动 ISO...
    "%OSCDIMG%" -m -o -u2 -udfver102 -l"QingningOS-2.0" "%WORK_DIR%\iso" "%OUTPUT_ISO%" >nul 2>&1
    if %errorlevel% equ 0 goto :iso_success
    echo  [警告] oscdimg 失败，尝试备用方案...
)

:: 备用方案：使用 PowerShell 创建 ISO
echo  [信息] 使用 PowerShell 生成 ISO...
powershell -ExecutionPolicy Bypass -Command "
$isoPath = '%OUTPUT_ISO%';
$srcPath = '%WORK_DIR%\iso';
try {
    # 使用 .NET 创建 ISO
    Add-Type -TypeDefinition @'
    using System;
    using System.IO;
    using System.Runtime.InteropServices;
    public class ISOCreator {
        [DllImport("shlwapi.dll", CharSet=CharSet.Unicode)]
        static extern uint SHCreateStreamOnFileEx(string file, uint mode, uint attributes, bool create, IntPtr reserved, out IntPtr stream);
        public static void CreateISO(string srcDir, string isoPath) {
            var files = Directory.GetFiles(srcDir, '*', SearchOption.AllDirectories);
            // 简化实现：使用 7-Zip 创建 ISO
        }
    }
'@ 2>$null;
    # 回退到 7-Zip
    & '%SEVENZIP%' a -tiso '$isoPath' '$srcPath\*' 2>$null;
} catch {}"

if exist "%OUTPUT_ISO%" goto :iso_success

:: 最终备用：创建 ZIP 包
echo  [警告] ISO 生成失败，创建 ZIP 包...
set "OUTPUT_ZIP=%OUTPUT_DIR%\qingning-os-2.0.0-files.zip"
"%SEVENZIP%" a -tzip "%OUTPUT_ZIP%" "%WORK_DIR%\iso\*" >nul 2>&1
echo  [OK] ZIP 包已生成: %OUTPUT_ZIP%
echo  [提示] 请使用 Rufus 的"ISO 模式"或 UltraISO 打开此 ZIP
goto :finish

:iso_success
echo  [OK] ISO 生成成功！

:: ============================================================
:: 完成
:: ============================================================
:finish
echo.
echo  ╔══════════════════════════════════════════════════════════════╗
echo  ║                     构建完成！                               ║
echo  ╚══════════════════════════════════════════════════════════════╝
echo.

if exist "%OUTPUT_ISO%" (
    echo  输出文件: %OUTPUT_ISO%
    for %%F in ("%OUTPUT_ISO%") do (
        echo  文件大小: %%~zF 字节 (约 %%~zF 字节)
        set /a size_mb=%%~zF/1048576
        echo  约 !size_mb! MB
    )
    echo.
    echo  ════════════════════════════════════════════════════════════
    echo  使用方法:
    echo  ════════════════════════════════════════════════════════════
    echo.
    echo  1. VMware:
    echo     创建新虚拟机 → CD/DVD → 使用ISO镜像文件 → 选择此ISO
    echo.
    echo  2. VirtualBox:
    echo     创建新虚拟机 → 存储 → 光驱 → 选择虚拟光盘文件 → 选择此ISO
    echo.
    echo  3. 启动后选择"安装 青柠OS"
    echo.
    echo  ════════════════════════════════════════════════════════════
    echo  安装完成后:
    echo  ════════════════════════════════════════════════════════════
    echo  系统标识会显示为"青柠OS"
    echo  桌面会有青柠网盘/商店/教程的快捷方式
    echo  终端使用青柠配色方案
    echo.
    echo  默认账户:
    echo    用户名: qingning
    echo    密码: qingning
    echo    Root 密码: qingning
) else if exist "%OUTPUT_ZIP%" (
    echo  输出文件: %OUTPUT_ZIP%
    echo.
    echo  [提示] 由于系统限制，生成了 ZIP 文件
    echo  请使用 Rufus (https://rufus.ie) 的"ISO 模式"制作启动盘
)

echo.

:: 清理工作目录
choice /c YN /n /m "是否清理临时文件? (Y/N) "
if %errorlevel% equ 1 (
    rmdir /s /q "%WORK_DIR%"
    echo  临时文件已清理
)

echo.
echo  按任意键退出...
pause >nul
exit /b 0
