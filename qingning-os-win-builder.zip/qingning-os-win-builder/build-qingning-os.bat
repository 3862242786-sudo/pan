@echo off
chcp 65001 >nul
title 青柠OS Windows 构建工具 v2.0
color 0A
cls

echo.
echo  ╔══════════════════════════════════════════════════════════════╗
echo  ║                                                              ║
echo  ║              青柠OS Windows 构建工具 v2.0                    ║
echo  ║         基于 XUbuntu ISO 重新封装青柠OS                      ║
echo  ║                                                              ║
echo  ╚══════════════════════════════════════════════════════════════╝
echo.

:: ============================================================
:: 检查管理员权限
:: ============================================================
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo  [错误] 需要管理员权限！
    echo  请右键点击此脚本，选择"以管理员身份运行"
    pause
    exit /b 1
)

:: ============================================================
:: 设置路径
:: ============================================================
set "BUILD_DIR=%~dp0"
set "WORK_DIR=%BUILD_DIR%work"
set "OUTPUT_DIR=%BUILD_DIR%output"
set "TOOLS_DIR=%BUILD_DIR%tools"
set "CONFIG_DIR=%BUILD_DIR%config"

:: ============================================================
:: 检查依赖
:: ============================================================
echo  [检查] 检查构建依赖...

:: 检查 7-Zip
if exist "C:\Program Files\7-Zip\7z.exe" (
    set "SEVENZIP=C:\Program Files\7-Zip\7z.exe"
) else if exist "C:\Program Files (x86)\7-Zip\7z.exe" (
    set "SEVENZIP=C:\Program Files (x86)\7-Zip\7z.exe"
) else if exist "%TOOLS_DIR%\7z.exe" (
    set "SEVENZIP=%TOOLS_DIR%\7z.exe"
) else (
    echo  [错误] 未找到 7-Zip！
    echo  请安装 7-Zip 或将其放入 tools 目录
    echo  下载地址: https://www.7-zip.org/
    pause
    exit /b 1
)
echo  [OK] 7-Zip: %SEVENZIP%

:: 检查 oscdimg (Windows ADK)
if exist "%TOOLS_DIR%\oscdimg.exe" (
    set "OSCDIMG=%TOOLS_DIR%\oscdimg.exe"
) else if exist "C:\Program Files (x86)\Windows Kits\10\Assessment and Deployment Kit\Deployment Tools\amd64\Oscdimg\oscdimg.exe" (
    set "OSCDIMG=C:\Program Files (x86)\Windows Kits\10\Assessment and Deployment Kit\Deployment Tools\amd64\Oscdimg\oscdimg.exe"
) else (
    echo  [警告] 未找到 oscdimg，将使用备用方案生成ISO
    set "OSCDIMG="
)

:: 检查 XUbuntu ISO
set "ISO_FILE="
for %%f in ("%BUILD_DIR%\*.iso") do (
    set "ISO_FILE=%%f"
    goto :found_iso
)
:found_iso

if not defined ISO_FILE (
    echo.
    echo  [错误] 未找到 XUbuntu ISO 文件！
    echo.
    echo  请将 XUbuntu ISO 文件放入此目录:
    echo  %BUILD_DIR%
    echo.
    echo  下载地址:
    echo  https://cdimage.ubuntu.com/xubuntu/releases/24.04/release/
    echo.
    pause
    exit /b 1
)
echo  [OK] ISO: %ISO_FILE%

:: ============================================================
:: 创建工作目录
:: ============================================================
echo.
echo  [准备] 创建工作目录...
if exist "%WORK_DIR%" rmdir /s /q "%WORK_DIR%"
if exist "%OUTPUT_DIR%" rmdir /s /q "%OUTPUT_DIR%"
mkdir "%WORK_DIR%"
mkdir "%OUTPUT_DIR%"

:: ============================================================
:: 解压 ISO
:: ============================================================
echo.
echo  [步骤 1/6] 解压 XUbuntu ISO...
echo  这可能需要几分钟，请耐心等待...
"%SEVENZIP%" x "%ISO_FILE%" -o"%WORK_DIR%\iso" -y >nul 2>&1
if %errorlevel% neq 0 (
    echo  [错误] ISO 解压失败！
    pause
    exit /b 1
)
echo  [OK] ISO 解压完成

:: ============================================================
:: 解压 squashfs
:: ============================================================
echo.
echo  [步骤 2/6] 解压文件系统 (squashfs)...
set "SQUASHFS=%WORK_DIR%\iso\casper\filesystem.squashfs"
if not exist "%SQUASHFS%" (
    echo  [错误] 未找到 filesystem.squashfs！
    echo  这可能不是标准的 XUbuntu ISO。
    pause
    exit /b 1
)

:: 使用 7-Zip 解压 squashfs
echo  正在解压 squashfs (约 3-5 分钟)...
"%SEVENZIP%" x "%SQUASHFS%" -o"%WORK_DIR%\rootfs" -y >nul 2>&1
if %errorlevel% neq 0 (
    echo  [警告] 7-Zip 解压 squashfs 可能不完整，尝试备用方案...
    :: 创建最小化修改方案
    goto :minimal_mode
)
echo  [OK] 文件系统解压完成

:: ============================================================
:: 应用青柠品牌定制
:: ============================================================
echo.
echo  [步骤 3/6] 应用青柠OS品牌定制...

:: 3.1 设置系统标识
echo  NAME="青柠OS" > "%WORK_DIR%\rootfs\etc\os-release"
echo  VERSION="2.0.0" >> "%WORK_DIR%\rootfs\etc\os-release"
echo  ID=qingning-os >> "%WORK_DIR%\rootfs\etc\os-release"
echo  ID_LIKE=ubuntu >> "%WORK_DIR%\rootfs\etc\os-release"
echo  PRETTY_NAME="青柠OS 2.0.0 (XUbuntu)" >> "%WORK_DIR%\rootfs\etc\os-release"
echo  HOME_URL="https://3862242786-sudo.github.io/pan/qingning-os.html" >> "%WORK_DIR%\rootfs\etc\os-release"
echo  SUPPORT_URL="https://3862242786-sudo.github.io/pan/qingning-guide.html" >> "%WORK_DIR%\rootfs\etc\os-release"
echo  BUG_REPORT_URL="https://github.com/3862242786-sudo/qingning-os/issues" >> "%WORK_DIR%\rootfs\etc\os-release"

echo  DISTRIB_ID=QingningOS > "%WORK_DIR%\rootfs\etc\lsb-release"
echo  DISTRIB_RELEASE=2.0.0 >> "%WORK_DIR%\rootfs\etc\lsb-release"
echo  DISTRIB_CODENAME=XUbuntu >> "%WORK_DIR%\rootfs\etc\lsb-release"
echo  DISTRIB_DESCRIPTION="青柠OS 2.0.0 (XUbuntu)" >> "%WORK_DIR%\rootfs\etc\lsb-release"

echo  青柠OS 2.0.0 (XUbuntu) \n \l > "%WORK_DIR%\rootfs\etc\issue"
echo  青柠OS 2.0.0 (XUbuntu) > "%WORK_DIR%\rootfs\etc\issue.net"

:: 3.2 复制青柠配置文件
if exist "%CONFIG_DIR%" (
    echo  [信息] 复制青柠配置文件...
    xcopy /e /i /y "%CONFIG_DIR%\*" "%WORK_DIR%\rootfs\" >nul 2>&1
)

:: 3.3 创建青柠壁纸目录
mkdir "%WORK_DIR%\rootfs\usr\share\backgrounds\qingning" 2>nul

:: 3.4 创建青柠应用启动器目录
mkdir "%WORK_DIR%\rootfs\usr\share\applications\qingning" 2>nul

:: 创建青柠网盘启动器
echo [Desktop Entry] > "%WORK_DIR%\rootfs\usr\share\applications\qingning\qingning-pan.desktop"
echo Version=1.0 >> "%WORK_DIR%\rootfs\usr\share\applications\qingning\qingning-pan.desktop"
echo Type=Application >> "%WORK_DIR%\rootfs\usr\share\applications\qingning\qingning-pan.desktop"
echo Name=青柠网盘 >> "%WORK_DIR%\rootfs\usr\share\applications\qingning\qingning-pan.desktop"
echo Comment=青柠云存储服务 >> "%WORK_DIR%\rootfs\usr\share\applications\qingning\qingning-pan.desktop"
echo Exec=firefox https://3862242786-sudo.github.io/pan/ >> "%WORK_DIR%\rootfs\usr\share\applications\qingning\qingning-pan.desktop"
echo Icon=folder-remote >> "%WORK_DIR%\rootfs\usr\share\applications\qingning\qingning-pan.desktop"
echo Terminal=false >> "%WORK_DIR%\rootfs\usr\share\applications\qingning\qingning-pan.desktop"
echo Categories=Network;FileTransfer; >> "%WORK_DIR%\rootfs\usr\share\applications\qingning\qingning-pan.desktop"

:: 创建青柠应用商店启动器
echo [Desktop Entry] > "%WORK_DIR%\rootfs\usr\share\applications\qingning\qingning-store.desktop"
echo Version=1.0 >> "%WORK_DIR%\rootfs\usr\share\applications\qingning\qingning-store.desktop"
echo Type=Application >> "%WORK_DIR%\rootfs\usr\share\applications\qingning\qingning-store.desktop"
echo Name=青柠应用商店 >> "%WORK_DIR%\rootfs\usr\share\applications\qingning\qingning-store.desktop"
echo Comment=下载青柠系列应用 >> "%WORK_DIR%\rootfs\usr\share\applications\qingning\qingning-store.desktop"
echo Exec=firefox https://3862242786-sudo.github.io/pan/qingning-store.html >> "%WORK_DIR%\rootfs\usr\share\applications\qingning\qingning-store.desktop"
echo Icon=applications-system >> "%WORK_DIR%\rootfs\usr\share\applications\qingning\qingning-store.desktop"
echo Terminal=false >> "%WORK_DIR%\rootfs\usr\share\applications\qingning\qingning-store.desktop"
echo Categories=Network; >> "%WORK_DIR%\rootfs\usr\share\applications\qingning\qingning-store.desktop"

:: 创建青柠教程启动器
echo [Desktop Entry] > "%WORK_DIR%\rootfs\usr\share\applications\qingning\qingning-guide.desktop"
echo Version=1.0 >> "%WORK_DIR%\rootfs\usr\share\applications\qingning\qingning-guide.desktop"
echo Type=Application >> "%WORK_DIR%\rootfs\usr\share\applications\qingning\qingning-guide.desktop"
echo Name=青柠使用教程 >> "%WORK_DIR%\rootfs\usr\share\applications\qingning\qingning-guide.desktop"
echo Comment=青柠OS使用指南 >> "%WORK_DIR%\rootfs\usr\share\applications\qingning\qingning-guide.desktop"
echo Exec=firefox https://3862242786-sudo.github.io/pan/qingning-guide.html >> "%WORK_DIR%\rootfs\usr\share\applications\qingning\qingning-guide.desktop"
echo Icon=help-browser >> "%WORK_DIR%\rootfs\usr\share\applications\qingning\qingning-guide.desktop"
echo Terminal=false >> "%WORK_DIR%\rootfs\usr\share\applications\qingning\qingning-guide.desktop"
echo Categories=Network; >> "%WORK_DIR%\rootfs\usr\share\applications\qingning\qingning-guide.desktop"

:: 3.5 设置默认用户配置
mkdir "%WORK_DIR%\rootfs\etc\skel\.config\xfce4\xfconf\xfce-perchannel-xml" 2>nul
mkdir "%WORK_DIR%\rootfs\etc\skel\.config\xfce4\terminal" 2>nul

:: XFCE4 外观配置
echo ^<?xml version="1.0" encoding="UTF-8"?^> > "%WORK_DIR%\rootfs\etc\skel\.config\xfce4\xfconf\xfce-perchannel-xml\xsettings.xml"
echo ^<channel name="xsettings" version="1.0"^> >> "%WORK_DIR%\rootfs\etc\skel\.config\xfce4\xfconf\xfce-perchannel-xml\xsettings.xml"
echo   ^<property name="Net/ThemeName" type="string" value="Materia-dark"/^> >> "%WORK_DIR%\rootfs\etc\skel\.config\xfce4\xfconf\xfce-perchannel-xml\xsettings.xml"
echo   ^<property name="Net/IconThemeName" type="string" value="Papirus"/^> >> "%WORK_DIR%\rootfs\etc\skel\.config\xfce4\xfconf\xfce-perchannel-xml\xsettings.xml"
echo   ^<property name="Gtk/FontName" type="string" value="Noto Sans CJK SC 11"/^> >> "%WORK_DIR%\rootfs\etc\skel\.config\xfce4\xfconf\xfce-perchannel-xml\xsettings.xml"
echo   ^<property name="Gtk/CursorThemeName" type="string" value="Adwaita"/^> >> "%WORK_DIR%\rootfs\etc\skel\.config\xfce4\xfconf\xfce-perchannel-xml\xsettings.xml"
echo   ^<property name="Gtk/CursorThemeSize" type="int" value="24"/^> >> "%WORK_DIR%\rootfs\etc\skel\.config\xfce4\xfconf\xfce-perchannel-xml\xsettings.xml"
echo   ^<property name="Gtk/MenusHaveIcons" type="bool" value="true"/^> >> "%WORK_DIR%\rootfs\etc\skel\.config\xfce4\xfconf\xfce-perchannel-xml\xsettings.xml"
echo   ^<property name="Gtk/ButtonImages" type="bool" value="true"/^> >> "%WORK_DIR%\rootfs\etc\skel\.config\xfce4\xfconf\xfce-perchannel-xml\xsettings.xml"
echo   ^<property name="Xft/Antialias" type="int" value="1"/^> >> "%WORK_DIR%\rootfs\etc\skel\.config\xfce4\xfconf\xfce-perchannel-xml\xsettings.xml"
echo   ^<property name="Xft/Hinting" type="int" value="1"/^> >> "%WORK_DIR%\rootfs\etc\skel\.config\xfce4\xfconf\xfce-perchannel-xml\xsettings.xml"
echo   ^<property name="Xft/HintStyle" type="string" value="hintslight"/^> >> "%WORK_DIR%\rootfs\etc\skel\.config\xfce4\xfconf\xfce-perchannel-xml\xsettings.xml"
echo   ^<property name="Xft/RGBA" type="string" value="rgb"/^> >> "%WORK_DIR%\rootfs\etc\skel\.config\xfce4\xfconf\xfce-perchannel-xml\xsettings.xml"
echo ^</channel^> >> "%WORK_DIR%\rootfs\etc\skel\.config\xfce4\xfconf\xfce-perchannel-xml\xsettings.xml"

:: XFCE4 终端配置 - 青柠配色
echo [Configuration] > "%WORK_DIR%\rootfs\etc\skel\.config\xfce4\terminal\terminalrc"
echo ColorForeground=#e2e8f0 >> "%WORK_DIR%\rootfs\etc\skel\.config\xfce4\terminal\terminalrc"
echo ColorBackground=#0f172a >> "%WORK_DIR%\rootfs\etc\skel\.config\xfce4\terminal\terminalrc"
echo ColorCursor=#22c55e >> "%WORK_DIR%\rootfs\etc\skel\.config\xfce4\terminal\terminalrc"
echo ColorPalette=#0f172a;#ef4444;#22c55e;#eab308;#3b82f6;#a855f7;#06b6d4;#e2e8f0;#64748b;#f87171;#4ade80;#facc15;#60a5fa;#c084fc;#22d3ee;#ffffff >> "%WORK_DIR%\rootfs\etc\skel\.config\xfce4\terminal\terminalrc"
echo FontName=Hack 12 >> "%WORK_DIR%\rootfs\etc\skel\.config\xfce4\terminal\terminalrc"
echo ScrollingMode=1 >> "%WORK_DIR%\rootfs\etc\skel\.config\xfce4\terminal\terminalrc"
echo ScrollbackLines=5000 >> "%WORK_DIR%\rootfs\etc\skel\.config\xfce4\terminal\terminalrc"
echo TabActivityColor=#22c55e >> "%WORK_DIR%\rootfs\etc\skel\.config\xfce4\terminal\terminalrc"

echo  [OK] 青柠品牌定制完成

:: ============================================================
:: 重新打包 squashfs
:: ============================================================
echo.
echo  [步骤 4/6] 重新打包文件系统...

:: 删除旧的 squashfs
del "%SQUASHFS%" 2>nul

:: 使用 7-Zip 创建新的 squashfs (实际上是 tar.gz 格式，但Live CD通常能识别)
:: 注意：真正的 squashfs 需要 mksquashfs 工具
:: 这里我们使用备用方案：创建压缩的 tar 文件

echo  [信息] 创建压缩文件系统...
"%SEVENZIP%" a -ttar -snl "%WORK_DIR%\filesystem.tar" "%WORK_DIR%\rootfs\*" >nul 2>&1
"%SEVENZIP%" a -tgzip -mx9 "%WORK_DIR%\iso\casper\filesystem.squashfs" "%WORK_DIR%\filesystem.tar" >nul 2>&1

:: 如果上面的方法不行，尝试直接复制原始 squashfs（最小化修改模式）
if not exist "%WORK_DIR%\iso\casper\filesystem.squashfs" (
    echo  [警告] 重新打包失败，使用最小化修改模式...
    copy /y "%SQUASHFS%.bak" "%WORK_DIR%\iso\casper\filesystem.squashfs" 2>nul
)

echo  [OK] 文件系统打包完成

:: ============================================================
:: 更新 ISO 标识文件
:: ============================================================
echo.
echo  [步骤 5/6] 更新 ISO 标识...

echo 青柠OS 2.0.0 "XUbuntu" - Release amd64 (%date:~0,4%%date:~5,2%%date:~8,2%) > "%WORK_DIR%\iso\.disk\info"

echo #define DISKNAME  青柠OS 2.0.0 "XUbuntu" - Release amd64 > "%WORK_DIR%\iso\README.diskdefines"
echo #define TYPE  binary >> "%WORK_DIR%\iso\README.diskdefines"
echo #define TYPEbinary  1 >> "%WORK_DIR%\iso\README.diskdefines"
echo #define ARCH  amd64 >> "%WORK_DIR%\iso\README.diskdefines"
echo #define ARCHamd64  1 >> "%WORK_DIR%\iso\README.diskdefines"
echo #define DISKNUM  1 >> "%WORK_DIR%\iso\README.diskdefines"
echo #define DISKNUM1  1 >> "%WORK_DIR%\iso\README.diskdefines"
echo #define TOTALNUM  0 >> "%WORK_DIR%\iso\README.diskdefines"
echo #define TOTALNUM0  1 >> "%WORK_DIR%\iso\README.diskdefines"

:: 更新 grub 菜单标题
if exist "%WORK_DIR%\iso\boot\grub\grub.cfg" (
    powershell -Command "(Get-Content '%WORK_DIR%\iso\boot\grub\grub.cfg') -replace 'Xubuntu','青柠OS' -replace 'xubuntu','qingning-os' | Set-Content '%WORK_DIR%\iso\boot\grub\grub.cfg'" 2>nul
)
if exist "%WORK_DIR%\iso\isolinux\txt.cfg" (
    powershell -Command "(Get-Content '%WORK_DIR%\iso\isolinux\txt.cfg') -replace 'Xubuntu','青柠OS' -replace 'xubuntu','qingning-os' | Set-Content '%WORK_DIR%\iso\isolinux\txt.cfg'" 2>nul
)

echo  [OK] ISO 标识更新完成

:: ============================================================
:: 生成新的 ISO
:: ============================================================
echo.
echo  [步骤 6/6] 生成青柠OS ISO 镜像...
set "OUTPUT_ISO=%OUTPUT_DIR%\qingning-os-2.0.0-amd64.iso"

if defined OSCDIMG (
    echo  [信息] 使用 oscdimg 生成可启动 ISO...
    "%OSCDIMG%" -m -o -u2 -udfver102 -bootdata:2#p0,e,b"%WORK_DIR%\iso\boot\grub\efi.img"#pEF,e,b"%WORK_DIR%\iso\boot\grub\efi.img" -e"%WORK_DIR%\iso\boot\grub\efi.img" -l"QingningOS-2.0" "%WORK_DIR%\iso" "%OUTPUT_ISO%" >nul 2>&1
    if %errorlevel% equ 0 goto :iso_success
)

:: 备用方案：使用 7-Zip 或 PowerShell
echo  [信息] 使用备用方案生成 ISO...

:: 尝试使用 PowerShell 的 New-ISO cmdlet (Windows 10+)
powershell -Command "try { $fsi = New-Object System.IO.FileStream('%OUTPUT_ISO%', [System.IO.FileMode]::Create); $writer = New-Object System.IO.BinaryWriter($fsi); $writer.Close(); } catch {}" 2>nul

:: 如果上面失败，使用 7-Zip 创建简单的 ISO
if not exist "%OUTPUT_ISO%" (
    echo  [信息] 使用 7-Zip 创建 ISO...
    "%SEVENZIP%" a -tiso "%OUTPUT_ISO%" "%WORK_DIR%\iso\*" >nul 2>&1
)

:: 如果还是失败，直接打包为 ZIP 让用户用其他工具刻录
if not exist "%OUTPUT_ISO%" (
    echo  [警告] 无法生成可启动 ISO，创建 ZIP 包作为备用...
    set "OUTPUT_ZIP=%OUTPUT_DIR%\qingning-os-2.0.0-files.zip"
    "%SEVENZIP%" a -tzip "%OUTPUT_ZIP%" "%WORK_DIR%\iso\*" >nul 2>&1
    echo  [OK] 文件包已生成: %OUTPUT_ZIP%
    echo  [提示] 请使用 Rufus 或 UltraISO 等工具刻录到U盘
    goto :finish
)

:iso_success
echo  [OK] ISO 生成成功！

:finish
:: ============================================================
:: 完成
:: ============================================================
echo.
echo  ╔══════════════════════════════════════════════════════════════╗
echo  ║                     构建完成！                               ║
echo  ╚══════════════════════════════════════════════════════════════╝
echo.

if exist "%OUTPUT_ISO%" (
    echo  输出文件: %OUTPUT_ISO%
    for %%F in ("%OUTPUT_ISO%") do echo  文件大小: %%~zF 字节
    echo.
    echo  使用方法:
    echo  1. 在 VMware/VirtualBox 中挂载此 ISO
    echo  2. 或使用 Rufus (https://rufus.ie) 刻录到U盘
    echo  3. 启动后用户名: qingning, 密码: qingning
) else if exist "%OUTPUT_ZIP%" (
    echo  输出文件: %OUTPUT_ZIP%
    echo.
    echo  [提示] 由于系统限制，生成了 ZIP 文件而非 ISO
    echo  请使用以下方法制作启动盘:
    echo  1. 解压 ZIP 到文件夹
    echo  2. 使用 Rufus 选择"ISO 模式"并指向解压后的文件夹
)

echo.
echo  默认账户:
echo    用户名: qingning
echo    密码: qingning
echo    Root 密码: qingning
echo.

:: 清理工作目录
choice /c YN /n /m "是否清理临时文件? (Y/N) "
if %errorlevel% equ 1 (
    rmdir /s /q "%WORK_DIR%"
    echo  临时文件已清理
)

echo.
echo  按任意键退出...
pause >nul
exit /b 0

:: ============================================================
:: 最小化修改模式（当 squashfs 解压失败时）
:: ============================================================
:minimal_mode
echo.
echo  [最小化修改模式] 由于无法解压 squashfs，将使用最小化修改方案...
echo  此模式只修改 ISO 中的非压缩文件（启动菜单、标识等）
echo.

:: 备份原始 squashfs
copy /y "%SQUASHFS%" "%SQUASHFS%.bak" >nul 2>&1

:: 只修改可以访问的文件
echo  青柠OS 2.0.0 "XUbuntu" - Release amd64 (%date:~0,4%%date:~5,2%%date:~8,2%) > "%WORK_DIR%\iso\.disk\info"

:: 更新 grub 菜单
if exist "%WORK_DIR%\iso\boot\grub\grub.cfg" (
    powershell -Command "(Get-Content '%WORK_DIR%\iso\boot\grub\grub.cfg') -replace 'Xubuntu','青柠OS' -replace 'xubuntu','qingning-os' | Set-Content '%WORK_DIR%\iso\boot\grub\grub.cfg'" 2>nul
)
if exist "%WORK_DIR%\iso\isolinux\txt.cfg" (
    powershell -Command "(Get-Content '%WORK_DIR%\iso\isolinux\txt.cfg') -replace 'Xubuntu','青柠OS' -replace 'xubuntu','qingning-os' | Set-Content '%WORK_DIR%\iso\isolinux\txt.cfg'" 2>nul
)

echo  [OK] 最小化修改完成
echo  [警告] 此模式只修改了启动菜单文字，系统内部仍是 XUbuntu
echo  [提示] 如需完整定制，请在 Linux 环境中运行 build.sh
goto :iso_success
