# ============================================================
# 青柠OS 统一构建脚本 v3.0
# Build-QingningOS.ps1
# 支持: Alex版 (Linux内核+自主GUI) | Windows版 (Windows封装)
# 运行环境: Windows 10/11 PowerShell 5.1+
# ============================================================

param(
    [string]$Version = "",  # "alex" 或 "windows"
    [string]$OutputDir = "",
    [string]$WindowsISO = ""  # Windows版需要: 原始Windows ISO路径
)

$ErrorActionPreference = "Stop"
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
if ([string]::IsNullOrEmpty($OutputDir)) { $OutputDir = Join-Path $scriptDir "output" }

# 颜色输出
function Write-Color($text, $color) {
    $old = $host.UI.RawUI.ForegroundColor
    $host.UI.RawUI.ForegroundColor = $color
    Write-Host $text
    $host.UI.RawUI.ForegroundColor = $old
}

function Write-Title($text) {
    Write-Host ""
    Write-Color "============================================================" "Cyan"
    Write-Color "  $text" "Cyan"
    Write-Color "============================================================" "Cyan"
    Write-Host ""
}

function Write-Info($text) { Write-Color "[INFO] $text" "White" }
function Write-Success($text) { Write-Color "[OK] $text" "Green" }
function Write-Warning($text) { Write-Color "[WARN] $text" "Yellow" }
function Write-Error($text) { Write-Color "[ERROR] $text" "Red" }

# 检查依赖
function Test-Dependency($cmd, $name) {
    $found = Get-Command $cmd -ErrorAction SilentlyContinue
    if (-not $found) {
        Write-Error "$name 未找到，请先安装"
        return $false
    }
    Write-Success "$name 已找到: $($found.Source)"
    return $true
}

# 下载文件（带重试）
function Download-File($url, $outfile, $maxRetries = 3) {
    $dir = Split-Path -Parent $outfile
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    
    for ($i = 1; $i -le $maxRetries; $i++) {
        try {
            Write-Info "下载: $url (尝试 $i/$maxRetries)"
            Invoke-WebRequest -Uri $url -OutFile $outfile -UseBasicParsing -TimeoutSec 120
            if (Test-Path $outfile) {
                Write-Success "下载完成: $([math]::Round((Get-Item $outfile).Length / 1KB, 1)) KB"
                return $true
            }
        } catch {
            Write-Warning "下载失败: $($_.Exception.Message)"
            Start-Sleep -Seconds 2
        }
    }
    return $false
}

# ============================================================
# Alex版构建 - 真正的Linux操作系统
# ============================================================
function Build-AlexVersion {
    Write-Title "构建青柠OS Alex版 (Linux内核 + 自主GUI)"
    
    $alexDir = Join-Path $OutputDir "alex-build"
    $isoDir = Join-Path $alexDir "iso"
    $kernelDir = Join-Path $alexDir "kernel"
    $rootfsDir = Join-Path $alexDir "rootfs"
    $isoFile = Join-Path $OutputDir "QingningOS-Alex-v3.0.iso"
    
    # 清理并创建目录
    if (Test-Path $alexDir) { Remove-Item -Recurse -Force $alexDir }
    New-Item -ItemType Directory -Path $isoDir, $kernelDir, $rootfsDir -Force | Out-Null
    New-Item -ItemType Directory -Path (Join-Path $isoDir "boot") -Force | Out-Null
    
    # 1. 下载 Alpine Linux 内核和initramfs
    Write-Title "步骤 1/6: 下载 Alpine Linux 内核"
    $baseUrl = "https://dl-cdn.alpinelinux.org/alpine/v3.19/releases/x86_64"
    $kernelUrl = "$baseUrl/netboot/vmlinuz-virt"
    $initrdUrl = "$baseUrl/netboot/initramfs-virt"
    $modloopUrl = "$baseUrl/netboot/modloop-virt"
    
    $kernelFile = Join-Path $kernelDir "vmlinuz-virt"
    $initrdFile = Join-Path $kernelDir "initramfs-virt"
    $modloopFile = Join-Path $kernelDir "modloop-virt"
    
    $dl1 = Download-File $kernelUrl $kernelFile
    $dl2 = Download-File $initrdUrl $initrdFile
    $dl3 = Download-File $modloopUrl $modloopFile
    
    if (-not ($dl1 -and $dl2)) {
        Write-Error "内核下载失败，尝试备用源..."
        $baseUrl2 = "https://mirrors.tuna.tsinghua.edu.cn/alpine/v3.19/releases/x86_64"
        $dl1 = Download-File "$baseUrl2/netboot/vmlinuz-virt" $kernelFile
        $dl2 = Download-File "$baseUrl2/netboot/initramfs-virt" $initrdFile
        if (-not ($dl1 -and $dl2)) {
            Write-Error "无法下载Linux内核，构建失败"
            exit 1
        }
    }
    
    # 2. 构建根文件系统
    Write-Title "步骤 2/6: 构建根文件系统"
    
    # 创建基本目录结构
    $dirs = @("bin", "sbin", "usr/bin", "usr/sbin", "lib", "lib64", "etc", "var", "tmp", 
              "proc", "sys", "dev", "mnt", "root", "home/qingning", "run", "opt")
    foreach ($d in $dirs) {
        New-Item -ItemType Directory -Path (Join-Path $rootfsDir $d) -Force | Out-Null
    }
    
    # 下载静态编译的busybox
    Write-Info "下载 BusyBox..."
    $busyboxUrl = "https://busybox.net/downloads/binaries/1.36.0-x86_64-linux-musl/busybox"
    $busyboxFile = Join-Path $rootfsDir "bin/busybox"
    if (-not (Download-File $busyboxUrl $busyboxFile)) {
        Write-Warning "BusyBox下载失败，将使用initramfs自带工具"
    } else {
        # 创建常用命令链接
        $cmds = @("sh", "bash", "ls", "cat", "cp", "mv", "rm", "mkdir", "rmdir", 
                  "echo", "printf", "grep", "awk", "sed", "ps", "top", "kill", "mount",
                  "umount", "df", "du", "chmod", "chown", "ln", "touch", "find",
                  "vi", "vim", "clear", "reset", "reboot", "poweroff", "halt",
                  "ifconfig", "route", "ping", "wget", "tar", "gzip", "gunzip",
                  "init", "getty", "login", "passwd", "whoami", "uname", "hostname",
                  "date", "sleep", "usleep", "true", "false", "yes", "seq",
                  "cut", "sort", "uniq", "head", "tail", "tee", "xargs", "which",
                  "free", "uptime", "dmesg", "lsmod", "insmod", "rmmod", "modprobe",
                  "mknod", "mdev", "switch_root", "pivot_root")
        foreach ($cmd in $cmds) {
            $link = Join-Path $rootfsDir "bin/$cmd"
            if (-not (Test-Path $link)) {
                cmd /c "mklink `"$link`" `"$busyboxFile`"" 2>$null | Out-Null
                if (-not (Test-Path $link)) {
                    Copy-Item $busyboxFile $link -Force 2>$null | Out-Null
                }
            }
        }
    }
    
    # 3. 编译青柠桌面环境
    Write-Title "步骤 3/6: 编译青柠桌面环境"
    $srcDir = Join-Path $scriptDir "src"
    $desktopSrc = Join-Path $srcDir "qingning-desktop.c"
    $desktopBin = Join-Path $rootfsDir "usr/bin/qingning-desktop"
    
    if (Test-Path $desktopSrc) {
        # 检查是否有交叉编译器
        $hasMusl = Get-Command "x86_64-linux-musl-gcc" -ErrorAction SilentlyContinue
        $hasGcc = Get-Command "gcc" -ErrorAction SilentlyContinue
        $hasClang = Get-Command "clang" -ErrorAction SilentlyContinue
        
        if ($hasMusl) {
            Write-Info "使用 musl-gcc 静态编译..."
            & $hasMusl.Source -O2 -static -o $desktopBin $desktopSrc 2>&1
        } elseif ($hasGcc) {
            Write-Info "使用 gcc 编译（建议安装 musl-gcc 进行静态链接）..."
            & $hasGcc.Source -O2 -o $desktopBin $desktopSrc 2>&1
        } elseif ($hasClang) {
            Write-Info "使用 clang 编译..."
            & $hasClang.Source -O2 -o $desktopBin $desktopSrc 2>&1
        } else {
            Write-Warning "未找到编译器，将使用预编译二进制文件（如果有）"
        }
        
        if (Test-Path $desktopBin) {
            Write-Success "青柠桌面编译成功"
        } else {
            Write-Warning "编译失败，系统将以文本模式启动"
        }
    } else {
        Write-Warning "未找到桌面源代码: $desktopSrc"
    }
    
    # 4. 创建系统配置文件
    Write-Title "步骤 4/6: 创建系统配置"
    
    # /etc/inittab
    @"
# 青柠OS /etc/inittab
::sysinit:/etc/init.d/rcS
::respawn:/sbin/getty 38400 tty1
::respawn:/sbin/getty 38400 tty2
::respawn:/sbin/getty 38400 tty3
::ctrlaltdel:/sbin/reboot
::shutdown:/sbin/poweroff
"@ | Set-Content -Path (Join-Path $rootfsDir "etc/inittab") -Encoding UTF8 -NoNewline
    
    # /etc/init.d/rcS
    $rcs = @'
#!/bin/sh
# 青柠OS 系统初始化

echo "[青柠OS] 正在启动系统..."

# 挂载文件系统
mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev
mount -t tmpfs tmpfs /tmp
mount -t tmpfs tmpfs /run

# 创建设备节点
mknod -m 666 /dev/null c 1 3 2>/dev/null
mknod -m 666 /dev/zero c 1 5 2>/dev/null
mknod -m 666 /dev/random c 1 8 2>/dev/null
mknod -m 666 /dev/urandom c 1 9 2>/dev/null
mknod -m 666 /dev/tty c 5 0 2>/dev/null
mknod -m 666 /dev/tty0 c 4 0 2>/dev/null
mknod -m 666 /dev/tty1 c 4 1 2>/dev/null
mknod -m 666 /dev/console c 5 1 2>/dev/null
mknod -m 666 /dev/fb0 c 29 0 2>/dev/null

# 网络
ifconfig lo 127.0.0.1 up 2>/dev/null

# 主机名
hostname QingningOS-Alex

# 创建用户目录
mkdir -p /home/qingning/Desktop
mkdir -p /home/qingning/Documents
chown -R 1000:1000 /home/qingning 2>/dev/null

# 启动桌面环境（如果存在且支持帧缓冲）
if [ -x /usr/bin/qingning-desktop ]; then
    echo "[青柠OS] 启动图形界面..."
    export TERM=linux
    /usr/bin/qingning-desktop &
fi

echo "[青柠OS] 系统启动完成"
'@
    $rcs | Set-Content -Path (Join-Path $rootfsDir "etc/init.d/rcS") -Encoding UTF8 -NoNewline
    
    # /etc/passwd
    @"
root:x:0:0:root:/root:/bin/sh
qingning:x:1000:1000:Qingning User:/home/qingning:/bin/sh
"@ | Set-Content -Path (Join-Path $rootfsDir "etc/passwd") -Encoding UTF8 -NoNewline
    
    # /etc/shadow
    @"
root::0:0:99999:7:::
qingning::0:0:99999:7:::
"@ | Set-Content -Path (Join-Path $rootfsDir "etc/shadow") -Encoding UTF8 -NoNewline
    
    # /etc/group
    @"
root:x:0:
qingning:x:1000:
"@ | Set-Content -Path (Join-Path $rootfsDir "etc/group") -Encoding UTF8 -NoNewline
    
    # /etc/hostname
    "QingningOS-Alex" | Set-Content -Path (Join-Path $rootfsDir "etc/hostname") -Encoding UTF8 -NoNewline
    
    # /etc/motd
    @"

    青柠OS Alex版 v3.0
    ==================
    基于 Linux Kernel + 自主GUI
    
    命令: 
      qingning-desktop  启动图形界面
      reboot            重启
      poweroff          关机

"@ | Set-Content -Path (Join-Path $rootfsDir "etc/motd") -Encoding UTF8 -NoNewline
    
    # 5. 打包根文件系统
    Write-Title "步骤 5/6: 打包根文件系统"
    $rootfsCpio = Join-Path $kernelDir "rootfs.cpio.gz"
    
    # 使用7z或PowerShell压缩
    $sevenZip = Get-Command "7z" -ErrorAction SilentlyContinue
    if (-not $sevenZip) { $sevenZip = Get-Command "7za" -ErrorAction SilentlyContinue }
    
    if ($sevenZip) {
        Write-Info "使用 7-Zip 创建 CPIO 归档..."
        # 先创建tar，然后转cpio（简化处理，直接用tar.gz）
        Push-Location $rootfsDir
        & $sevenZip.Source "a" "-ttar" (Join-Path $kernelDir "rootfs.tar") "*" | Out-Null
        Pop-Location
        if (Test-Path (Join-Path $kernelDir "rootfs.tar")) {
            & $sevenZip.Source "a" "-tgzip" $rootfsCpio (Join-Path $kernelDir "rootfs.tar") | Out-Null
            Remove-Item (Join-Path $kernelDir "rootfs.tar") -Force
        }
    } else {
        Write-Warning "未找到 7-Zip，尝试使用 PowerShell 压缩..."
        Compress-Archive -Path "$rootfsDir\*" -DestinationPath (Join-Path $kernelDir "rootfs.zip") -Force
    }
    
    # 6. 创建启动配置和ISO
    Write-Title "步骤 6/6: 创建可启动ISO"
    
    # 复制内核文件到iso/boot
    Copy-Item $kernelFile (Join-Path $isoDir "boot/vmlinuz") -Force
    Copy-Item $initrdFile (Join-Path $isoDir "boot/initrd.img") -Force
    if (Test-Path $modloopFile) {
        Copy-Item $modloopFile (Join-Path $isoDir "boot/modloop") -Force
    }
    if (Test-Path $rootfsCpio) {
        Copy-Item $rootfsCpio (Join-Path $isoDir "boot/rootfs.cpio.gz") -Force
    }
    
    # 创建 ISOLINUX 配置
    $isolinuxDir = Join-Path $isoDir "isolinux"
    New-Item -ItemType Directory -Path $isolinuxDir -Force | Out-Null
    
    # isolinux.cfg
    @"
DEFAULT qingning
TIMEOUT 50
PROMPT 1

MENU TITLE 青柠OS Alex版 v3.0 启动菜单
MENU COLOR border       30;44   #40ffffff #a0000000 std
MENU COLOR title        1;36;44 #9033ccff #a0000000 std
MENU COLOR sel          7;37;40 #e0ffffff #20ffffff all
MENU COLOR unsel        37;44   #50ffffff #a0000000 std

LABEL qingning
    MENU LABEL ^1. 启动 青柠OS (图形界面)
    KERNEL /boot/vmlinuz
    APPEND initrd=/boot/initrd.img root=/dev/ram0 rw quiet console=tty1

LABEL qingning-text
    MENU LABEL ^2. 启动 青柠OS (文本模式)
    KERNEL /boot/vmlinuz
    APPEND initrd=/boot/initrd.img root=/dev/ram0 rw text console=tty1

LABEL qingning-debug
    MENU LABEL ^3. 启动 青柠OS (调试模式)
    KERNEL /boot/vmlinuz
    APPEND initrd=/boot/initrd.img root=/dev/ram0 rw debug console=tty1

LABEL memtest
    MENU LABEL ^4. 内存测试 (Memtest86+)
    KERNEL /boot/memtest

LABEL local
    MENU LABEL ^5. 从硬盘启动
    LOCALBOOT 0x80
"@ | Set-Content -Path (Join-Path $isolinuxDir "isolinux.cfg") -Encoding UTF8
    
    # 下载 isolinux 二进制文件
    Write-Info "下载 ISOLINUX 引导文件..."
    $isolinuxBinUrl = "https://mirrors.edge.kernel.org/pub/linux/utils/boot/syslinux/syslinux-6.03.tar.gz"
    $syslinuxTar = Join-Path $alexDir "syslinux.tar.gz"
    
    # 简化：创建基本的 El Torito 启动 ISO
    # 使用 oscdimg 或 替代方案
    $oscdimg = Get-Command "oscdimg" -ErrorAction SilentlyContinue
    if (-not $oscdimg) {
        # 尝试从 Windows ADK 找
        $adkPaths = @(
            "${env:ProgramFiles(x86)}\Windows Kits\10\Assessment and Deployment Kit\Deployment Tools\x86\Oscdimg\oscdimg.exe",
            "${env:ProgramFiles(x86)}\Windows Kits\10\Assessment and Deployment Kit\Deployment Tools\amd64\Oscdimg\oscdimg.exe",
            "${env:ProgramFiles}\Windows Kits\10\Assessment and Deployment Kit\Deployment Tools\amd64\Oscdimg\oscdimg.exe"
        )
        foreach ($p in $adkPaths) { if (Test-Path $p) { $oscdimg = Get-Command $p; break } }
    }
    
    if ($oscdimg) {
        Write-Info "使用 oscdimg 创建 ISO..."
        & $oscdimg.Source -n -b$isolinuxDir\isolinux.bin -m -o $isoDir $isoFile 2>&1 | Out-Null
    } else {
        Write-Warning "未找到 oscdimg，尝试使用 PowerShell + 7-Zip 方案..."
        # 使用 7z 创建 ISO（简化版）
        if ($sevenZip) {
            & $sevenZip.Source "a" "-tiso" $isoFile "$isoDir\*" | Out-Null
        } else {
            # 最后的备选：创建 ZIP 包，用户可用其他工具转ISO
            $zipFile = [System.IO.Path]::ChangeExtension($isoFile, ".zip")
            Compress-Archive -Path "$isoDir\*" -DestinationPath $zipFile -Force
            Write-Warning "已创建 ZIP 包: $zipFile"
            Write-Warning "请使用 Rufus/UltraISO 等工具制作可启动U盘"
        }
    }
    
    # 检查结果
    if ((Test-Path $isoFile) -and (Get-Item $isoFile).Length -gt 1000000) {
        $size = [math]::Round((Get-Item $isoFile).Length / 1MB, 2)
        Write-Success "Alex版构建完成!"
        Write-Info "输出文件: $isoFile"
        Write-Info "文件大小: $size MB"
        Write-Info ""
        Write-Info "启动方式:"
        Write-Info "  1. 虚拟机: 直接挂载ISO启动"
        Write-Info "  2. 实体机: 使用 Rufus/Ventoy 写入U盘"
        Write-Info ""
        Write-Info "默认账号: root (无密码) / qingning (无密码)"
    } else {
        Write-Error "ISO 创建失败"
        exit 1
    }
    
    # 清理
    if (Test-Path $alexDir) { Remove-Item -Recurse -Force $alexDir }
}

# ============================================================
# Windows版构建 - 基于Windows ISO封装
# ============================================================
function Build-WindowsVersion {
    param([string]$SourceISO)
    
    Write-Title "构建青柠OS Windows版 (基于 Windows 10/11 ISO)"
    
    if (-not (Test-Path $SourceISO)) {
        Write-Error "未找到Windows ISO文件: $SourceISO"
        Write-Info "请提供Windows 10/11原版ISO文件路径"
        Write-Info "示例: .\Build-QingningOS.ps1 -Version windows -WindowsISO `"C:\Win11.iso`""
        exit 1
    }
    
    $winDir = Join-Path $OutputDir "windows-build"
    $isoDir = Join-Path $winDir "iso"
    $isoFile = Join-Path $OutputDir "QingningOS-Windows-v3.0.iso"
    
    if (Test-Path $winDir) { Remove-Item -Recurse -Force $winDir }
    New-Item -ItemType Directory -Path $isoDir -Force | Out-Null
    
    # 1. 挂载或解压ISO
    Write-Title "步骤 1/4: 提取 Windows ISO 内容"
    
    $sevenZip = Get-Command "7z" -ErrorAction SilentlyContinue
    if (-not $sevenZip) { $sevenZip = Get-Command "7za" -ErrorAction SilentlyContinue }
    
    if ($sevenZip) {
        Write-Info "使用 7-Zip 提取 ISO..."
        & $sevenZip.Source "x" $SourceISO "-o$isoDir" -y | Out-Null
    } else {
        Write-Info "尝试挂载 ISO..."
        $mountResult = Mount-DiskImage -ImagePath $SourceISO -PassThru
        $driveLetter = ($mountResult | Get-Volume).DriveLetter
        if ($driveLetter) {
            Write-Info "ISO 已挂载到 ${driveLetter}:"
            Copy-Item "${driveLetter}:\*" $isoDir -Recurse -Force
            Dismount-DiskImage -ImagePath $SourceISO | Out-Null
        } else {
            Write-Error "无法提取ISO内容，请安装 7-Zip"
            exit 1
        }
    }
    
    Write-Success "ISO 内容已提取"
    
    # 2. 注入青柠OS配置
    Write-Title "步骤 2/4: 注入青柠OS配置"
    
    # 复制 autounattend.xml
    $autoUnattend = Join-Path $scriptDir "config\autounattend.xml"
    if (Test-Path $autoUnattend) {
        Copy-Item $autoUnattend (Join-Path $isoDir "autounattend.xml") -Force
        Write-Success "已注入无人值守安装配置"
    } else {
        Write-Warning "未找到 autounattend.xml"
    }
    
    # 创建 QingningOS 目录并复制脚本
    $qnDir = Join-Path $isoDir "QingningOS"
    New-Item -ItemType Directory -Path $qnDir -Force | Out-Null
    
    $setupBat = Join-Path $scriptDir "assets\qingning-setup.bat"
    if (Test-Path $setupBat) {
        Copy-Item $setupBat (Join-Path $qnDir "qingning-setup.bat") -Force
        Write-Success "已注入首次启动脚本"
    }
    
    # 创建 OEM 信息文件
    @"
[Version]
Signature="$Windows NT$"

[OEMInfo]
Manufacturer=青柠OS
Model=QingningOS 3.0
Logo=%SystemRoot%\System32\oobe\info\qingning.bmp
SupportURL=https://3862242786-sudo.github.io/pan/qingning-os.html
SupportHours=24x7
SupportPhone=+86-400-QINGNING
"@ | Set-Content -Path (Join-Path $qnDir "oeminfo.ini") -Encoding UTF8
    
    # 3. 修改启动菜单（如果存在）
    Write-Title "步骤 3/4: 自定义启动界面"
    
    $bootDir = Join-Path $isoDir "sources"
    if (Test-Path $bootDir) {
        Write-Info "检测到标准 Windows 安装结构"
        # 可以在这里修改 boot.wim 等
    }
    
    # 4. 重新打包ISO
    Write-Title "步骤 4/4: 重新打包 ISO"
    
    $oscdimg = Get-Command "oscdimg" -ErrorAction SilentlyContinue
    if (-not $oscdimg) {
        $adkPaths = @(
            "${env:ProgramFiles(x86)}\Windows Kits\10\Assessment and Deployment Kit\Deployment Tools\x86\Oscdimg\oscdimg.exe",
            "${env:ProgramFiles(x86)}\Windows Kits\10\Assessment and Deployment Kit\Deployment Tools\amd64\Oscdimg\oscdimg.exe",
            "${env:ProgramFiles}\Windows Kits\10\Assessment and Deployment Kit\Deployment Tools\amd64\Oscdimg\oscdimg.exe"
        )
        foreach ($p in $adkPaths) { if (Test-Path $p) { $oscdimg = Get-Command $p; break } }
    }
    
    if ($oscdimg) {
        Write-Info "使用 oscdimg 创建 ISO..."
        # 获取原ISO的启动文件
        $etfsboot = Join-Path $isoDir "boot\etfsboot.com"
        $efsboot = Join-Path $isoDir "efi\microsoft\boot\efisys.bin"
        
        $bootData = if (Test-Path $etfsboot) { "-b$etfsboot" } else { "" }
        
        & $oscdimg.Source -n -m -o $bootData -u2 -udfver102 $isoDir $isoFile 2>&1 | Out-Null
    } elseif ($sevenZip) {
        Write-Warning "使用 7-Zip 创建 ISO（可能丢失启动信息）..."
        & $sevenZip.Source "a" "-tiso" $isoFile "$isoDir\*" | Out-Null
    } else {
        $zipFile = [System.IO.Path]::ChangeExtension($isoFile, ".zip")
        Compress-Archive -Path "$isoDir\*" -DestinationPath $zipFile -Force
        Write-Warning "已创建 ZIP 包: $zipFile"
    }
    
    # 检查结果
    if ((Test-Path $isoFile) -and (Get-Item $isoFile).Length -gt 100000000) {
        $size = [math]::Round((Get-Item $isoFile).Length / 1MB, 2)
        Write-Success "Windows版构建完成!"
        Write-Info "输出文件: $isoFile"
        Write-Info "文件大小: $size MB"
        Write-Info ""
        Write-Info "安装说明:"
        Write-Info "  1. 刻录ISO到U盘或挂载到虚拟机"
        Write-Info "  2. 自动安装，无需手动操作"
        Write-Info "  3. 首次启动自动应用青柠主题"
        Write-Info ""
        Write-Info "默认账号: qingning / 密码: qingning"
    } else {
        Write-Error "ISO 创建失败"
        exit 1
    }
    
    # 清理
    if (Test-Path $winDir) { Remove-Item -Recurse -Force $winDir }
}

# ============================================================
# 主菜单
# ============================================================
function Show-Menu {
    Clear-Host
    Write-Host ""
    Write-Color "    ╔═══════════════════════════════════════════════════════╗" "Green"
    Write-Color "    ║                                                       ║" "Green"
    Write-Color "    ║           青柠OS 统一构建工具 v3.0                    ║" "Green"
    Write-Color "    ║                                                       ║" "Green"
    Write-Color "    ║     一个脚本，构建两个版本的操作系统                   ║" "Green"
    Write-Color "    ║                                                       ║" "Green"
    Write-Color "    ╚═══════════════════════════════════════════════════════╝" "Green"
    Write-Host ""
    Write-Color "    [1] Alex版  - 真正的Linux操作系统" "Cyan"
    Write-Color "        • Linux Kernel + 自主GUI图形界面" "Gray"
    Write-Color "        • 任务栏、Dock、窗口管理、鼠标支持" "Gray"
    Write-Color "        • 约 25MB 超轻量系统" "Gray"
    Write-Host ""
    Write-Color "    [2] Windows版 - 基于Windows的定制系统" "Cyan"
    Write-Color "        • 需要Windows 10/11原版ISO" "Gray"
    Write-Color "        • 自动应用青柠主题和配置" "Gray"
    Write-Color "        • 无人值守安装" "Gray"
    Write-Host ""
    Write-Color "    [Q] 退出" "Red"
    Write-Host ""
    Write-Host -NoNewline "    请选择版本 [1/2/Q]: "
}

# ============================================================
# 主程序
# ============================================================
Write-Title "青柠OS 构建工具 v3.0"

# 检查基本依赖
Write-Info "检查依赖..."
$hasCurl = Test-Dependency "curl" "curl"
$has7z = Test-Dependency "7z" "7-Zip"
if (-not $has7z) { Test-Dependency "7za" "7-Zip (standalone)" | Out-Null }

# 创建输出目录
if (-not (Test-Path $OutputDir)) {
    New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
}

# 版本选择
if ([string]::IsNullOrEmpty($Version)) {
    Show-Menu
    $choice = Read-Host
    switch ($choice.Trim().ToUpper()) {
        "1" { $Version = "alex" }
        "2" { $Version = "windows" }
        "Q" { exit 0 }
        default {
            Write-Error "无效选择"
            exit 1
        }
    }
}

# 执行构建
switch ($Version.ToLower()) {
    "alex" {
        Build-AlexVersion
    }
    "windows" {
        if ([string]::IsNullOrEmpty($WindowsISO)) {
            Write-Host -NoNewline "请输入Windows ISO文件路径: "
            $WindowsISO = Read-Host
        }
        Build-WindowsVersion -SourceISO $WindowsISO
    }
    default {
        Write-Error "未知版本: $Version"
        Write-Info "可用版本: alex, windows"
        exit 1
    }
}

Write-Host ""
Write-Color "============================================================" "Green"
Write-Color "  构建完成！输出目录: $OutputDir" "Green"
Write-Color "============================================================" "Green"
Write-Host ""
