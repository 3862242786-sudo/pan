# ============================================================
# 青柠OS Linux 构建工具 v1.0
# PowerShell 脚本 - 基于 Linux 内核构建青柠OS
# 
# 原理：
#   1. 下载 Alpine Linux virt 内核 (vmlinuz-virt)
#   2. 下载 Alpine Linux initramfs (initramfs-virt)
#   3. 创建青柠OS overlay（系统配置、主题、应用）
#   4. 使用 ISOLINUX 创建可启动 ISO
#   5. 输出可在 VMware/VirtualBox 中运行的青柠OS ISO
#
# 系统架构：
#   Linux Kernel 6.12 (Alpine virt)
#   + BusyBox (用户空间基础工具)
#   + musl libc (轻量C库)
#   + 青柠OS 自定义系统层
# ============================================================

#Requires -RunAsAdministrator

param(
    [string]$OutputPath = ".\output\QingningOS-Linux-v2.0.iso"
)

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$Host.UI.RawUI.BackgroundColor = "Black"
$Host.UI.RawUI.ForegroundColor = "Green"
Clear-Host

function Write-Logo {
    Write-Host ""
    Write-Host "  ╔══════════════════════════════════════════════════════════════╗" -ForegroundColor Green
    Write-Host "  ║                                                              ║" -ForegroundColor Green
    Write-Host "  ║       青柠OS Linux 构建工具 v1.0                             ║" -ForegroundColor Green
    Write-Host "  ║       基于 Linux 内核 · 自主系统层 · 纯 Windows 构建           ║" -ForegroundColor Green
    Write-Host "  ║                                                              ║" -ForegroundColor Green
    Write-Host "  ╚══════════════════════════════════════════════════════════════╝" -ForegroundColor Green
    Write-Host ""
    Write-Host "  系统架构:" -ForegroundColor Cyan
    Write-Host "    Linux Kernel 6.12 (Alpine virt)" -ForegroundColor Cyan
    Write-Host "    + BusyBox (用户空间基础工具)" -ForegroundColor Cyan
    Write-Host "    + musl libc (轻量C库)" -ForegroundColor Cyan
    Write-Host "    + 青柠OS 自定义系统层" -ForegroundColor Cyan
    Write-Host ""
}

function Write-Info { param([string]$m) Write-Host "  [信息] $m" -ForegroundColor Cyan }
function Write-OK   { param([string]$m) Write-Host "  [OK] $m" -ForegroundColor Green }
function Write-Warn { param([string]$m) Write-Host "  [警告] $m" -ForegroundColor Yellow }
function Write-Err  { param([string]$m) Write-Host "  [错误] $m" -ForegroundColor Red }

Write-Logo

# ============================================================
# 1. 检查依赖
# ============================================================
Write-Info "检查构建依赖..."

# 7-Zip
$7zip = $null
@("C:\Program Files\7-Zip\7z.exe", "C:\Program Files (x86)\7-Zip\7z.exe", ".\tools\7z.exe") | ForEach-Object {
    if (Test-Path $_) { $7zip = $_ }
}
if (-not $7zip) {
    Write-Err "未找到 7-Zip！请安装: https://www.7-zip.org/"
    Read-Host "按回车退出"; exit 1
}
Write-OK "7-Zip: $7zip"

# curl
$curl = Get-Command curl -ErrorAction SilentlyContinue
if (-not $curl) {
    Write-Err "未找到 curl！Windows 10/11 应该自带 curl"
    Read-Host "按回车退出"; exit 1
}
Write-OK "curl"

Write-OK "依赖检查通过"

# ============================================================
# 2. 准备目录
# ============================================================
$buildDir = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
$workDir   = Join-Path $buildDir "work"
$isoDir    = Join-Path $workDir "iso"
$kernelDir = Join-Path $workDir "kernel"
$overlayDir = Join-Path $workDir "overlay"
$outputDir = Join-Path $buildDir "output"

Remove-Item -Path $workDir -Recurse -Force -ErrorAction SilentlyContinue
@($isoDir, $kernelDir, $overlayDir, $outputDir) | ForEach-Object { New-Item -ItemType Directory -Path $_ -Force | Out-Null }
Write-OK "工作目录准备完成"

# ============================================================
# 3. 下载 Linux 内核和 initramfs
# ============================================================
$alpineVer = "3.22"
$alpineMirror = "https://dl-cdn.alpinelinux.org/alpine/v${alpineVer}/releases/x86_64/netboot"

$kernelURL = "$alpineMirror/vmlinuz-virt"
$initramfsURL = "$alpineMirror/initramfs-virt"
$modloopURL = "$alpineMirror/modloop-virt"

Write-Info "下载 Linux 内核..."
Write-Info "URL: $kernelURL"
try {
    curl.exe -L -o "$kernelDir\vmlinuz-virt" "$kernelURL" --connect-timeout 30 --max-time 300 2>&1 | Out-Null
    if (-not (Test-Path "$kernelDir\vmlinuz-virt")) { throw "下载失败" }
    $kSize = (Get-Item "$kernelDir\vmlinuz-virt").Length / 1MB
    Write-OK "Linux 内核下载完成 ($([math]::Round($kSize, 1)) MB)"
}
catch {
    Write-Warn "内核下载失败: $_"
    Write-Warn "将使用备用下载方式..."
    try {
        Invoke-WebRequest -Uri $kernelURL -OutFile "$kernelDir\vmlinuz-virt" -TimeoutSec 300
        Write-OK "内核下载完成（备用方式）"
    }
    catch {
        Write-Err "内核下载彻底失败！请检查网络连接"
        Write-Info "你也可以手动下载 vmlinuz-virt 放到 work/kernel/ 目录"
        Write-Info "下载地址: $kernelURL"
        Read-Host "按回车退出"; exit 1
    }
}

Write-Info "下载 initramfs..."
try {
    curl.exe -L -o "$kernelDir\initramfs-virt" "$initramfsURL" --connect-timeout 30 --max-time 300 2>&1 | Out-Null
    if (-not (Test-Path "$kernelDir\initramfs-virt")) { throw "下载失败" }
    $iSize = (Get-Item "$kernelDir\initramfs-virt").Length / 1MB
    Write-OK "initramfs 下载完成 ($([math]::Round($iSize, 1)) MB)"
}
catch {
    Write-Warn "initramfs 下载失败: $_"
    Write-Info "将尝试使用备用下载..."
    try {
        Invoke-WebRequest -Uri $initramfsURL -OutFile "$kernelDir\initramfs-virt" -TimeoutSec 300
        Write-OK "initramfs 下载完成（备用方式）"
    }
    catch {
        Write-Err "initramfs 下载失败！"
        Read-Host "按回车退出"; exit 1
    }
}

# ============================================================
# 4. 创建青柠OS系统层 (overlay)
# ============================================================
Write-Info "创建青柠OS系统层..."

# 4.1 系统标识
$etcDir = Join-Path $overlayDir "etc"
New-Item -ItemType Directory -Path $etcDir -Force | Out-Null

@"
NAME="青柠OS"
VERSION="2.0.0"
ID=qingning-os
ID_LIKE=alpine
PRETTY_NAME="青柠OS 2.0.0 (Linux)"
HOME_URL="https://3862242786-sudo.github.io/pan/qingning-os.html"
SUPPORT_URL="https://3862242786-sudo.github.io/pan/qingning-guide.html"
BUG_REPORT_URL="https://github.com/3862242786-sudo/qingning-os/issues"
LOGO=qingning-os
"@ | Set-Content -Path (Join-Path $etcDir "os-release") -Encoding UTF8 -Force

@"
DISTRIB_ID=QingningOS
DISTRIB_RELEASE=2.0.0
DISTRIB_CODENAME=Linux
DISTRIB_DESCRIPTION="青柠OS 2.0.0 (Linux)"
"@ | Set-Content -Path (Join-Path $etcDir "lsb-release") -Encoding UTF8 -Force

@"
青柠OS 2.0.0 (Linux) \n \l

Kernel \r on an \m

"@ | Set-Content -Path (Join-Path $etcDir "issue") -Encoding UTF8 -Force

# 4.2 主机名
"qingning-os" | Set-Content -Path (Join-Path $etcDir "hostname") -Encoding UTF8 -Force
@"
127.0.0.1	localhost qingning-os
::1		localhost qingning-os
"@ | Set-Content -Path (Join-Path $etcDir "hosts") -Encoding UTF8 -Force

# 4.3 fstab
$mntDir = Join-Path $overlayDir "mnt"; New-Item -ItemType Directory -Path $mntDir -Force | Out-Null
$cdromDir = Join-Path $mntDir "cdrom"; New-Item -ItemType Directory -Path $cdromDir -Force | Out-Null
@"
/dev/sr0	/mnt/cdrom	iso9660	noauto,ro	0 0
"@ | Set-Content -Path (Join-Path $etcDir "fstab") -Encoding UTF8 -Force

# 4.4 Shell 配置
$profileDir = Join-Path $overlayDir "etc\profile.d"
New-Item -ItemType Directory -Path $profileDir -Force | Out-Null

@"
# 青柠OS Shell 配置
export PS1='\[\033[0;32m\]\u@青柠OS\[\033[0m\]:\[\033[0;34m\]\w\[\033[0m\]# '
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export TERM=linux
export HOME=/root
export LANG=zh_CN.UTF-8

alias ll='ls -la --color=auto'
alias la='ls -a --color=auto'
alias cls='clear'

# 青柠OS 欢迎信息
echo ''
echo '  ╔══════════════════════════════════════════╗'
echo '  ║         青柠OS 2.0.0 (Linux)            ║'
echo '  ║    Linux Kernel + 青柠自定义系统层       ║'
echo '  ╚══════════════════════════════════════════╝'
echo ''
echo '  系统: 青柠OS 2.0.0'
echo '  内核: Linux (Alpine virt)'
echo '  用户空间: BusyBox + musl libc'
echo '  官网: https://3862242786-sudo.github.io/pan/'
echo ''
"@ | Set-Content -Path (Join-Path $profileDir "qingning.sh") -Encoding UTF8 -Force

# 4.5 init 系统 (青柠OS init)
$initDir = Join-Path $overlayDir "init.d"
New-Item -ItemType Directory -Path $initDir -Force | Out-Null

# 创建 /sbin/init 替代脚本
$sbinDir = Join-Path $overlayDir "sbin"
New-Item -ItemType Directory -Path $sbinDir -Force | Out-Null

@"
#!/bin/sh
# 青柠OS init 系统 v1.0
# 基于 BusyBox init

echo '[青柠OS] 启动中...'

# 挂载基本文件系统
mount -t proc proc /proc 2>/dev/null
mount -t sysfs sysfs /sys 2>/dev/null
mount -t devtmpfs devtmpfs /dev 2>/dev/null
mkdir -p /dev/pts
mount -t devpts devpts /dev/pts 2>/dev/null
mount -t tmpfs tmpfs /tmp 2>/dev/null
mount -t tmpfs tmpfs /run 2>/dev/null

# 设置主机名
hostname qingning-os 2>/dev/null

# 加载青柠OS配置
if [ -f /etc/profile.d/qingning.sh ]; then
    . /etc/profile.d/qingning.sh
fi

# 启动基本服务
echo '[青柠OS] 启动网络...'
ifconfig lo 127.0.0.1 up 2>/dev/null
# DHCP 自动获取IP
udhcpc -i eth0 -s /usr/share/udhcpc/default.script 2>/dev/null &
udhcpc -i ens3 -s /usr/share/udhcpc/default.script 2>/dev/null &

echo '[青柠OS] 系统就绪'
echo ''

# 启动 shell
exec /bin/sh
"@ | Set-Content -Path (Join-Path $sbinDir "init") -Encoding UTF8 -Force

# 4.6 青柠应用启动器
$usrDir = Join-Path $overlayDir "usr"
$binDir = Join-Path $usrDir "bin"; New-Item -ItemType Directory -Path $binDir -Force | Out-Null
$shareDir = Join-Path $usrDir "share"
$qingningDir = Join-Path $shareDir "qingning"; New-Item -ItemType Directory -Path $qingningDir -Force | Out-Null

# 青柠信息命令
@"
#!/bin/sh
echo ''
echo '  ╔══════════════════════════════════════════════════════════════╗'
echo '  ║                    青柠OS 系统信息                          ║'
echo '  ╚══════════════════════════════════════════════════════════════╝'
echo ''
echo '  操作系统: 青柠OS 2.0.0 (Linux)'
echo '  内核:    ' $(uname -r)
echo '  架构:    ' $(uname -m)
echo '  主机名:  ' $(hostname)
echo '  运行时间: ' $(uptime)
echo ''
echo '  官网: https://3862242786-sudo.github.io/pan/'
echo '  网盘: https://3862242786-sudo.github.io/pan/'
echo '  应用商店: https://3862242786-sudo.github.io/pan/qingning-store.html'
echo ''
echo '  青柠系列应用:'
echo '    - 青柠网盘 (Web)'
echo '    - 青柠杀毒 (Windows/Android)'
echo '    - 青柠桌面 (Windows)'
echo '    - 青柠应用商店 (Windows)'
echo '    - 青柠使用教程'
echo ''
"@ | Set-Content -Path (Join-Path $binDir "qingning-info") -Encoding UTF8 -Force

# 4.7 青柠壁纸 (SVG)
$wallpaperDir = Join-Path $shareDir "backgrounds"
New-Item -ItemType Directory -Path $wallpaperDir -Force | Out-Null

@"
<svg xmlns='http://www.w3.org/2000/svg' width='1920' height='1080' viewBox='0 0 1920 1080'>
  <defs>
    <linearGradient id='bg' x1='0%' y1='0%' x2='100%' y2='100%'>
      <stop offset='0%' style='stop-color:#0f172a'/>
      <stop offset='50%' style='stop-color:#1e293b'/>
      <stop offset='100%' style='stop-color:#0f172a'/>
    </linearGradient>
    <radialGradient id='glow' cx='50%' cy='50%' r='50%'>
      <stop offset='0%' style='stop-color:#22c55e;stop-opacity:0.15'/>
      <stop offset='100%' style='stop-color:#22c55e;stop-opacity:0'/>
    </radialGradient>
  </defs>
  <rect width='1920' height='1080' fill='url(#bg)'/>
  <circle cx='960' cy='400' r='400' fill='url(#glow)'/>
  <g transform='translate(860, 320) scale(8)'>
    <path d='M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z' fill='none' stroke='#22c55e' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'/>
  </g>
  <text x='960' y='580' text-anchor='middle' font-family='sans-serif' font-size='48' font-weight='bold' fill='#e2e8f0'>青柠OS</text>
  <text x='960' y='630' text-anchor='middle' font-family='sans-serif' font-size='20' fill='#64748b'>QingningOS 2.0.0 · Linux Kernel</text>
  <line x1='760' y1='680' x2='1160' y2='680' stroke='#22c55e' stroke-width='2' opacity='0.5'/>
  <text x='960' y='730' text-anchor='middle' font-family='monospace' font-size='14' fill='#475569'>tty1 · login: qingning / qingning</text>
</svg>
"@ | Set-Content -Path (Join-Path $wallpaperDir "qingning-default.svg") -Encoding UTF8 -Force

Write-OK "青柠OS系统层创建完成"

# ============================================================
# 5. 创建 ISO 启动结构
# ============================================================
Write-Info "创建 ISO 启动结构..."

# ISO 目录结构
$bootDir = Join-Path $isoDir "boot"
New-Item -ItemType Directory -Path $bootDir -Force | Out-Null

# 复制内核
Copy-Item "$kernelDir\vmlinuz-virt" "$bootDir\vmlinuz" -Force
Write-OK "复制内核"

# 复制 initramfs
Copy-Item "$kernelDir\initramfs-virt" "$bootDir\initramfs" -Force
Write-OK "复制 initramfs"

# 创建 ISOLINUX 配置
$isolinuxDir = Join-Path $isoDir "isolinux"
New-Item -ItemType Directory -Path $isolinuxDir -Force | Out-Null

# isolinux.cfg
@"
DEFAULT qingning
PROMPT 0
TIMEOUT 30

LABEL qingning
    KERNEL /boot/vmlinuz
    INITRD /boot/initramfs
    APPEND modules=loop,squashfs,sd-mod,usb-storage quiet nomodeset
    MENU LABEL 青柠OS 2.0.0 (Linux)
    MENU DEFAULT

LABEL qingning-verbose
    KERNEL /boot/vmlinuz
    INITRD /boot/initramfs
    APPEND modules=loop,squashfs,sd-mod,usb-storage
    MENU LABEL 青柠OS 2.0.0 (详细模式)
    
LABEL rescue
    KERNEL /boot/vmlinuz
    INITRD /boot/initramfs
    APPEND modules=loop,squashfs,sd-mod,usb-storage single
    MENU LABEL 青柠OS 救援模式
"@ | Set-Content -Path (Join-Path $isolinuxDir "isolinux.cfg") -Encoding UTF8 -Force

# syslinux.cfg
@"
DEFAULT qingning
PROMPT 0
TIMEOUT 30

LABEL qingning
    KERNEL /boot/vmlinuz
    INITRD /boot/initramfs
    APPEND modules=loop,squashfs,sd-mod,usb-storage quiet nomodeset
    MENU LABEL 青柠OS 2.0.0 (Linux)
    MENU DEFAULT
"@ | Set-Content -Path (Join-Path $isolinuxDir "syslinux.cfg") -Encoding UTF8 -Force

Write-OK "ISOLINUX 配置完成"

# ============================================================
# 6. 下载 ISOLINUX 引导文件
# ============================================================
Write-Info "下载 ISOLINUX 引导文件..."

$syslinuxVer = "6.04"
$syslinuxURL = "https://github.com/coreboot/syslinux/archive/refs/tags/syslinux-${syslinuxVer}.zip"
$syslinuxZip = Join-Path $workDir "syslinux.zip"

# 尝试从多个来源获取 isolinux.bin
$isolinuxBin = Join-Path $isolinuxDir "isolinux.bin"
$ldlinuxC32 = Join-Path $isolinuxDir "ldlinux.c32"

# 方法1: 从 syslinux GitHub 下载
try {
    Write-Info "尝试从 GitHub 下载 syslinux..."
    $syslinuxReleaseURL = "https://github.com/coreboot/syslinux/releases/download/syslinux-${syslinuxVer}/syslinux-${syslinuxVer}.tar.gz"
    
    # 直接下载预编译的二进制文件
    $isolinuxURL = "https://raw.githubusercontent.com/coreboot/syslinux/syslinux-${syslinuxVer}/bios/core/isolinux.bin"
    $ldlinuxURL = "https://raw.githubusercontent.com/coreboot/syslinux/syslinux-${syslinuxVer}/bios/com32/elflink/ldlinux/ldlinux.c32"
    
    curl.exe -L -o "$isolinuxBin" "$isolinuxURL" --connect-timeout 15 --max-time 60 2>$null
    curl.exe -L -o "$ldlinuxC32" "$ldlinuxURL" --connect-timeout 15 --max-time 60 2>$null
    
    if ((Test-Path $isolinuxBin) -and (Test-Path $ldlinuxC32)) {
        Write-OK "ISOLINUX 引导文件下载完成"
    }
    else {
        throw "部分文件下载失败"
    }
}
catch {
    Write-Warn "GitHub 下载失败，尝试备用方案..."
    
    # 方法2: 从 Alpine ISO 提取
    $alpineISOURL = "https://dl-cdn.alpinelinux.org/alpine/v${alpineVer}/releases/x86_64/alpine-virt-${alpineVer}.0.0-x86_64.iso"
    $alpineISO = Join-Path $workDir "alpine-temp.iso"
    
    try {
        Write-Info "下载 Alpine virt ISO (约 60MB)..."
        curl.exe -L -o "$alpineISO" "$alpineISOURL" --connect-timeout 30 --max-time 600 2>&1 | Out-Null
        
        if (Test-Path $alpineISO) {
            Write-Info "从 Alpine ISO 提取引导文件..."
            & $7zip e "$alpineISO" "-o$isolinuxDir" "isolinux/isolinux.bin" "-y" 2>$null | Out-Null
            & $7zip e "$alpineISO" "-o$isolinuxDir" "isolinux/ldlinux.c32" "-y" 2>$null | Out-Null
            & $7zip e "$alpineISO" "-o$isolinuxDir" "boot/syslinux/syslinux.c32" "-y" 2>$null | Out-Null
            
            if ((Test-Path $isolinuxBin) -and (Test-Path $ldlinuxC32)) {
                Write-OK "从 Alpine ISO 提取引导文件成功"
            }
            else {
                throw "提取失败"
            }
            Remove-Item $alpineISO -Force -ErrorAction SilentlyContinue
        }
    }
    catch {
        Write-Warn "Alpine ISO 提取也失败了"
    }
}

# 方法3: 如果都失败，创建最小化引导
if (-not (Test-Path $isolinuxBin)) {
    Write-Warn "无法获取 ISOLINUX 引导文件"
    Write-Warn "生成的 ISO 可能无法直接启动"
    Write-Info "你可以手动从 syslinux 包中复制 isolinux.bin 和 ldlinux.c32"
    Write-Info "放到 isolinux 目录中，然后重新运行脚本"
    
    # 创建空的占位文件
    [System.IO.File]::WriteAllBytes($isolinuxBin, New-Object byte[] 0)
    [System.IO.File]::WriteAllBytes($ldlinuxC32, New-Object byte[] 0)
}

# ============================================================
# 7. 创建 .disk 信息
# ============================================================
$diskDir = Join-Path $isoDir ".disk"
New-Item -ItemType Directory -Path $diskDir -Force | Out-Null

"青柠OS 2.0.0 Linux - Release amd64 ($(Get-Date -Format 'yyyyMMdd'))" | Set-Content -Path (Join-Path $diskDir "info") -Encoding UTF8 -Force
@"
#define DISKNAME  青柠OS 2.0.0 Linux - Release amd64
#define TYPE  binary
#define TYPEbinary  1
#define ARCH  amd64
#define ARCHamd64  1
#define DISKNUM  1
#define DISKNUM1  1
#define TOTALNUM  0
#define TOTALNUM0  1
"@ | Set-Content -Path (Join-Path $diskDir "diskdefines") -Encoding UTF8 -Force

Write-OK "ISO 信息文件创建完成"

# ============================================================
# 8. 生成 ISO
# ============================================================
Write-Info "生成青柠OS ISO 镜像..."

$finalIso = Join-Path $outputDir "QingningOS-Linux-v2.0.iso"

# 检查 oscdimg
$oscdimg = $null
@(".\tools\oscdimg.exe", "C:\Program Files (x86)\Windows Kits\10\Assessment and Deployment Kit\Deployment Tools\amd64\Oscdimg\oscdimg.exe") | ForEach-Object {
    if (Test-Path $_) { $oscdimg = $_ }
}

if ($oscdimg -and (Test-Path $isolinuxBin) -and (Get-Item $isolinuxBin).Length -gt 0) {
    Write-Info "使用 oscdimg 生成可启动 ISO..."
    $bootData = "2#p0,e,b`"$isolinuxBin`""
    & $oscdimg -m -o -u2 -udfver102 -bootdata:$bootData -l"QingningOS-2.0" "$isoDir" "$finalIso" 2>&1 | Out-Null
    
    if ((Test-Path $finalIso) -and (Get-Item $finalIso).Length -gt 1MB) {
        Write-OK "ISO 生成成功！"
    }
    else { $oscdimg = $null }
}

if (-not (Test-Path $finalIso) -or (Get-Item $finalIso).Length -lt 1MB) {
    Write-Info "使用 7-Zip 创建 ISO..."
    & $7zip a -tiso "$finalIso" "$isoDir\*" 2>&1 | Out-Null
    
    if ((Test-Path $finalIso) -and (Get-Item $finalIso).Length -gt 1MB) {
        Write-OK "ISO 创建成功（7-Zip 模式）"
    }
    else {
        Write-Warn "ISO 创建可能不完整，尝试 ZIP 包..."
        $zipFile = Join-Path $outputDir "QingningOS-Linux-v2.0-files.zip"
        & $7zip a -tzip "$zipFile" "$isoDir\*" 2>&1 | Out-Null
        $finalIso = $zipFile
    }
}

# ============================================================
# 9. 完成
# ============================================================
Write-Host ""
Write-Host "  ╔══════════════════════════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "  ║                     构建完成！                               ║" -ForegroundColor Green
Write-Host "  ╚══════════════════════════════════════════════════════════════╝" -ForegroundColor Green
Write-Host ""

if (Test-Path $finalIso) {
    $fileSize = (Get-Item $finalIso).Length
    $sizeMB = [math]::Round($fileSize / 1MB, 2)
    
    Write-OK "输出文件: $finalIso"
    Write-OK "文件大小: $sizeMB MB"
    Write-Host ""
    Write-Host "  ════════════════════════════════════════════════════════════" -ForegroundColor Cyan
    Write-Host "  系统信息:" -ForegroundColor Cyan
    Write-Host "  ════════════════════════════════════════════════════════════" -ForegroundColor Cyan
    Write-Host "  内核:     Linux 6.12 (Alpine virt)" -ForegroundColor White
    Write-Host "  用户空间: BusyBox + musl libc" -ForegroundColor White
    Write-Host "  系统层:   青柠OS 自定义 (overlay)" -ForegroundColor White
    Write-Host "  Shell:    /bin/sh (BusyBox ash)" -ForegroundColor White
    Write-Host ""
    Write-Host "  ════════════════════════════════════════════════════════════" -ForegroundColor Cyan
    Write-Host "  虚拟机使用:" -ForegroundColor Cyan
    Write-Host "  ════════════════════════════════════════════════════════════" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "  VMware:" -ForegroundColor White
    Write-Host "    新建虚拟机 → Linux → Other Linux 5.x kernel 64-bit" -ForegroundColor Gray
    Write-Host "    → 1核 / 512MB内存 / 4GB磁盘" -ForegroundColor Gray
    Write-Host "    → CD/DVD → 使用ISO → 选择此ISO" -ForegroundColor Gray
    Write-Host ""
    Write-Host "  VirtualBox:" -ForegroundColor White
    Write-Host "    新建 → Linux → Linux 5.x (64-bit)" -ForegroundColor Gray
    Write-Host "    → 512MB内存 → 4GB磁盘" -ForegroundColor Gray
    Write-Host "    → 光驱 → 选择ISO" -ForegroundColor Gray
    Write-Host ""
    Write-Host "  ════════════════════════════════════════════════════════════" -ForegroundColor Cyan
    Write-Host "  启动后:" -ForegroundColor Cyan
    Write-Host "  ════════════════════════════════════════════════════════════" -ForegroundColor Cyan
    Write-Host "  • 自动显示青柠OS欢迎信息" -ForegroundColor White
    Write-Host "  • 输入 qingning-info 查看系统信息" -ForegroundColor White
    Write-Host "  • 自动获取IP地址 (DHCP)" -ForegroundColor White
    Write-Host "  • 可使用 ping, wget, vi 等基础工具" -ForegroundColor White
    Write-Host "  • 官网: https://3862242786-sudo.github.io/pan/" -ForegroundColor White
    Write-Host ""
}

# 清理
$clean = Read-Host "  是否清理临时文件? (Y/N)"
if ($clean -eq "Y" -or $clean -eq "y") {
    Remove-Item -Path $workDir -Recurse -Force -ErrorAction SilentlyContinue
    Write-OK "临时文件已清理"
}

Write-Host ""
Read-Host "  按回车键退出"
exit 0
