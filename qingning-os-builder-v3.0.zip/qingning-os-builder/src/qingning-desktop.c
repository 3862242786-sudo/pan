/************************************************************
 * 青柠OS 桌面环境 v3.0
 * 基于 Linux Framebuffer 的轻量图形界面
 ************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <linux/fb.h>
#include <linux/input.h>
#include <errno.h>
#include <signal.h>
#include <time.h>

/* 颜色 */
#define COLOR_BG        0xFF0F172A
#define COLOR_BG_LIGHT  0xFF1E293B
#define COLOR_ACCENT    0xFF22C55E
#define COLOR_ACCENT_HL 0xFF4ADE80
#define COLOR_TEXT      0xFFE2E8F0
#define COLOR_TEXT_DIM  0xFF94A3B8
#define COLOR_PANEL     0xFF334155
#define COLOR_WHITE     0xFFFFFFFF
#define COLOR_BLACK     0xFF000000

/* 尺寸 */
#define TASKBAR_H       40
#define ICON_SIZE       48
#define DOCK_H          64
#define DOCK_ICON_SIZE  40

/* 帧缓冲 */
static int fb_fd = -1;
static unsigned int *fb_mem = NULL;
static struct fb_var_screeninfo vinfo;
static struct fb_fix_screeninfo finfo;
static int screen_w, screen_h;
static int fb_size;

/* 鼠标 */
static int mouse_x = 0, mouse_y = 0;
static int mouse_fd = -1;

/* 状态 */
static int running = 1;

/* 窗口 */
#define MAX_WINDOWS 8
typedef struct {
    int x, y, w, h;
    int visible;
    char title[64];
} Window;
static Window windows[MAX_WINDOWS];
static int window_count = 0;
static int active_win = -1;

/* 图标 */
typedef struct {
    int x, y;
    const char *label;
    unsigned int color;
    void (*click)(void);
} Icon;

static void launch_term(void) {
    if (fork() == 0) {
        execlp("/bin/sh", "sh", "-c", "exec /bin/sh", NULL);
        exit(0);
    }
}

static void launch_browser(void) {
    if (fork() == 0) {
        execlp("lynx", "lynx", "https://3862242786-sudo.github.io/pan/", NULL);
        execlp("links", "links", "https://3862242786-sudo.github.io/pan/", NULL);
        exit(0);
    }
}

static void launch_fm(void) {
    if (window_count < MAX_WINDOWS) {
        Window *w = &windows[window_count++];
        w->x = 100 + window_count * 30;
        w->y = 100 + window_count * 30;
        w->w = 400; w->h = 300;
        w->visible = 1;
        strncpy(w->title, "文件管理器", 63);
        active_win = window_count - 1;
    }
}

static void launch_settings(void) {
    if (window_count < MAX_WINDOWS) {
        Window *w = &windows[window_count++];
        w->x = 150 + window_count * 30;
        w->y = 120 + window_count * 30;
        w->w = 350; w->h = 250;
        w->visible = 1;
        strncpy(w->title, "系统设置", 63);
        active_win = window_count - 1;
    }
}

static void launch_about(void) {
    if (window_count < MAX_WINDOWS) {
        Window *w = &windows[window_count++];
        w->x = 200 + window_count * 30;
        w->y = 150 + window_count * 30;
        w->w = 380; w->h = 280;
        w->visible = 1;
        strncpy(w->title, "关于青柠OS", 63);
        active_win = window_count - 1;
    }
}

static Icon dock_icons[] = {
    {0, 0, "终端", COLOR_ACCENT, launch_term},
    {0, 0, "浏览器", COLOR_ACCENT_HL, launch_browser},
    {0, 0, "文件", 0xFF3B82F6, launch_fm},
    {0, 0, "设置", 0xFFA855F7, launch_settings},
    {0, 0, "关于", 0xFFF97316, launch_about},
};
#define DOCK_COUNT (sizeof(dock_icons)/sizeof(dock_icons[0]))

static Icon desktop_icons[] = {
    {40, 80, "青柠网盘", COLOR_ACCENT, launch_browser},
    {40, 160, "应用商店", COLOR_ACCENT_HL, launch_browser},
    {40, 240, "使用教程", 0xFF3B82F6, launch_browser},
    {40, 320, "系统信息", 0xFFF97316, launch_about},
};
#define DESKTOP_COUNT (sizeof(desktop_icons)/sizeof(desktop_icons[0]))

/* 帧缓冲操作 */
int fb_init(void) {
    fb_fd = open("/dev/fb0", O_RDWR);
    if (fb_fd < 0) { fb_fd = open("/dev/fb1", O_RDWR); }
    if (fb_fd < 0) { perror("fb"); return -1; }

    ioctl(fb_fd, FBIOGET_FSCREENINFO, &finfo);
    ioctl(fb_fd, FBIOGET_VSCREENINFO, &vinfo);

    screen_w = vinfo.xres;
    screen_h = vinfo.yres;
    fb_size = finfo.line_length * screen_h;

    fb_mem = (unsigned int *)mmap(NULL, fb_size, PROT_READ|PROT_WRITE, MAP_SHARED, fb_fd, 0);
    if (fb_mem == MAP_FAILED) { perror("mmap"); return -1; }

    printf("[青柠OS] Framebuffer: %dx%d\n", screen_w, screen_h);
    return 0;
}

void fb_close(void) {
    if (fb_mem && fb_mem != MAP_FAILED) munmap(fb_mem, fb_size);
    if (fb_fd >= 0) close(fb_fd);
}

static inline void pixel(int x, int y, unsigned int c) {
    if (x < 0 || x >= screen_w || y < 0 || y >= screen_h) return;
    fb_mem[y * (finfo.line_length / 4) + x] = c;
}

void fill_rect(int x, int y, int w, int h, unsigned int c) {
    int i, j;
    for (j = y; j < y + h && j < screen_h; j++)
        for (i = x; i < x + w && i < screen_w; i++)
            if (i >= 0 && j >= 0) pixel(i, j, c);
}

void round_rect(int x, int y, int w, int h, int r, unsigned int c) {
    int i, j;
    for (j = y; j < y + h && j < screen_h; j++) {
        for (i = x; i < x + w && i < screen_w; i++) {
            if (i >= 0 && j >= 0) {
                int dx = (i < x + r) ? (x + r - i) : ((i > x + w - r) ? (i - (x + w - r)) : 0);
                int dy = (j < y + r) ? (y + r - j) : ((j > y + h - r) ? (j - (y + h - r)) : 0);
                if (dx * dx + dy * dy <= r * r || (dx == 0 && dy == 0)) pixel(i, j, c);
            }
        }
    }
}

/* 位图字体 5x7 */
static const unsigned char font[128][5] = {
    ['A']={0x7E,0x09,0x09,0x09,0x7E},['B']={0x7F,0x49,0x49,0x49,0x36},
    ['C']={0x3E,0x41,0x41,0x41,0x22},['D']={0x7F,0x41,0x41,0x22,0x1C},
    ['E']={0x7F,0x49,0x49,0x49,0x41},['F']={0x7F,0x09,0x09,0x09,0x01},
    ['G']={0x3E,0x41,0x49,0x49,0x7A},['H']={0x7F,0x08,0x08,0x08,0x7F},
    ['I']={0x00,0x41,0x7F,0x41,0x00},['J']={0x20,0x40,0x41,0x3F,0x01},
    ['K']={0x7F,0x08,0x14,0x22,0x41},['L']={0x7F,0x40,0x40,0x40,0x40},
    ['M']={0x7F,0x02,0x0C,0x02,0x7F},['N']={0x7F,0x04,0x08,0x10,0x7F},
    ['O']={0x3E,0x41,0x41,0x41,0x3E},['P']={0x7F,0x09,0x09,0x09,0x06},
    ['Q']={0x3E,0x41,0x51,0x21,0x5E},['R']={0x7F,0x09,0x19,0x29,0x46},
    ['S']={0x46,0x49,0x49,0x49,0x31},['T']={0x01,0x01,0x7F,0x01,0x01},
    ['U']={0x3F,0x40,0x40,0x40,0x3F},['V']={0x1F,0x20,0x40,0x20,0x1F},
    ['W']={0x3F,0x40,0x38,0x40,0x3F},['X']={0x63,0x14,0x08,0x14,0x63},
    ['Y']={0x07,0x08,0x70,0x08,0x07},['Z']={0x61,0x51,0x49,0x45,0x43},
    ['a']={0x20,0x54,0x54,0x54,0x78},['b']={0x7F,0x48,0x44,0x44,0x38},
    ['c']={0x38,0x44,0x44,0x44,0x20},['d']={0x38,0x44,0x44,0x48,0x7F},
    ['e']={0x38,0x54,0x54,0x54,0x18},['f']={0x08,0x7E,0x09,0x01,0x02},
    ['g']={0x0C,0x52,0x52,0x52,0x3E},['h']={0x7F,0x08,0x04,0x04,0x78},
    ['i']={0x00,0x44,0x7D,0x40,0x00},['j']={0x20,0x40,0x44,0x3D,0x00},
    ['k']={0x7F,0x10,0x28,0x44,0x00},['l']={0x00,0x41,0x7F,0x40,0x00},
    ['m']={0x7C,0x04,0x18,0x04,0x78},['n']={0x7C,0x08,0x04,0x04,0x78},
    ['o']={0x38,0x44,0x44,0x44,0x38},['p']={0x7C,0x14,0x14,0x14,0x08},
    ['q']={0x08,0x14,0x14,0x18,0x7C},['r']={0x7C,0x08,0x04,0x04,0x08},
    ['s']={0x48,0x54,0x54,0x54,0x20},['t']={0x04,0x3F,0x44,0x40,0x20},
    ['u']={0x3C,0x40,0x40,0x20,0x7C},['v']={0x1C,0x20,0x40,0x20,0x1C},
    ['w']={0x3C,0x40,0x30,0x40,0x3C},['x']={0x44,0x28,0x10,0x28,0x44},
    ['y']={0x0C,0x50,0x50,0x50,0x3C},['z']={0x44,0x64,0x54,0x4C,0x44},
    ['0']={0x3E,0x51,0x49,0x45,0x3E},['1']={0x00,0x42,0x7F,0x40,0x00},
    ['2']={0x42,0x61,0x51,0x49,0x46},['3']={0x21,0x41,0x45,0x4B,0x31},
    ['4']={0x18,0x14,0x12,0x7F,0x10},['5']={0x27,0x45,0x45,0x45,0x39},
    ['6']={0x3C,0x4A,0x49,0x49,0x30},['7']={0x01,0x71,0x09,0x05,0x03},
    ['8']={0x36,0x49,0x49,0x49,0x36},['9']={0x06,0x49,0x49,0x29,0x1E},
    ['.']={0x00,0x60,0x60,0x00,0x00},['-']={0x08,0x08,0x08,0x08,0x08},
    ['_']={0x40,0x40,0x40,0x40,0x40},[' ']={0x00,0x00,0x00,0x00,0x00},
    ['/']={0x20,0x10,0x08,0x04,0x02},['(']={0x00,0x1E,0x41,0x00,0x00},
    [')']={0x00,0x41,0x1E,0x00,0x00},['[']={0x00,0x7F,0x41,0x41,0x00},
    [']']={0x00,0x41,0x41,0x7F,0x00},['{']={0x08,0x36,0x41,0x00,0x00},
    ['}']={0x00,0x41,0x36,0x08,0x00},['<']={0x08,0x14,0x22,0x41,0x00},
    ['>']={0x00,0x41,0x22,0x14,0x08},['=']={0x14,0x14,0x14,0x14,0x14},
    ['+']={0x08,0x08,0x3E,0x08,0x08},['*']={0x08,0x2A,0x1C,0x2A,0x08},
    ['%']={0x46,0x26,0x10,0x4C,0x62},['@']={0x3E,0x41,0x5D,0x55,0x1E},
    ['#']={0x14,0x7F,0x14,0x7F,0x14},['$']={0x24,0x2A,0x7F,0x2A,0x12},
    ['&']={0x30,0x4E,0x59,0x26,0x50},['"']={0x00,0x03,0x00,0x03,0x00},
    ['\'']={0x00,0x01,0x00,0x00,0x00},[':']={0x00,0x36,0x36,0x00,0x00},
    [';']={0x00,0x80,0x36,0x36,0x00},
};

void draw_char(int x, int y, char c, unsigned int color, int scale) {
    unsigned char ch = (unsigned char)c;
    if (ch >= 128) ch = '?';
    int cx, cy;
    for (cx = 0; cx < 5; cx++) {
        unsigned char col = font[ch][cx];
        for (cy = 0; cy < 7; cy++) {
            if (col & (1 << cy)) {
                int px = x + cx * scale;
                int py = y + cy * scale;
                int sx, sy;
                for (sx = 0; sx < scale; sx++)
                    for (sy = 0; sy < scale; sy++)
                        pixel(px + sx, py + sy, color);
            }
        }
    }
}

void draw_text(int x, int y, const char *text, unsigned int color, int scale) {
    int i;
    for (i = 0; i < (int)strlen(text); i++)
        draw_char(x + i * (6 * scale), y, text[i], color, scale);
}

void draw_text_center(int x, int y, int w, const char *text, unsigned int color, int scale) {
    int text_w = strlen(text) * 6 * scale;
    draw_text(x + (w - text_w) / 2, y, text, color, scale);
}

/* 绘制Logo */
void draw_logo(int cx, int cy, int size) {
    int r = size / 2;
    int x, y;
    for (y = -r; y <= r; y++) {
        for (x = -r; x <= r; x++) {
            if (x * x + y * y <= r * r) {
                float nx = (float)x / r, ny = (float)y / r;
                float cloud = 1.0f - (nx * nx + ny * ny);
                if (cloud > 0.3f) {
                    pixel(cx + x, cy + y, (cloud > 0.7f) ? COLOR_ACCENT_HL : COLOR_ACCENT);
                }
            }
        }
    }
}

/* 绘制图标 */
void draw_icon(Icon *icon, int selected) {
    int x = icon->x, y = icon->y, s = ICON_SIZE;
    if (selected) round_rect(x - 4, y - 4, s + 8, s + 8, 8, 0x40FFFFFF);
    round_rect(x, y, s, s, 10, icon->color);
    round_rect(x + 2, y + 2, s - 4, s / 3, 6, 0x40FFFFFF);
    int label_w = strlen(icon->label) * 6;
    draw_text(x + (s - label_w) / 2, y + s + 6, icon->label, COLOR_TEXT, 1);
}

/* 绘制任务栏 */
void draw_taskbar(void) {
    fill_rect(0, 0, screen_w, TASKBAR_H, COLOR_PANEL);
    fill_rect(0, TASKBAR_H - 1, screen_w, 1, COLOR_ACCENT);
    round_rect(8, 6, 28, 28, 6, COLOR_ACCENT);
    draw_text(42, 10, "青柠OS", COLOR_TEXT, 2);
    time_t now = time(NULL);
    struct tm *tm_info = localtime(&now);
    char time_str[32];
    snprintf(time_str, sizeof(time_str), "%02d:%02d", tm_info->tm_hour, tm_info->tm_min);
    draw_text(screen_w - 60, 10, time_str, COLOR_TEXT_DIM, 2);
}

/* 绘制Dock */
void draw_dock(void) {
    int dock_y = screen_h - DOCK_H - 8;
    int total_w = DOCK_COUNT * DOCK_ICON_SIZE + (DOCK_COUNT + 1) * 12;
    int dock_x = (screen_w - total_w) / 2;
    round_rect(dock_x, dock_y, total_w, DOCK_H, 16, 0xE6334155);
    int i;
    int icon_x = dock_x + 12;
    for (i = 0; i < DOCK_COUNT; i++) {
        dock_icons[i].x = icon_x;
        dock_icons[i].y = dock_y + (DOCK_H - DOCK_ICON_SIZE) / 2;
        draw_icon(&dock_icons[i], 0);
        icon_x += DOCK_ICON_SIZE + 12;
    }
}

/* 绘制桌面 */
void draw_desktop(void) {
    fill_rect(0, TASKBAR_H, screen_w, screen_h - TASKBAR_H, COLOR_BG);
    int logo_x = screen_w / 2, logo_y = screen_h / 2 - 40;
    draw_logo(logo_x, logo_y, 80);
    draw_text_center(0, logo_y + 60, screen_w, "青柠OS 3.0.0", COLOR_TEXT, 3);
    draw_text_center(0, logo_y + 100, screen_w, "Linux Kernel + 自主GUI图形界面", COLOR_TEXT_DIM, 1);
    draw_text_center(0, logo_y + 130, screen_w, "Alex版 - 真正的操作系统", COLOR_TEXT_DIM, 1);
    int i;
    for (i = 0; i < DESKTOP_COUNT; i++) draw_icon(&desktop_icons[i], 0);
    draw_taskbar();
    draw_dock();
}

/* 绘制窗口 */
void draw_window(Window *win, int active) {
    if (!win->visible) return;
    int x = win->x, y = win->y, w = win->w, h = win->h;
    fill_rect(x + 4, y + 4, w, h, 0x40000000);
    fill_rect(x, y, w, h, COLOR_BG_LIGHT);
    unsigned int title_color = active ? COLOR_ACCENT : COLOR_PANEL;
    fill_rect(x, y, w, 32, title_color);
    draw_text(x + 10, y + 8, win->title, COLOR_WHITE, 1);
    round_rect(x + w - 28, y + 4, 24, 24, 4, 0xFFEF4444);
    draw_text(x + w - 22, y + 8, "X", COLOR_WHITE, 1);
}

/* 鼠标 */
int mouse_init(void) {
    mouse_fd = open("/dev/input/mice", O_RDONLY | O_NONBLOCK);
    if (mouse_fd < 0) mouse_fd = open("/dev/input/mouse0", O_RDONLY | O_NONBLOCK);
    return mouse_fd;
}

void mouse_poll(void) {
    if (mouse_fd < 0) return;
    unsigned char buf[3];
    while (read(mouse_fd, buf, 3) == 3) {
        mouse_x += (signed char)buf[1];
        mouse_y -= (signed char)buf[2];
        if (mouse_x < 0) mouse_x = 0;
        if (mouse_x >= screen_w) mouse_x = screen_w - 1;
        if (mouse_y < 0) mouse_y = 0;
        if (mouse_y >= screen_h) mouse_y = screen_h - 1;
        if (buf[0] & 0x01) {
            int i;
            int dock_y = screen_h - DOCK_H - 8;
            int total_w = DOCK_COUNT * DOCK_ICON_SIZE + (DOCK_COUNT + 1) * 12;
            int dock_x = (screen_w - total_w) / 2;
            for (i = 0; i < DOCK_COUNT; i++) {
                int ix = dock_x + 12 + i * (DOCK_ICON_SIZE + 12);
                int iy = dock_y + (DOCK_H - DOCK_ICON_SIZE) / 2;
                if (mouse_x >= ix && mouse_x < ix + DOCK_ICON_SIZE &&
                    mouse_y >= iy && mouse_y < iy + DOCK_ICON_SIZE) {
                    if (dock_icons[i].click) dock_icons[i].click();
                    usleep(200000); return;
                }
            }
            for (i = 0; i < DESKTOP_COUNT; i++) {
                if (mouse_x >= desktop_icons[i].x && mouse_x < desktop_icons[i].x + ICON_SIZE &&
                    mouse_y >= desktop_icons[i].y && mouse_y < desktop_icons[i].y + ICON_SIZE) {
                    if (desktop_icons[i].click) desktop_icons[i].click();
                    usleep(200000); return;
                }
            }
        }
    }
}

void draw_mouse(void) {
    int x = mouse_x, y = mouse_y;
    pixel(x, y, COLOR_WHITE);
    pixel(x+1, y, COLOR_WHITE);
    pixel(x+2, y, COLOR_WHITE);
    pixel(x, y+1, COLOR_WHITE);
    pixel(x, y+2, COLOR_WHITE);
    pixel(x+1, y+1, COLOR_BLACK);
}

/* 信号处理 */
void signal_handler(int sig) { running = 0; }

/* 主函数 */
int main(int argc, char *argv[]) {
    printf("[青柠OS] 启动桌面环境 v3.0...\n");
    signal(SIGINT, signal_handler);
    signal(SIGTERM, signal_handler);

    if (fb_init() < 0) {
        printf("[青柠OS] 无法初始化帧缓冲，进入文本模式\n");
        execlp("/bin/sh", "sh", NULL);
        return 1;
    }

    mouse_init();
    memset(windows, 0, sizeof(windows));
    printf("[青柠OS] 桌面就绪 (%dx%d)\n", screen_w, screen_h);

    while (running) {
        draw_desktop();
        int i;
        for (i = 0; i < window_count; i++) draw_window(&windows[i], i == active_win);
        mouse_poll();
        draw_mouse();
        usleep(16666);
    }

    if (mouse_fd >= 0) close(mouse_fd);
    fb_close();
    printf("[青柠OS] 桌面已退出\n");
    return 0;
}
