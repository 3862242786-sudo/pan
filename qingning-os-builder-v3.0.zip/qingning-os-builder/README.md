# 青柠OS 构建工具 v3.0

双平台构建工具，**同一个压缩包**，无论在 Linux 还是 Windows 上运行，构建出的 ISO 完全相同。

## 目录结构

```
qingning-os-builder/
├── scripts/
│   ├── Build-Linux.sh        # Linux 构建脚本
│   └── Build-Windows.ps1     # Windows 构建脚本
├── src/
│   ├── qingning-desktop.c    # GUI 源代码
│   └── Makefile
├── config/
│   └── autounattend.xml      # Windows版无人值守配置（可选）
├── assets/
│   └── qingning-setup.bat    # Windows版首次启动脚本（可选）
└── README.md
```

## 系统要求

### Linux
- Debian/Ubuntu 或任何 Linux 发行版
- `curl`, `gcc`, `xorriso` 或 `genisoimage`

### Windows
- Windows 10/11 (64位)
- PowerShell 5.1+（管理员权限）
- [7-Zip](https://www.7-zip.org/)（必需）
- `curl`（Windows 10 自带）
- `gcc` / MinGW-w64（可选，用于编译 GUI）

## 使用方法

### Linux

```bash
cd qingning-os-builder
chmod +x scripts/Build-Linux.sh
./scripts/Build-Linux.sh
```

### Windows

右键 `scripts/Build-Windows.ps1` → **使用 PowerShell 运行**

## 输出

两个平台构建出的 ISO 完全相同：

```
output/QingningOS-v3.0.iso    # 约 25MB，可启动的 Linux 系统
```

## 特性

- Linux Kernel 6.x (Alpine)
- 自主 GUI：任务栏、Dock、桌面图标、窗口管理
- 鼠标支持
- 终端、浏览器、文件管理器、设置、关于窗口
- ISOLINUX 引导菜单（图形界面 / 文本模式）

## 开源协议

MIT License
