@echo off
chcp 65001 >nul
title 青柠OS 首次启动配置
color 0A

echo.
echo  ╔══════════════════════════════════════════════════════════════╗
echo  ║                  青柠OS 正在初始化...                        ║
echo  ╚══════════════════════════════════════════════════════════════╝
echo.

mkdir "C:\QingningOS" 2>nul
mkdir "C:\QingningOS\Themes" 2>nul
mkdir "C:\QingningOS\Wallpapers" 2>nul

echo  [1/5] 设置青柠主题色...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v AppsUseLightTheme /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v SystemUsesLightTheme /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v ColorPrevalence /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v AccentColor /t REG_DWORD /d 0xff5ec522 /f >nul 2>&1

echo  [2/5] 配置任务栏...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v TaskbarAl /t REG_DWORD /d 1 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v ShowTaskViewButton /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Search" /v SearchboxTaskbarMode /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v TaskbarDa /t REG_DWORD /d 0 /f >nul 2>&1

echo  [3/5] 配置桌面...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel" /v "{20D04FE0-3AEA-1069-A2D8-08002B30309D}" /t REG_DWORD /d 0 /f >nul 2>&1

echo  [4/5] 创建青柠快捷方式...
set "DESKTOP=%USERPROFILE%\Desktop"
(
echo [InternetShortcut]
echo URL=https://3862242786-sudo.github.io/pan/
) > "%DESKTOP%\青柠网盘.url"
(
echo [InternetShortcut]
echo URL=https://3862242786-sudo.github.io/pan/qingning-store.html
) > "%DESKTOP%\青柠应用商店.url"
(
echo [InternetShortcut]
echo URL=https://3862242786-sudo.github.io/pan/qingning-guide.html
) > "%DESKTOP%\青柠使用教程.url"

echo  [5/5] 应用系统标识...
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\OEMInformation" /v Manufacturer /t REG_SZ /d "青柠OS" /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\OEMInformation" /v Model /t REG_SZ /d "QingningOS 3.0" /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\OEMInformation" /v SupportURL /t REG_SZ /d "https://3862242786-sudo.github.io/pan/qingning-os.html" /f >nul 2>&1

taskkill /f /im explorer.exe >nul 2>&1
start explorer.exe

echo.
echo  ╔══════════════════════════════════════════════════════════════╗
echo  ║              青柠OS 初始化完成！                             ║
echo  ╚══════════════════════════════════════════════════════════════╝
echo.
echo  欢迎使用青柠OS Windows版！
echo  桌面已添加青柠网盘、应用商店、使用教程快捷方式。
echo.
timeout /t 3 /nobreak >nul
exit /b 0
