#!/bin/bash
# ============================================================
#   青柠OS 构建工具 v3.0 - Linux版
#   用于构建青柠OS ISO镜像
# ============================================================

set -e

# ---- 颜色定义 ----
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

# ---- 辅助函数 ----
print_info()    { echo -e "${BLUE}[信息]${NC} $1"; }
print_success() { echo -e "${GREEN}[成功]${NC} $1"; }
print_warn()    { echo -e "${YELLOW}[警告]${NC} $1"; }
print_error()   { echo -e "${RED}[错误]${NC} $1"; }

print_banner() {
    echo -e "${CYAN}${BOLD}"
    echo '  ╔══════════════════════════════════════════════════════╗'
    echo '  ║          青柠OS 构建工具 v3.0 - Linux版            ║'
    echo '  ║          QingningOS ISO Builder                     ║'
    echo '  ╚══════════════════════════════════════════════════════╝'
    echo -e "${NC}"
}

print_step() {
    echo ""
    echo -e "${YELLOW}${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${CYAN}${BOLD}  步骤 $1: $2${NC}"
    echo -e "${YELLOW}${BOLD}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
}

# ---- 目录定义 ----
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
SRC_DIR="${PROJECT_DIR}/src"
CONFIG_DIR="${PROJECT_DIR}/config"
OUTPUT_DIR="${PROJECT_DIR}/output"
WORK_DIR="${PROJECT_DIR}/build"
ISO_ROOT="${WORK_DIR}/iso"

ALPINE_MIRRORS=(
    "https://dl-cdn.alpinelinux.org/alpine/v3.22/releases/x86_64/netboot"
    "https://mirror.tuna.tsinghua.edu.cn/alpine/v3.22/releases/x86_64/netboot"
    "https://mirrors.aliyun.com/alpine/v3.22/releases/x86_64/netboot"
)

ISOLINUX_BASE="https://raw.githubusercontent.com/coreboot/syslinux/syslinux-6.04/bios"
ISO_OUTPUT="${OUTPUT_DIR}/QingningOS-v3.0.iso"

# ---- 清理 ----
cleanup() {
    if [ -d "${WORK_DIR}" ]; then
        rm -rf "${WORK_DIR}"
    fi
}

# ---- 下载函数（带镜像回退） ----
download_with_fallback() {
    local filename="$1"
    local dest="$2"
    shift 2
    local urls=("$@")

    for url in "${urls[@]}"; do
        local full_url="${url}/${filename}"
        print_info "尝试下载: ${full_url}"
        if curl -fsSL --connect-timeout 15 --max-time 120 -o "${dest}" "${full_url}"; then
            print_success "下载完成: ${filename}"
            return 0
        else
            print_warn "下载失败: ${full_url}"
        fi
    done
    print_error "所有镜像均下载失败: ${filename}"
    exit 1
}

# ---- 下载 ISOLINUX 文件 ----
download_isolinux() {
    local filename="$1"
    local rel_path="$2"
    local dest="$3"
    local full_url="${ISOLINUX_BASE}/${rel_path}"

    print_info "下载 ISOLINUX: ${filename}"
    if curl -fsSL --connect-timeout 15 --max-time 120 -o "${dest}" "${full_url}"; then
        print_success "下载完成: ${filename}"
    else
        print_error "下载失败: ${filename} (${full_url})"
        exit 1
    fi
}

# ============================================================
#   主流程
# ============================================================

print_banner

# ---- 步骤 0: 环境检查 ----
print_step "0" "环境检查"

if command -v xorriso &>/dev/null; then
    ISO_TOOL="xorriso"
    print_success "找到 xorriso"
elif command -v genisoimage &>/dev/null; then
    ISO_TOOL="genisoimage"
    print_success "找到 genisoimage"
elif command -v mkisofs &>/dev/null; then
    ISO_TOOL="genisoimage"
    print_success "找到 mkisofs (将作为 genisoimage 使用)"
else
    print_error "未找到 xorriso 或 genisoimage，请安装其中一个"
    exit 1
fi

if command -v gcc &>/dev/null; then
    HAS_GCC=true
    print_success "找到 gcc"
else
    HAS_GCC=false
    print_warn "未找到 gcc，将跳过桌面程序编译"
fi

if command -v curl &>/dev/null; then
    print_success "找到 curl"
else
    print_error "未找到 curl，请安装 curl"
    exit 1
fi

# ---- 步骤 1: 准备工作目录 ----
print_step "1" "准备工作目录"

cleanup
mkdir -p "${WORK_DIR}"
mkdir -p "${ISO_ROOT}/boot"
mkdir -p "${ISO_ROOT}/isolinux"
mkdir -p "${OUTPUT_DIR}"
print_success "工作目录已创建: ${WORK_DIR}"

# ---- 步骤 2: 下载 Alpine Linux 内核 ----
print_step "2" "下载 Alpine Linux 3.22 内核"

download_with_fallback "vmlinuz-virt" "${ISO_ROOT}/boot/vmlinuz" "${ALPINE_MIRRORS[@]}"
download_with_fallback "initramfs-virt" "${ISO_ROOT}/boot/initramfs" "${ALPINE_MIRRORS[@]}"

# ---- 步骤 3: 编译桌面程序 ----
print_step "3" "编译桌面程序"

if [ "${HAS_GCC}" = true ] && [ -f "${SRC_DIR}/qingning-desktop.c" ]; then
    mkdir -p "${ISO_ROOT}/usr/bin"
    if gcc -o "${ISO_ROOT}/usr/bin/qingning-desktop" "${SRC_DIR}/qingning-desktop.c" -lm 2>/dev/null; then
        print_success "桌面程序编译成功"
    else
        print_warn "桌面程序编译失败，图形界面可能不可用"
    fi
else
    if [ "${HAS_GCC}" = false ]; then
        print_warn "跳过桌面程序编译（未找到 gcc）"
    else
        print_warn "跳过桌面程序编译（未找到源码文件 ${SRC_DIR}/qingning-desktop.c）"
    fi
fi

# ---- 步骤 4: 创建系统层文件 ----
print_step "4" "创建系统层文件"

mkdir -p "${ISO_ROOT}/etc"
mkdir -p "${ISO_ROOT}/etc/profile.d"
mkdir -p "${ISO_ROOT}/sbin"
mkdir -p "${ISO_ROOT}/usr/bin"

# os-release
cat > "${ISO_ROOT}/etc/os-release" << 'OSRELEASE'
NAME="青柠OS"
VERSION="3.0.0"
ID=qingning-os
ID_LIKE=alpine
PRETTY_NAME="青柠OS 3.0.0 (Linux)"
HOME_URL="https://3862242786-sudo.github.io/pan/qingning-os.html"
SUPPORT_URL="https://3862242786-sudo.github.io/pan/qingning-guide.html"
BUG_REPORT_URL="https://github.com/3862242786-sudo/qingning-os/issues"
LOGO=qingning-os
OSRELEASE
print_success "已创建 etc/os-release"

# sbin/init
cat > "${ISO_ROOT}/sbin/init" << 'INITEOF'
#!/bin/sh
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
mount -t proc proc /proc 2>/dev/null
mount -t sysfs sysfs /sys 2>/dev/null
mount -t devtmpfs devtmpfs /dev 2>/dev/null
mkdir -p /dev/pts /dev/shm /tmp /run
mount -t devpts devpts /dev/pts 2>/dev/null
mount -t tmpfs tmpfs /tmp 2>/dev/null
mount -t tmpfs tmpfs /run 2>/dev/null
mount -t tmpfs tmpfs /dev/shm 2>/dev/null
hostname qingning-os 2>/dev/null
echo '[青柠OS] 加载显卡驱动...'
modprobe bochs_drm 2>/dev/null
modprobe virtio_gpu 2>/dev/null
modprobe vmwgfx 2>/dev/null
modprobe cirrus 2>/dev/null
sleep 1
if [ -c /dev/fb0 ] && [ -x /usr/bin/qingning-desktop ]; then
    echo '[青柠OS] 启动图形界面...'
    /usr/bin/qingning-desktop
else
    echo '[青柠OS] 进入文本模式'
    exec /bin/sh
fi
INITEOF
chmod 755 "${ISO_ROOT}/sbin/init"
print_success "已创建 sbin/init"

# etc/profile.d/qingning.sh
cat > "${ISO_ROOT}/etc/profile.d/qingning.sh" << 'PROFILEEOF'
export PS1='\[\033[0;32m\]\u@青柠OS\[\033[0m\]:\[\033[0;34m\]\w\[\033[0m\]# '
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export TERM=linux
export HOME=/root
alias ll='ls -la --color=auto'
alias la='ls -a --color=auto'
echo ''
echo '  ╔══════════════════════════════════════════════════════╗'
echo '  ║    青柠OS 3.0.0 (Linux)                 ║'
echo '  ║    Linux Kernel + 自主GUI图形界面        ║'
echo '  ╚══════════════════════════════════════════════════════╝'
echo ''
PROFILEEOF
chmod 644 "${ISO_ROOT}/etc/profile.d/qingning.sh"
print_success "已创建 etc/profile.d/qingning.sh"

# ---- 步骤 5: 创建 ISOLINUX 引导配置 ----
print_step "5" "创建 ISOLINUX 引导配置"

cat > "${ISO_ROOT}/isolinux/isolinux.cfg" << 'ISOLINUXEOF'
DEFAULT qingning
PROMPT 0
TIMEOUT 30
UI menu.c32

MENU TITLE 青柠OS 3.0.0
MENU COLOR border       30;44 #40ffffff #a0000000 std
MENU COLOR title        1;36;44 #9033ccff #a0000000 std
MENU COLOR sel          7;37;40 #e0ffffff #20ffffff all

LABEL qingning
    MENU LABEL 青柠OS 3.0.0 (图形界面)
    MENU DEFAULT
    KERNEL /boot/vmlinuz
    INITRD /boot/initramfs
    APPEND modules=loop,squashfs,sd-mod,usb-storage,bochs_drm,virtio_gpu,vmwgfx quiet nomodeset

LABEL qingning-text
    MENU LABEL 青柠OS 3.0.0 (文本模式)
    KERNEL /boot/vmlinuz
    INITRD /boot/initramfs
    APPEND modules=loop,squashfs,sd-mod,usb-storage quiet nomodeset 3
ISOLINUXEOF
print_success "已创建 isolinux/isolinux.cfg"

# ---- 步骤 6: 下载 ISOLINUX 引导文件 ----
print_step "6" "下载 ISOLINUX 引导文件"

download_isolinux "isolinux.bin"  "core/isolinux.bin"                                          "${ISO_ROOT}/isolinux/isolinux.bin"
download_isolinux "ldlinux.c32"    "com32/elflink/ldlinux/ldlinux.c32"                         "${ISO_ROOT}/isolinux/ldlinux.c32"
download_isolinux "menu.c32"       "com32/menu/menu.c32"                                        "${ISO_ROOT}/isolinux/menu.c32"
download_isolinux "libutil.c32"    "com32/libutil/libutil.c32"                                 "${ISO_ROOT}/isolinux/libutil.c32"

# ---- 步骤 7: 生成 ISO ----
print_step "7" "生成 ISO 镜像"

if [ "${ISO_TOOL}" = "xorriso" ]; then
    print_info "使用 xorriso 生成 ISO..."
    xorriso \
        -as mkisofs \
        -o "${ISO_OUTPUT}" \
        -isohybrid-mbr "${ISO_ROOT}/isolinux/isolinux.bin" \
        -c isolinux/boot.cat \
        -b isolinux/isolinux.bin \
        -no-emul-boot \
        -boot-load-size 4 \
        -boot-info-table \
        -J -R -V "QingningOS 3.0.0" \
        "${ISO_ROOT}"
elif [ "${ISO_TOOL}" = "genisoimage" ]; then
    print_info "使用 genisoimage 生成 ISO..."
    genisoimage \
        -o "${ISO_OUTPUT}" \
        -c isolinux/boot.cat \
        -b isolinux/isolinux.bin \
        -no-emul-boot \
        -boot-load-size 4 \
        -boot-info-table \
        -J -R -V "QingningOS 3.0.0" \
        "${ISO_ROOT}"
fi

if [ -f "${ISO_OUTPUT}" ]; then
    local_size=$(du -h "${ISO_OUTPUT}" | cut -f1)
    print_success "ISO 镜像生成成功: ${ISO_OUTPUT} (${local_size})"
else
    print_error "ISO 镜像生成失败"
    exit 1
fi

# ---- 完成 ----
echo ""
echo -e "${GREEN}${BOLD}"
echo '  ╔══════════════════════════════════════════════════════╗'
echo '  ║              构建完成!                              ║'
echo '  ║  输出文件: QingningOS-v3.0.iso                     ║'
echo '  ╚══════════════════════════════════════════════════════╝'
echo -e "${NC}"
echo -e "  输出路径: ${CYAN}${ISO_OUTPUT}${NC}"
echo ""

# ---- 清理构建目录 ----
print_info "清理构建目录..."
cleanup
print_success "构建目录已清理"
