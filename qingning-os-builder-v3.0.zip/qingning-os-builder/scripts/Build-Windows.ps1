<#
.SYNOPSIS
    青柠OS 构建工具 v3.0 - Windows版
    用于构建青柠OS ISO镜像
.DESCRIPTION
    该脚本在 Windows 环境下构建青柠OS ISO镜像。
    需要 oscdimg.exe 或 7z.exe 来生成 ISO。
#>

#Requires -Version 5.1

[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# ============================================================
#   青柠OS 构建工具 v3.0 - Windows版
# ============================================================

# ---- 辅助函数 ----
function Write-Info    { param([string]$Msg) Write-Host "[信息] $Msg" -ForegroundColor Blue }
function Write-Ok      { param([string]$Msg) Write-Host "[成功] $Msg" -ForegroundColor Green }
function Write-Warn    { param([string]$Msg) Write-Host "[警告] $Msg" -ForegroundColor Yellow }
function Write-Err     { param([string]$Msg) Write-Host "[错误] $Msg" -ForegroundColor Red }

function Write-Step {
    param(
        [int]$Number,
        [string]$Title
    )
    Write-Host ""
    Write-Host ("=" * 64) -ForegroundColor Yellow
    Write-Host "  步骤 $Number`: $Title" -ForegroundColor Cyan
    Write-Host ("=" * 64) -ForegroundColor Yellow
    Write-Host ""
}

function Write-Banner {
    Write-Host ""
    Write-Host "  ============================================================" -ForegroundColor Cyan
    Write-Host "  |          青柠OS 构建工具 v3.0 - Windows版              |" -ForegroundColor Cyan
    Write-Host "  |          QingningOS ISO Builder                       |" -ForegroundColor Cyan
    Write-Host "  ============================================================" -ForegroundColor Cyan
    Write-Host ""
}

# ---- 目录定义 ----
$ScriptDir    = $PSScriptRoot
if (-not $ScriptDir) { $ScriptDir = Get-Location }
$ProjectDir   = (Resolve-Path (Join-Path $ScriptDir "..")).Path
$SrcDir       = Join-Path $ProjectDir "src"
$ConfigDir    = Join-Path $ProjectDir "config"
$OutputDir    = Join-Path $ProjectDir "output"
$WorkDir      = Join-Path $ProjectDir "build"
$IsoRoot      = Join-Path $WorkDir "iso"
$IsoOutput    = Join-Path $OutputDir "QingningOS-v3.0.iso"

$AlpineMirrors = @(
    "https://dl-cdn.alpinelinux.org/alpine/v3.22/releases/x86_64/netboot",
    "https://mirror.tuna.tsinghua.edu.cn/alpine/v3.22/releases/x86_64/netboot",
    "https://mirrors.aliyun.com/alpine/v3.22/releases/x86_64/netboot"
)

$IsolinuxBase = "https://raw.githubusercontent.com/coreboot/syslinux/syslinux-6.04/bios"

# ---- 清理 ----
function Remove-BuildDir {
    if (Test-Path $WorkDir) {
        Remove-Item -Path $WorkDir -Recurse -Force -ErrorAction SilentlyContinue
    }
}

# ---- 下载函数（带镜像回退） ----
function Download-WithFallback {
    param(
        [string]$Filename,
        [string]$DestPath,
        [string[]]$Urls
    )

    foreach ($url in $Urls) {
        $fullUrl = "$url/$Filename"
        Write-Info "尝试下载`: $fullUrl"
        try {
            Invoke-WebRequest -Uri $fullUrl -OutFile $DestPath -UseBasicParsing `
                -TimeoutSec 120 -ErrorAction Stop
            Write-Ok "下载完成`: $Filename"
            return $true
        }
        catch {
            Write-Warn "下载失败`: $fullUrl"
        }
    }

    Write-Err "所有镜像均下载失败`: $Filename"
    exit 1
}

# ---- 下载 ISOLINUX 文件 ----
function Download-Isolinux {
    param(
        [string]$Filename,
        [string]$RelPath,
        [string]$DestPath
    )

    $fullUrl = "$IsolinuxBase/$RelPath"
    Write-Info "下载 ISOLINUX`: $Filename"
    try {
        Invoke-WebRequest -Uri $fullUrl -OutFile $DestPath -UseBasicParsing `
            -TimeoutSec 120 -ErrorAction Stop
        Write-Ok "下载完成`: $Filename"
    }
    catch {
        Write-Err "下载失败`: $Filename ($fullUrl)"
        exit 1
    }
}

# ============================================================
#   主流程
# ============================================================

Write-Banner

# ---- 步骤 0: 环境检查 ----
Write-Step 0 "环境检查"

$IsoTool = $null
if (Get-Command oscdimg.exe -ErrorAction SilentlyContinue) {
    $IsoTool = "oscdimg"
    Write-Ok "找到 oscdimg.exe"
}
elseif (Get-Command 7z.exe -ErrorAction SilentlyContinue) {
    $IsoTool = "7z"
    Write-Ok "找到 7z.exe"
}
else {
    Write-Err "未找到 oscdimg.exe 或 7z.exe，请安装其中一个"
    Write-Host "  oscdimg.exe - Windows ADK 的一部分" -ForegroundColor Gray
    Write-Host "  7z.exe     - 7-Zip (https://7-zip.org)" -ForegroundColor Gray
    exit 1
}

$HasGcc = $false
if (Get-Command gcc.exe -ErrorAction SilentlyContinue) {
    $HasGcc = $true
    Write-Ok "找到 gcc.exe"
}
else {
    Write-Warn "未找到 gcc.exe，将跳过桌面程序编译"
}

try {
    $null = Invoke-WebRequest -Uri "https://dl-cdn.alpinelinux.org" -UseBasicParsing `
        -TimeoutSec 10 -Method Head -ErrorAction Stop
    Write-Ok "网络连接正常"
}
catch {
    Write-Err "无法连接到网络，请检查网络设置"
    exit 1
}

# ---- 步骤 1: 准备工作目录 ----
Write-Step 1 "准备工作目录"

Remove-BuildDir
$null = New-Item -ItemType Directory -Path (Join-Path $IsoRoot "boot") -Force
$null = New-Item -ItemType Directory -Path (Join-Path $IsoRoot "isolinux") -Force
$null = New-Item -ItemType Directory -Path $OutputDir -Force
Write-Ok "工作目录已创建`: $WorkDir"

# ---- 步骤 2: 下载 Alpine Linux 内核 ----
Write-Step 2 "下载 Alpine Linux 3.22 内核"

Download-WithFallback -Filename "vmlinuz-virt" `
    -DestPath (Join-Path $IsoRoot "boot\vmlinuz") `
    -Urls $AlpineMirrors

Download-WithFallback -Filename "initramfs-virt" `
    -DestPath (Join-Path $IsoRoot "boot\initramfs") `
    -Urls $AlpineMirrors

# ---- 步骤 3: 编译桌面程序 ----
Write-Step 3 "编译桌面程序"

if ($HasGcc -and (Test-Path (Join-Path $SrcDir "qingning-desktop.c"))) {
    $null = New-Item -ItemType Directory -Path (Join-Path $IsoRoot "usr\bin") -Force
    $desktopSrc = Join-Path $SrcDir "qingning-desktop.c"
    $desktopOut = Join-Path $IsoRoot "usr\bin\qingning-desktop.exe"
    try {
        & gcc.exe -o $desktopOut $desktopSrc -lm 2>$null
        if ($LASTEXITCODE -eq 0) {
            Write-Ok "桌面程序编译成功"
        }
        else {
            Write-Warn "桌面程序编译失败，图形界面可能不可用"
        }
    }
    catch {
        Write-Warn "桌面程序编译失败，图形界面可能不可用"
    }
}
else {
    if (-not $HasGcc) {
        Write-Warn "跳过桌面程序编译（未找到 gcc.exe）"
    }
    else {
        Write-Warn "跳过桌面程序编译（未找到源码文件 $($SrcDir)\qingning-desktop.c）"
    }
}

# ---- 步骤 4: 创建系统层文件 ----
Write-Step 4 "创建系统层文件"

$null = New-Item -ItemType Directory -Path (Join-Path $IsoRoot "etc") -Force
$null = New-Item -ItemType Directory -Path (Join-Path $IsoRoot "etc\profile.d") -Force
$null = New-Item -ItemType Directory -Path (Join-Path $IsoRoot "sbin") -Force
$null = New-Item -ItemType Directory -Path (Join-Path $IsoRoot "usr\bin") -Force

# os-release
$osReleaseContent = @'
NAME="青柠OS"
VERSION="3.0.0"
ID=qingning-os
ID_LIKE=alpine
PRETTY_NAME="青柠OS 3.0.0 (Linux)"
HOME_URL="https://3862242786-sudo.github.io/pan/qingning-os.html"
SUPPORT_URL="https://3862242786-sudo.github.io/pan/qingning-guide.html"
BUG_REPORT_URL="https://github.com/3862242786-sudo/qingning-os/issues"
LOGO=qingning-os
'@
Set-Content -Path (Join-Path $IsoRoot "etc\os-release") -Value $osReleaseContent -NoNewline -Encoding UTF8
Write-Ok "已创建 etc\os-release"

# sbin/init
$initContent = @'
#!/bin/sh
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
mount -t proc proc /proc 2>/dev/null
mount -t sysfs sysfs /sys 2>/dev/null
mount -t devtmpfs devtmpfs /dev 2>/dev/null
mkdir -p /dev/pts /dev/shm /tmp /run
mount -t devpts devpts /dev/pts 2>/dev/null
mount -t tmpfs tmpfs /tmp 2>/dev/null
mount -t tmpfs tmpfs /run 2>/dev/null
mount -t tmpfs tmpfs /dev/shm 2>/dev/null
hostname qingning-os 2>/dev/null
echo '[青柠OS] 加载显卡驱动...'
modprobe bochs_drm 2>/dev/null
modprobe virtio_gpu 2>/dev/null
modprobe vmwgfx 2>/dev/null
modprobe cirrus 2>/dev/null
sleep 1
if [ -c /dev/fb0 ] && [ -x /usr/bin/qingning-desktop ]; then
    echo '[青柠OS] 启动图形界面...'
    /usr/bin/qingning-desktop
else
    echo '[青柠OS] 进入文本模式'
    exec /bin/sh
fi
'@
Set-Content -Path (Join-Path $IsoRoot "sbin\init") -Value $initContent -NoNewline -Encoding UTF8
Write-Ok "已创建 sbin\init"

# etc/profile.d/qingning.sh
$profileContent = @'
export PS1='\[\033[0;32m\]\u@青柠OS\[\033[0m\]:\[\033[0;34m\]\w\[\033[0m\]# '
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export TERM=linux
export HOME=/root
alias ll='ls -la --color=auto'
alias la='ls -a --color=auto'
echo ''
echo '  ╔══════════════════════════════════════════════════════╗'
echo '  ║    青柠OS 3.0.0 (Linux)                 ║'
echo '  ║    Linux Kernel + 自主GUI图形界面        ║'
echo '  ╚══════════════════════════════════════════════════════╝'
echo ''
'@
Set-Content -Path (Join-Path $IsoRoot "etc\profile.d\qingning.sh") -Value $profileContent -NoNewline -Encoding UTF8
Write-Ok "已创建 etc\profile.d\qingning.sh"

# ---- 步骤 5: 创建 ISOLINUX 引导配置 ----
Write-Step 5 "创建 ISOLINUX 引导配置"

$isolinuxCfgContent = @'
DEFAULT qingning
PROMPT 0
TIMEOUT 30
UI menu.c32

MENU TITLE 青柠OS 3.0.0
MENU COLOR border       30;44 #40ffffff #a0000000 std
MENU COLOR title        1;36;44 #9033ccff #a0000000 std
MENU COLOR sel          7;37;40 #e0ffffff #20ffffff all

LABEL qingning
    MENU LABEL 青柠OS 3.0.0 (图形界面)
    MENU DEFAULT
    KERNEL /boot/vmlinuz
    INITRD /boot/initramfs
    APPEND modules=loop,squashfs,sd-mod,usb-storage,bochs_drm,virtio_gpu,vmwgfx quiet nomodeset

LABEL qingning-text
    MENU LABEL 青柠OS 3.0.0 (文本模式)
    KERNEL /boot/vmlinuz
    INITRD /boot/initramfs
    APPEND modules=loop,squashfs,sd-mod,usb-storage quiet nomodeset 3
'@
Set-Content -Path (Join-Path $IsoRoot "isolinux\isolinux.cfg") -Value $isolinuxCfgContent -NoNewline -Encoding UTF8
Write-Ok "已创建 isolinux\isolinux.cfg"

# ---- 步骤 6: 下载 ISOLINUX 引导文件 ----
Write-Step 6 "下载 ISOLINUX 引导文件"

Download-Isolinux -Filename "isolinux.bin" `
    -RelPath "core/isolinux.bin" `
    -DestPath (Join-Path $IsoRoot "isolinux\isolinux.bin")

Download-Isolinux -Filename "ldlinux.c32" `
    -RelPath "com32/elflink/ldlinux/ldlinux.c32" `
    -DestPath (Join-Path $IsoRoot "isolinux\ldlinux.c32")

Download-Isolinux -Filename "menu.c32" `
    -RelPath "com32/menu/menu.c32" `
    -DestPath (Join-Path $IsoRoot "isolinux\menu.c32")

Download-Isolinux -Filename "libutil.c32" `
    -RelPath "com32/libutil/libutil.c32" `
    -DestPath (Join-Path $IsoRoot "isolinux\libutil.c32")

# ---- 步骤 7: 生成 ISO ----
Write-Step 7 "生成 ISO 镜像"

if ($IsoTool -eq "oscdimg") {
    Write-Info "使用 oscdimg.exe 生成 ISO..."
    & oscdimg.exe -n -m -b"$IsoRoot\isolinux\isolinux.bin" `
        -j"$IsoRoot" "$IsoOutput" "QingningOS_3.0.0" `
        2>$null
    if ($LASTEXITCODE -ne 0) {
        Write-Warn "oscdimg 执行返回非零退出码，尝试备用参数..."
        & oscdimg.exe -n -m "$IsoRoot" "$IsoOutput" "QingningOS_3.0.0" `
            2>$null
    }
}
elseif ($IsoTool -eq "7z") {
    Write-Info "使用 7z.exe 生成 ISO..."
    & 7z.exe a -tiso -r "$IsoOutput" "$IsoRoot\*" 2>$null
}

if (Test-Path $IsoOutput) {
    $fileSize = (Get-Item $IsoOutput).Length
    $fileSizeMB = [math]::Round($fileSize / 1MB, 2)
    Write-Ok "ISO 镜像生成成功`: $IsoOutput (${fileSizeMB} MB)"
}
else {
    Write-Err "ISO 镜像生成失败"
    exit 1
}

# ---- 完成 ----
Write-Host ""
Write-Host "  ============================================================" -ForegroundColor Green
Write-Host "  |              构建完成!                                    |" -ForegroundColor Green
Write-Host "  |  输出文件: QingningOS-v3.0.iso                           |" -ForegroundColor Green
Write-Host "  ============================================================" -ForegroundColor Green
Write-Host ""
Write-Host "  输出路径: " -NoNewline
Write-Host $IsoOutput -ForegroundColor Cyan
Write-Host ""

# ---- 清理构建目录 ----
Write-Info "清理构建目录..."
Remove-BuildDir
Write-Ok "构建目录已清理"

# ---- 暂停等待用户查看结果 ----
Write-Host ""
Write-Host "  按回车键退出..." -ForegroundColor Yellow
Read-Host
