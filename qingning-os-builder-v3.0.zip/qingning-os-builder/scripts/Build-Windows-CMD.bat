@echo off
chcp 65001 >nul
title 青柠OS构建工具 v3.0 - Windows CMD版
cls

echo.
echo  ================================================================
echo.
echo          青柠OS 构建工具 v3.0 - Windows CMD版
echo          纯批处理，无需PowerShell
echo.
echo  ================================================================
echo.

:: 设置路径
set "SCRIPT_DIR=%~dp0"
set "BUILD_DIR=%SCRIPT_DIR%.."
set "WORK_DIR=%BUILD_DIR%\work"
set "ISO_DIR=%WORK_DIR%\iso"
set "KERNEL_DIR=%WORK_DIR%\kernel"
set "OVERLAY_DIR=%WORK_DIR%\overlay"
set "OUTPUT_DIR=%BUILD_DIR%\output"
set "SRC_DIR=%BUILD_DIR%\src"

echo [信息] 检查依赖...

:: 设置curl路径（直接使用系统路径，避免PATH问题）
set "CURL_CMD=C:\Windows\System32\curl.exe"
if not exist "%CURL_CMD%" (
    echo [错误] 未找到 curl！
    echo 请确保系统已安装 curl。
    pause
    exit /b 1
)
echo [OK] curl

:: 检查WinRAR或7-Zip
set "ZIP_TOOL="
set "ZIP_TYPE="

WinRAR.exe >nul 2>&1
if not errorlevel 1 (
    set "ZIP_TOOL=WinRAR.exe"
    set "ZIP_TYPE=winrar"
    echo [OK] WinRAR
    goto :found_zip
)

rar.exe >nul 2>&1
if not errorlevel 1 (
    set "ZIP_TOOL=rar.exe"
    set "ZIP_TYPE=winrar"
    echo [OK] rar.exe
    goto :found_zip
)

7z.exe >nul 2>&1
if not errorlevel 1 (
    set "ZIP_TOOL=7z.exe"
    set "ZIP_TYPE=7z"
    echo [OK] 7-Zip
    goto :found_zip
)

:: 检查常见安装路径
if exist "C:\Program Files\WinRAR\WinRAR.exe" (
    set "ZIP_TOOL=C:\Program Files\WinRAR\WinRAR.exe"
    set "ZIP_TYPE=winrar"
    echo [OK] WinRAR (C:\Program Files\WinRAR\)
    goto :found_zip
)

if exist "C:\Program Files\7-Zip\7z.exe" (
    set "ZIP_TOOL=C:\Program Files\7-Zip\7z.exe"
    set "ZIP_TYPE=7z"
    echo [OK] 7-Zip (C:\Program Files\7-Zip\)
    goto :found_zip
)

if exist "C:\Program Files (x86)\7-Zip\7z.exe" (
    set "ZIP_TOOL=C:\Program Files (x86)\7-Zip\7z.exe"
    set "ZIP_TYPE=7z"
    echo [OK] 7-Zip (x86)
    goto :found_zip
)

echo [错误] 未找到 WinRAR 或 7-Zip！
echo 请安装其中一个：
echo   - WinRAR: https://www.rarlab.com
echo   - 7-Zip:  https://7-zip.org
pause
exit /b 1

:found_zip

:: 检查gcc（可选）
gcc --version >nul 2>&1
if not errorlevel 1 (
    echo [OK] gcc
    set "HAS_GCC=1"
) else (
    echo [提示] 未找到gcc，将跳过GUI编译
    set "HAS_GCC=0"
)

:: 清理并创建目录
echo.
echo [信息] 准备工作目录...
if exist "%WORK_DIR%" rmdir /s /q "%WORK_DIR%"
mkdir "%ISO_DIR%"
mkdir "%KERNEL_DIR%"
mkdir "%OVERLAY_DIR%"
mkdir "%OUTPUT_DIR%"

:: 下载Linux内核
echo.
echo [信息] 下载 Linux 内核...
echo [信息] 尝试镜像1: dl-cdn.alpinelinux.org...
%CURL_CMD% -L -o "%KERNEL_DIR%\vmlinuz-virt" "https://dl-cdn.alpinelinux.org/alpine/v3.22/releases/x86_64/netboot/vmlinuz-virt" --connect-timeout 15 --max-time 120 >nul 2>&1
%CURL_CMD% -L -o "%KERNEL_DIR%\initramfs-virt" "https://dl-cdn.alpinelinux.org/alpine/v3.22/releases/x86_64/netboot/initramfs-virt" --connect-timeout 15 --max-time 120 >nul 2>&1

:: 检查下载是否成功
if not exist "%KERNEL_DIR%\vmlinuz-virt" (
    echo [信息] 镜像1失败，尝试镜像2: tuna.tsinghua.edu.cn...
    %CURL_CMD% -L -o "%KERNEL_DIR%\vmlinuz-virt" "https://mirror.tuna.tsinghua.edu.cn/alpine/v3.22/releases/x86_64/netboot/vmlinuz-virt" --connect-timeout 15 --max-time 120 >nul 2>&1
    %CURL_CMD% -L -o "%KERNEL_DIR%\initramfs-virt" "https://mirror.tuna.tsinghua.edu.cn/alpine/v3.22/releases/x86_64/netboot/initramfs-virt" --connect-timeout 15 --max-time 120 >nul 2>&1
)

if not exist "%KERNEL_DIR%\vmlinuz-virt" (
    echo [信息] 镜像2失败，尝试镜像3: mirrors.aliyun.com...
    %CURL_CMD% -L -o "%KERNEL_DIR%\vmlinuz-virt" "https://mirrors.aliyun.com/alpine/v3.22/releases/x86_64/netboot/vmlinuz-virt" --connect-timeout 15 --max-time 120 >nul 2>&1
    %CURL_CMD% -L -o "%KERNEL_DIR%\initramfs-virt" "https://mirrors.aliyun.com/alpine/v3.22/releases/x86_64/netboot/initramfs-virt" --connect-timeout 15 --max-time 120 >nul 2>&1
)

if not exist "%KERNEL_DIR%\vmlinuz-virt" (
    echo [错误] 内核下载失败！请检查网络连接。
    pause
    exit /b 1
)
echo [OK] 内核下载完成

:: 编译图形界面
if "%HAS_GCC%"=="1" (
    if exist "%SRC_DIR%\qingning-desktop.c" (
        echo.
        echo [信息] 编译青柠桌面环境...
        cd /d "%SRC_DIR%"
        gcc -O2 -Wall -std=c99 -D_GNU_SOURCE -o qingning-desktop qingning-desktop.c >nul 2>&1
        cd /d "%SCRIPT_DIR%"
        if exist "%SRC_DIR%\qingning-desktop" (
            echo [OK] 编译成功
        ) else (
            echo [提示] 编译失败，将不包含图形界面
        )
    )
)

:: 创建系统层
echo.
echo [信息] 创建青柠OS系统层...

mkdir "%OVERLAY_DIR%\etc"
mkdir "%OVERLAY_DIR%\sbin"
mkdir "%OVERLAY_DIR%\etc\profile.d"
mkdir "%OVERLAY_DIR%\usr\bin"

:: os-release
(
echo NAME="青柠OS"
echo VERSION="3.0.0"
echo ID=qingning-os
echo ID_LIKE=alpine
echo PRETTY_NAME="青柠OS 3.0.0 (Linux)"
echo HOME_URL="https://3862242786-sudo.github.io/pan/qingning-os.html"
echo SUPPORT_URL="https://3862242786-sudo.github.io/pan/qingning-guide.html"
echo BUG_REPORT_URL="https://github.com/3862242786-sudo/qingning-os/issues"
echo LOGO=qingning-os
) > "%OVERLAY_DIR%\etc\os-release"

:: init脚本
(
echo #!/bin/sh
echo export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
echo mount -t proc proc /proc 2^>/dev/null
echo mount -t sysfs sysfs /sys 2^>/dev/null
echo mount -t devtmpfs devtmpfs /dev 2^>/dev/null
echo mkdir -p /dev/pts /dev/shm /tmp /run
echo mount -t devpts devpts /dev/pts 2^>/dev/null
echo mount -t tmpfs tmpfs /tmp 2^>/dev/null
echo mount -t tmpfs tmpfs /run 2^>/dev/null
echo mount -t tmpfs tmpfs /dev/shm 2^>/dev/null
echo hostname qingning-os 2^>/dev/null
echo echo '[青柠OS] 加载显卡驱动...'
echo modprobe bochs_drm 2^>/dev/null
echo modprobe virtio_gpu 2^>/dev/null
echo modprobe vmwgfx 2^>/dev/null
echo modprobe cirrus 2^>/dev/null
echo sleep 1
echo if [ -c /dev/fb0 ] ^&^& [ -x /usr/bin/qingning-desktop ]; then
echo     echo '[青柠OS] 启动图形界面...'
echo     /usr/bin/qingning-desktop
echo else
echo     echo '[青柠OS] 进入文本模式'
echo     exec /bin/sh
echo fi
) > "%OVERLAY_DIR%\sbin\init"

:: profile
copy "%OVERLAY_DIR%\etc\os-release" "%OVERLAY_DIR%\etc\os-release.bak" >nul 2>&1

:: 复制图形界面程序
if exist "%SRC_DIR%\qingning-desktop" (
    copy "%SRC_DIR%\qingning-desktop" "%OVERLAY_DIR%\usr\bin\" >nul 2>&1
    echo [OK] 复制图形界面程序
)

:: 创建ISO结构
echo.
echo [信息] 创建ISO结构...
mkdir "%ISO_DIR%\boot"
copy "%KERNEL_DIR%\vmlinuz-virt" "%ISO_DIR%\boot\vmlinuz" >nul 2>&1
copy "%KERNEL_DIR%\initramfs-virt" "%ISO_DIR%\boot\initramfs" >nul 2>&1

mkdir "%ISO_DIR%\isolinux"
(
echo DEFAULT qingning
echo PROMPT 0
echo TIMEOUT 30
echo UI menu.c32
echo.
echo MENU TITLE 青柠OS 3.0.0
echo MENU COLOR border       30;44 #40ffffff #a0000000 std
echo MENU COLOR title        1;36;44 #9033ccff #a0000000 std
echo MENU COLOR sel          7;37;40 #e0ffffff #20ffffff all
echo.
echo LABEL qingning
echo     MENU LABEL 青柠OS 3.0.0 (图形界面)
echo     MENU DEFAULT
echo     KERNEL /boot/vmlinuz
echo     INITRD /boot/initramfs
echo     APPEND modules=loop,squashfs,sd-mod,usb-storage,bochs_drm,virtio_gpu,vmwgfx quiet nomodeset
echo.
echo LABEL qingning-text
echo     MENU LABEL 青柠OS 3.0.0 (文本模式)
echo     KERNEL /boot/vmlinuz
echo     INITRD /boot/initramfs
echo     APPEND modules=loop,squashfs,sd-mod,usb-storage quiet nomodeset 3
) > "%ISO_DIR%\isolinux\isolinux.cfg"

:: 下载ISOLINUX引导文件
echo.
echo [信息] 下载ISOLINUX引导文件...
%CURL_CMD% -L -o "%ISO_DIR%\isolinux\isolinux.bin" "https://raw.githubusercontent.com/coreboot/syslinux/syslinux-6.04/bios/core/isolinux.bin" --connect-timeout 15 --max-time 60 >nul 2>&1
%CURL_CMD% -L -o "%ISO_DIR%\isolinux\ldlinux.c32" "https://raw.githubusercontent.com/coreboot/syslinux/syslinux-6.04/bios/com32/elflink/ldlinux/ldlinux.c32" --connect-timeout 15 --max-time 60 >nul 2>&1
%CURL_CMD% -L -o "%ISO_DIR%\isolinux\menu.c32" "https://raw.githubusercontent.com/coreboot/syslinux/syslinux-6.04/bios/com32/menu/menu.c32" --connect-timeout 15 --max-time 60 >nul 2>&1
%CURL_CMD% -L -o "%ISO_DIR%\isolinux\libutil.c32" "https://raw.githubusercontent.com/coreboot/syslinux/syslinux-6.04/bios/com32/libutil/libutil.c32" --connect-timeout 15 --max-time 60 >nul 2>&1

:: 生成ISO
echo.
echo [信息] 生成ISO...
set "FINAL_ISO=%OUTPUT_DIR%\QingningOS-v3.0.iso"

if "%ZIP_TYPE%"=="winrar" (
    echo [信息] 使用 WinRAR 生成ISO...
    "%ZIP_TOOL%" a -afiso -r -ep1 "%FINAL_ISO%" "%ISO_DIR%\*" >nul 2>&1
) else (
    echo [信息] 使用 7-Zip 生成ISO...
    "%ZIP_TOOL%" a -tiso -r "%FINAL_ISO%" "%ISO_DIR%\*" >nul 2>&1
)

:: 清理
echo [信息] 清理临时文件...
if exist "%WORK_DIR%" rmdir /s /q "%WORK_DIR%"

:: 检查结果
if exist "%FINAL_ISO%" (
    echo.
    echo  ================================================================
    echo.
    echo          构建完成！
    echo.
    echo          输出: %FINAL_ISO%
    echo.
    echo  ================================================================
    echo.
) else (
    echo.
    echo [错误] ISO生成失败！
    echo.
)

pause
