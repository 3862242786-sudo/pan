# ============================================================
# 青柠OS 构建脚本 - Windows版
# 与 Linux版 (build.sh) 构建相同的 ISO
# ============================================================

#Requires -RunAsAdministrator

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$Host.UI.RawUI.BackgroundColor = "Black"
$Host.UI.RawUI.ForegroundColor = "Green"
Clear-Host

function Write-Logo {
    Write-Host ""
    Write-Host "  ╔══════════════════════════════════════════════════════════════╗" -ForegroundColor Green
    Write-Host "  ║                                                              ║" -ForegroundColor Green
    Write-Host "  ║         青柠OS 构建工具 v3.0 - Windows版                     ║" -ForegroundColor Green
    Write-Host "  ║         构建与Linux版相同的青柠OS ISO                        ║" -ForegroundColor Green
    Write-Host "  ║                                                              ║" -ForegroundColor Green
    Write-Host "  ╚══════════════════════════════════════════════════════════════╝" -ForegroundColor Green
    Write-Host ""
}

function Write-Info { param([string]$m) Write-Host "  [信息] $m" -ForegroundColor Cyan }
function Write-OK   { param([string]$m) Write-Host "  [OK] $m" -ForegroundColor Green }
function Write-Warn { param([string]$m) Write-Host "  [警告] $m" -ForegroundColor Yellow }
function Write-Err  { param([string]$m) Write-Host "  [错误] $m" -ForegroundColor Red }

Write-Logo

# 检查依赖
Write-Info "检查构建依赖..."

$7zip = $null
@("C:\Program Files\7-Zip\7z.exe", "C:\Program Files (x86)\7-Zip\7z.exe", ".\tools\7z.exe") | ForEach-Object {
    if (Test-Path $_) { $7zip = $_ }
}
if (-not $7zip) {
    Write-Err "未找到 7-Zip！请安装: https://www.7-zip.org/"
    Read-Host "按回车退出"; exit 1
}
Write-OK "7-Zip"

$curl = Get-Command curl -ErrorAction SilentlyContinue
if (-not $curl) {
    Write-Err "未找到 curl！"
    Read-Host "按回车退出"; exit 1
}
Write-OK "curl"

$gcc = Get-Command gcc -ErrorAction SilentlyContinue
if ($gcc) { Write-OK "gcc" } else { Write-Warn "未找到 gcc，将跳过GUI编译" }

$oscdimg = $null
@(".\tools\oscdimg.exe",
  "C:\Program Files (x86)\Windows Kits\10\Assessment and Deployment Kit\Deployment Tools\amd64\Oscdimg\oscdimg.exe",
  "C:\Program Files (x86)\Windows Kits\11\Assessment and Deployment Kit\Deployment Tools\amd64\Oscdimg\oscdimg.exe") | ForEach-Object {
    if (Test-Path $_) { $oscdimg = $_ }
}
if ($oscdimg) { Write-OK "oscdimg" } else { Write-Warn "未找到 oscdimg，将使用7-Zip生成ISO" }

# 目录
$buildDir = if ($PSScriptRoot) { (Split-Path $PSScriptRoot -Parent) } else { (Get-Location).Path }
$workDir = Join-Path $buildDir "work"
$isoDir = Join-Path $workDir "iso"
$kernelDir = Join-Path $workDir "kernel"
$overlayDir = Join-Path $workDir "overlay"
$outputDir = Join-Path $buildDir "output"
$srcDir = Join-Path $buildDir "src"

Remove-Item -Path $workDir -Recurse -Force -ErrorAction SilentlyContinue
@($isoDir, $kernelDir, $overlayDir, $outputDir) | ForEach-Object {
    New-Item -ItemType Directory -Path $_ -Force | Out-Null
}

# 下载Linux内核
$alpineVer = "3.22"
$mirrors = @(
    "https://dl-cdn.alpinelinux.org/alpine/v${alpineVer}/releases/x86_64/netboot",
    "https://mirror.tuna.tsinghua.edu.cn/alpine/v${alpineVer}/releases/x86_64/netboot",
    "https://mirrors.aliyun.com/alpine/v${alpineVer}/releases/x86_64/netboot"
)

Write-Info "下载 Linux 内核..."
$kernelOk = $false
foreach ($mirror in $mirrors) {
    Write-Info "尝试镜像: $mirror"
    curl.exe -L -o "$kernelDir\vmlinuz-virt" "$mirror/vmlinuz-virt" --connect-timeout 15 --max-time 120 2>$null
    curl.exe -L -o "$kernelDir\initramfs-virt" "$mirror/initramfs-virt" --connect-timeout 15 --max-time 120 2>$null
    if ((Test-Path "$kernelDir\vmlinuz-virt") -and (Get-Item "$kernelDir\vmlinuz-virt").Length -gt 1MB) {
        $kernelOk = $true; break
    }
}
if (-not $kernelOk) {
    Write-Err "内核下载失败！"; exit 1
}
Write-OK "内核下载完成"

# 编译图形界面
if ($gcc -and (Test-Path "$srcDir\qingning-desktop.c")) {
    Write-Info "编译青柠桌面环境..."
    Push-Location $srcDir
    & gcc -O2 -Wall -std=c99 -D_GNU_SOURCE -o qingning-desktop qingning-desktop.c 2>$null
    Pop-Location
    if (Test-Path "$srcDir\qingning-desktop") { Write-OK "编译成功" }
}

# 创建系统层
Write-Info "创建青柠OS系统层..."

$etcDir = Join-Path $overlayDir "etc"
New-Item -ItemType Directory -Path $etcDir -Force | Out-Null
@"
NAME="青柠OS"
VERSION="3.0.0"
ID=qingning-os
ID_LIKE=alpine
PRETTY_NAME="青柠OS 3.0.0 (Linux)"
HOME_URL="https://3862242786-sudo.github.io/pan/qingning-os.html"
SUPPORT_URL="https://3862242786-sudo.github.io/pan/qingning-guide.html"
BUG_REPORT_URL="https://github.com/3862242786-sudo/qingning-os/issues"
LOGO=qingning-os
"@ | Set-Content -Path (Join-Path $etcDir "os-release") -Encoding UTF8

$sbinDir = Join-Path $overlayDir "sbin"
New-Item -ItemType Directory -Path $sbinDir -Force | Out-Null
@"
#!/bin/sh
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

mount -t proc proc /proc 2>/dev/null
mount -t sysfs sysfs /sys 2>/dev/null
mount -t devtmpfs devtmpfs /dev 2>/dev/null
mkdir -p /dev/pts /dev/shm /tmp /run
mount -t devpts devpts /dev/pts 2>/dev/null
mount -t tmpfs tmpfs /tmp 2>/dev/null
mount -t tmpfs tmpfs /run 2>/dev/null
mount -t tmpfs tmpfs /dev/shm 2>/dev/null

hostname qingning-os 2>/dev/null

echo '[青柠OS] 加载显卡驱动...'
modprobe bochs_drm 2>/dev/null
modprobe virtio_gpu 2>/dev/null
modprobe vmwgfx 2>/dev/null
modprobe cirrus 2>/dev/null
sleep 1

if [ -c /dev/fb0 ] && [ -x /usr/bin/qingning-desktop ]; then
    echo '[青柠OS] 启动图形界面...'
    /usr/bin/qingning-desktop
else
    echo '[青柠OS] 进入文本模式'
    exec /bin/sh
fi
"@ | Set-Content -Path (Join-Path $sbinDir "init") -Encoding UTF8

$profileDir = Join-Path $overlayDir "etc/profile.d"
New-Item -ItemType Directory -Path $profileDir -Force | Out-Null
@"
export PS1='\[\033[0;32m\]\u@青柠OS\[\033[0m\]:\[\033[0;34m\]\w\[\033[0m\]# '
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export TERM=linux
export HOME=/root
alias ll='ls -la --color=auto'
alias la='ls -a --color=auto'
echo ''
echo '  ╔══════════════════════════════════════════╗'
echo '  ║    青柠OS 3.0.0 (Linux)                 ║'
echo '  ║    Linux Kernel + 自主GUI图形界面        ║'
echo '  ╚══════════════════════════════════════════╝'
echo ''
"@ | Set-Content -Path (Join-Path $profileDir "qingning.sh") -Encoding UTF8

$usrBinDir = Join-Path $overlayDir "usr/bin"
New-Item -ItemType Directory -Path $usrBinDir -Force | Out-Null
if (Test-Path "$srcDir\qingning-desktop") {
    Copy-Item "$srcDir\qingning-desktop" $usrBinDir -Force
    Write-OK "复制图形界面程序"
}

# 创建ISO结构
Write-Info "创建ISO结构..."
$bootDir = Join-Path $isoDir "boot"
New-Item -ItemType Directory -Path $bootDir -Force | Out-Null
Copy-Item "$kernelDir\vmlinuz-virt" "$bootDir\vmlinuz" -Force
Copy-Item "$kernelDir\initramfs-virt" "$bootDir\initramfs" -Force

$isolinuxDir = Join-Path $isoDir "isolinux"
New-Item -ItemType Directory -Path $isolinuxDir -Force | Out-Null
@"
DEFAULT qingning
PROMPT 0
TIMEOUT 30
UI menu.c32

MENU TITLE 青柠OS 3.0.0
MENU COLOR border       30;44 #40ffffff #a0000000 std
MENU COLOR title        1;36;44 #9033ccff #a0000000 std
MENU COLOR sel          7;37;40 #e0ffffff #20ffffff all

LABEL qingning
    MENU LABEL 青柠OS 3.0.0 (图形界面)
    MENU DEFAULT
    KERNEL /boot/vmlinuz
    INITRD /boot/initramfs
    APPEND modules=loop,squashfs,sd-mod,usb-storage,bochs_drm,virtio_gpu,vmwgfx quiet nomodeset

LABEL qingning-text
    MENU LABEL 青柠OS 3.0.0 (文本模式)
    KERNEL /boot/vmlinuz
    INITRD /boot/initramfs
    APPEND modules=loop,squashfs,sd-mod,usb-storage quiet nomodeset 3
"@ | Set-Content -Path (Join-Path $isolinuxDir "isolinux.cfg") -Encoding UTF8

# 下载引导文件
Write-Info "下载ISOLINUX引导文件..."
curl.exe -L -o "$isolinuxDir\isolinux.bin" "https://raw.githubusercontent.com/coreboot/syslinux/syslinux-6.04/bios/core/isolinux.bin" --connect-timeout 15 --max-time 60 2>$null
curl.exe -L -o "$isolinuxDir\ldlinux.c32" "https://raw.githubusercontent.com/coreboot/syslinux/syslinux-6.04/bios/com32/elflink/ldlinux/ldlinux.c32" --connect-timeout 15 --max-time 60 2>$null
curl.exe -L -o "$isolinuxDir\menu.c32" "https://raw.githubusercontent.com/coreboot/syslinux/syslinux-6.04/bios/com32/menu/menu.c32" --connect-timeout 15 --max-time 60 2>$null
curl.exe -L -o "$isolinuxDir\libutil.c32" "https://raw.githubusercontent.com/coreboot/syslinux/syslinux-6.04/bios/com32/libutil/libutil.c32" --connect-timeout 15 --max-time 60 2>$null

# 生成ISO
Write-Info "生成ISO..."
$finalIso = Join-Path $outputDir "QingningOS-v3.0.iso"

if ($oscdimg -and (Test-Path "$isolinuxDir\isolinux.bin") -and (Get-Item "$isolinuxDir\isolinux.bin").Length -gt 0) {
    Write-Info "使用 oscdimg 生成可启动ISO..."
    & $oscdimg -m -o -u2 -udfver102 -bootdata:"2#p0,e,b`"$isolinuxBin`"" -l"QingningOS-3.0" "$isoDir" "$finalIso" 2>&1 | Out-Null
}
if (-not (Test-Path $finalIso) -or (Get-Item $finalIso).Length -lt 1MB) {
    Write-Warn "oscdimg 失败，使用 7-Zip 生成ISO..."
    & $7zip a -tiso "$finalIso" "$isoDir\*" 2>&1 | Out-Null
}

# 清理
Remove-Item -Path $workDir -Recurse -Force -ErrorAction SilentlyContinue

if (Test-Path $finalIso) {
    $sizeMB = [math]::Round((Get-Item $finalIso).Length / 1MB, 2)
    Write-OK "构建完成！"
    Write-OK "输出: $finalIso ($sizeMB MB)"
    Write-Host ""
    Write-Host "  ╔══════════════════════════════════════════════════════════════╗" -ForegroundColor Green
    Write-Host "  ║                     构建完成！                               ║" -ForegroundColor Green
    Write-Host "  ╚══════════════════════════════════════════════════════════════╝" -ForegroundColor Green
    Write-Host ""
} else {
    Write-Err "ISO生成失败！"
}

Read-Host "按回车退出"
