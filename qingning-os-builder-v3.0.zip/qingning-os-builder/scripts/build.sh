#!/bin/bash
# ============================================================
# 青柠OS 构建脚本 - Linux版
# 与 Windows版 (Build-QingningOS.ps1) 构建相同的 ISO
# ============================================================

set -e

GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

info() { echo -e "${CYAN}[信息] $1${NC}"; }
ok()   { echo -e "${GREEN}[OK] $1${NC}"; }
warn() { echo -e "${YELLOW}[警告] $1${NC}"; }
err()  { echo -e "${RED}[错误] $1${NC}"; }

clear
echo ""
echo "  ╔══════════════════════════════════════════════════════════════╗"
echo "  ║                                                              ║"
echo "  ║         青柠OS 构建工具 v3.0 - Linux版                       ║"
echo "  ║         构建与Windows版相同的青柠OS ISO                      ║"
echo "  ║                                                              ║"
echo "  ╚══════════════════════════════════════════════════════════════╝"
echo ""

# 检查依赖
info "检查构建依赖..."

for cmd in curl wget gcc make xorriso; do
    if command -v "$cmd" &>/dev/null; then
        ok "$cmd"
    else
        warn "未找到 $cmd"
    fi
done

# 目录
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
BUILD_DIR="$(dirname "$SCRIPT_DIR")"
WORK_DIR="$BUILD_DIR/work"
ISO_DIR="$WORK_DIR/iso"
KERNEL_DIR="$WORK_DIR/kernel"
OVERLAY_DIR="$WORK_DIR/overlay"
OUTPUT_DIR="$BUILD_DIR/output"
SRC_DIR="$BUILD_DIR/src"

mkdir -p "$ISO_DIR" "$KERNEL_DIR" "$OVERLAY_DIR" "$OUTPUT_DIR"

# 下载Linux内核
ALPINE_VER="3.22"
MIRRORS=(
    "https://dl-cdn.alpinelinux.org/alpine/v${ALPINE_VER}/releases/x86_64/netboot"
    "https://mirror.tuna.tsinghua.edu.cn/alpine/v${ALPINE_VER}/releases/x86_64/netboot"
    "https://mirrors.aliyun.com/alpine/v${ALPINE_VER}/releases/x86_64/netboot"
)

info "下载 Linux 内核..."
KERNEL_OK=false
for mirror in "${MIRRORS[@]}"; do
    info "尝试镜像: $mirror"
    if curl -L -o "$KERNEL_DIR/vmlinuz-virt" "$mirror/vmlinuz-virt" --connect-timeout 15 --max-time 120 2>/dev/null && \
       curl -L -o "$KERNEL_DIR/initramfs-virt" "$mirror/initramfs-virt" --connect-timeout 15 --max-time 120 2>/dev/null; then
        if [ -s "$KERNEL_DIR/vmlinuz-virt" ]; then
            KERNEL_OK=true
            break
        fi
    fi
done

if [ "$KERNEL_OK" != true ]; then
    err "内核下载失败！"
    exit 1
fi
ok "内核下载完成"

# 编译图形界面
if [ -f "$SRC_DIR/qingning-desktop.c" ] && command -v gcc &>/dev/null; then
    info "编译青柠桌面环境..."
    cd "$SRC_DIR"
    gcc -O2 -Wall -std=c99 -D_GNU_SOURCE -o qingning-desktop qingning-desktop.c
    cd - >/dev/null
    if [ -f "$SRC_DIR/qingning-desktop" ]; then
        ok "编译成功"
    fi
else
    warn "跳过图形界面编译"
fi

# 创建系统层
info "创建青柠OS系统层..."

mkdir -p "$OVERLAY_DIR/etc" "$OVERLAY_DIR/sbin" "$OVERLAY_DIR/etc/profile.d" "$OVERLAY_DIR/usr/bin"

cat > "$OVERLAY_DIR/etc/os-release" <<'EOF'
NAME="青柠OS"
VERSION="3.0.0"
ID=qingning-os
ID_LIKE=alpine
PRETTY_NAME="青柠OS 3.0.0 (Linux)"
HOME_URL="https://3862242786-sudo.github.io/pan/qingning-os.html"
SUPPORT_URL="https://3862242786-sudo.github.io/pan/qingning-guide.html"
BUG_REPORT_URL="https://github.com/3862242786-sudo/qingning-os/issues"
LOGO=qingning-os
EOF

cat > "$OVERLAY_DIR/sbin/init" <<'EOF'
#!/bin/sh
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

mount -t proc proc /proc 2>/dev/null
mount -t sysfs sysfs /sys 2>/dev/null
mount -t devtmpfs devtmpfs /dev 2>/dev/null
mkdir -p /dev/pts /dev/shm /tmp /run
mount -t devpts devpts /dev/pts 2>/dev/null
mount -t tmpfs tmpfs /tmp 2>/dev/null
mount -t tmpfs tmpfs /run 2>/dev/null
mount -t tmpfs tmpfs /dev/shm 2>/dev/null

hostname qingning-os 2>/dev/null

echo '[青柠OS] 加载显卡驱动...'
modprobe bochs_drm 2>/dev/null
modprobe virtio_gpu 2>/dev/null
modprobe vmwgfx 2>/dev/null
modprobe cirrus 2>/dev/null
sleep 1

if [ -c /dev/fb0 ] && [ -x /usr/bin/qingning-desktop ]; then
    echo '[青柠OS] 启动图形界面...'
    /usr/bin/qingning-desktop
else
    echo '[青柠OS] 进入文本模式'
    exec /bin/sh
fi
EOF
chmod +x "$OVERLAY_DIR/sbin/init"

cat > "$OVERLAY_DIR/etc/profile.d/qingning.sh" <<'EOF'
export PS1='\[\033[0;32m\]\u@青柠OS\[\033[0m\]:\[\033[0;34m\]\w\[\033[0m\]# '
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export TERM=linux
export HOME=/root
alias ll='ls -la --color=auto'
alias la='ls -a --color=auto'
echo ''
echo '  ╔══════════════════════════════════════════╗'
echo '  ║    青柠OS 3.0.0 (Linux)                 ║'
echo '  ║    Linux Kernel + 自主GUI图形界面        ║'
echo '  ╚══════════════════════════════════════════╝'
echo ''
EOF

if [ -f "$SRC_DIR/qingning-desktop" ]; then
    cp "$SRC_DIR/qingning-desktop" "$OVERLAY_DIR/usr/bin/"
    ok "复制图形界面程序"
fi

# 创建ISO结构
info "创建ISO结构..."
mkdir -p "$ISO_DIR/boot"
cp "$KERNEL_DIR/vmlinuz-virt" "$ISO_DIR/boot/vmlinuz"
cp "$KERNEL_DIR/initramfs-virt" "$ISO_DIR/boot/initramfs"

mkdir -p "$ISO_DIR/isolinux"
cat > "$ISO_DIR/isolinux/isolinux.cfg" <<'EOF'
DEFAULT qingning
PROMPT 0
TIMEOUT 30
UI menu.c32

MENU TITLE 青柠OS 3.0.0
MENU COLOR border       30;44 #40ffffff #a0000000 std
MENU COLOR title        1;36;44 #9033ccff #a0000000 std
MENU COLOR sel          7;37;40 #e0ffffff #20ffffff all

LABEL qingning
    MENU LABEL 青柠OS 3.0.0 (图形界面)
    MENU DEFAULT
    KERNEL /boot/vmlinuz
    INITRD /boot/initramfs
    APPEND modules=loop,squashfs,sd-mod,usb-storage,bochs_drm,virtio_gpu,vmwgfx quiet nomodeset

LABEL qingning-text
    MENU LABEL 青柠OS 3.0.0 (文本模式)
    KERNEL /boot/vmlinuz
    INITRD /boot/initramfs
    APPEND modules=loop,squashfs,sd-mod,usb-storage quiet nomodeset 3
EOF

# 下载引导文件
info "下载ISOLINUX引导文件..."
curl -L -o "$ISO_DIR/isolinux/isolinux.bin" "https://raw.githubusercontent.com/coreboot/syslinux/syslinux-6.04/bios/core/isolinux.bin" --connect-timeout 15 --max-time 60 2>/dev/null || true
curl -L -o "$ISO_DIR/isolinux/ldlinux.c32" "https://raw.githubusercontent.com/coreboot/syslinux/syslinux-6.04/bios/com32/elflink/ldlinux/ldlinux.c32" --connect-timeout 15 --max-time 60 2>/dev/null || true
curl -L -o "$ISO_DIR/isolinux/menu.c32" "https://raw.githubusercontent.com/coreboot/syslinux/syslinux-6.04/bios/com32/menu/menu.c32" --connect-timeout 15 --max-time 60 2>/dev/null || true
curl -L -o "$ISO_DIR/isolinux/libutil.c32" "https://raw.githubusercontent.com/coreboot/syslinux/syslinux-6.04/bios/com32/libutil/libutil.c32" --connect-timeout 15 --max-time 60 2>/dev/null || true

# 生成ISO
info "生成ISO..."
FINAL_ISO="$OUTPUT_DIR/QingningOS-v3.0.iso"

if command -v xorriso &>/dev/null && [ -s "$ISO_DIR/isolinux/isolinux.bin" ]; then
    info "使用 xorriso 生成可启动ISO..."
    xorriso -as mkisofs \
        -isohybrid-mbr "$ISO_DIR/isolinux/isolinux.bin" \
        -c isolinux/boot.cat \
        -b isolinux/isolinux.bin \
        -no-emul-boot -boot-load-size 4 -boot-info-table \
        -eltorito-alt-boot \
        -e boot/grub/efi.img \
        -no-emul-boot -isohybrid-gpt-basdat \
        -o "$FINAL_ISO" "$ISO_DIR" 2>/dev/null || \
    xorriso -as mkisofs \
        -b isolinux/isolinux.bin -c isolinux/boot.cat \
        -no-emul-boot -boot-load-size 4 -boot-info-table \
        -o "$FINAL_ISO" "$ISO_DIR" 2>/dev/null || true
fi

if [ ! -f "$FINAL_ISO" ] || [ ! -s "$FINAL_ISO" ]; then
    warn "xorriso 失败，尝试 genisoimage..."
    if command -v genisoimage &>/dev/null; then
        genisoimage -o "$FINAL_ISO" -b isolinux/isolinux.bin -c isolinux/boot.cat \
            -no-emul-boot -boot-load-size 4 -boot-info-table -J -R -V "QingningOS-3.0" "$ISO_DIR" 2>/dev/null || true
    fi
fi

# 清理
rm -rf "$WORK_DIR"

if [ -f "$FINAL_ISO" ] && [ -s "$FINAL_ISO" ]; then
    SIZE_MB=$(du -m "$FINAL_ISO" | cut -f1)
    ok "构建完成！"
    ok "输出: $FINAL_ISO (${SIZE_MB}MB)"
    echo ""
    echo "  ╔══════════════════════════════════════════════════════════════╗"
    echo "  ║                     构建完成！                               ║"
    echo "  ╚══════════════════════════════════════════════════════════════╝"
    echo ""
else
    err "ISO生成失败！"
    exit 1
fi
