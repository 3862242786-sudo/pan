@echo off
chcp 65001 >nul
title 青柠OS构建工具 - Windows版
color 0A
cls

echo.
echo  ╔══════════════════════════════════════════════════════════════╗
echo  ║                                                              ║
echo  ║         青柠OS 构建工具 v3.0 - Windows版                     ║
echo  ║         正在启动 PowerShell 构建脚本...                      ║
echo  ║                                                              ║
echo  ╚══════════════════════════════════════════════════════════════╝
echo.

:: 获取当前目录
set "SCRIPT_DIR=%~dp0"
set "PS1_FILE=%SCRIPT_DIR%Build-Windows.ps1"

:: 检查 PowerShell 脚本是否存在
if not exist "%PS1_FILE%" (
    echo [错误] 找不到 PowerShell 脚本: Build-Windows.ps1
    echo 请确保 Build-Windows.bat 和 Build-Windows.ps1 在同一目录。
    pause
    exit /b 1
)

:: 检查是否以管理员身份运行
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [警告] 当前未以管理员身份运行，建议右键"以管理员身份运行"。
    echo.
    choice /C YN /M "是否继续"
    if errorlevel 2 exit /b 0
)

:: 启动 PowerShell 脚本
echo [信息] 正在启动构建脚本...
echo.
powershell.exe -ExecutionPolicy Bypass -File "%PS1_FILE%"

if %errorLevel% neq 0 (
    echo.
    echo [错误] 构建脚本执行失败。
    pause
    exit /b 1
)

exit /b 0
