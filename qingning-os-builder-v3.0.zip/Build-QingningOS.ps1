# ============================================================
# 青柠OS 统一构建工具 v3.0
# PowerShell 脚本 - Windows直接打包
# 支持两个版本:
#   1. Alex版  - 完整Linux内核 + 自主GUI (真正的操作系统)
#   2. Windows版 - 基于Windows ISO封装 (主题定制)
#
# 用法: 右键"使用 PowerShell 运行" 或 .
# ============================================================

#Requires -RunAsAdministrator

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$Host.UI.RawUI.BackgroundColor = "Black"
$Host.UI.RawUI.ForegroundColor = "Green"
Clear-Host

function Write-Logo {
    Write-Host ""
    Write-Host "  ╔══════════════════════════════════════════════════════════════╗" -ForegroundColor Green
    Write-Host "  ║                                                              ║" -ForegroundColor Green
    Write-Host "  ║         青柠OS 统一构建工具 v3.0                             ║" -ForegroundColor Green
    Write-Host "  ║         Windows直接打包 · 双版本选择                         ║" -ForegroundColor Green
    Write-Host "  ║                                                              ║" -ForegroundColor Green
    Write-Host "  ╚══════════════════════════════════════════════════════════════╝" -ForegroundColor Green
    Write-Host ""
}

function Write-Info { param([string]$m) Write-Host "  [信息] $m" -ForegroundColor Cyan }
function Write-OK   { param([string]$m) Write-Host "  [OK] $m" -ForegroundColor Green }
function Write-Warn { param([string]$m) Write-Host "  [警告] $m" -ForegroundColor Yellow }
function Write-Err  { param([string]$m) Write-Host "  [错误] $m" -ForegroundColor Red }

Write-Logo

# ============================================================
# 检查依赖
# ============================================================
Write-Info "检查构建依赖..."

# 7-Zip
$7zip = $null
@("C:\Program Files\7-Zip\7z.exe", "C:\Program Files (x86)\7-Zip\7z.exe", ".\tools\7z.exe") | ForEach-Object {
    if (Test-Path $_) { $7zip = $_ }
}
if (-not $7zip) {
    Write-Err "未找到 7-Zip！请安装: https://www.7-zip.org/"
    Read-Host "按回车退出"; exit 1
}
Write-OK "7-Zip: $7zip"

# curl
$curl = Get-Command curl -ErrorAction SilentlyContinue
if (-not $curl) {
    Write-Err "未找到 curl！"
    Read-Host "按回车退出"; exit 1
}
Write-OK "curl"

# gcc (用于编译Alex版)
$gcc = Get-Command gcc -ErrorAction SilentlyContinue
if ($gcc) {
    Write-OK "gcc 编译器"
} else {
    Write-Warn "未找到 gcc，Alex版将跳过图形界面编译"
    Write-Info "如需图形界面，请安装 MinGW-w64: https://www.mingw-w64.org/"
}

# oscdimg (可选，用于生成可启动ISO)
$oscdimg = $null
@(".\tools\oscdimg.exe", 
  "C:\Program Files (x86)\Windows Kits\10\Assessment and Deployment Kit\Deployment Tools\amd64\Oscdimg\oscdimg.exe",
  "C:\Program Files (x86)\Windows Kits\11\Assessment and Deployment Kit\Deployment Tools\amd64\Oscdimg\oscdimg.exe") | ForEach-Object {
    if (Test-Path $_) { $oscdimg = $_ }
}
if ($oscdimg) {
    Write-OK "oscdimg (Windows ADK)"
} else {
    Write-Warn "未找到 oscdimg，将使用 7-Zip 生成ISO（可能无法启动）"
    Write-Info "如需可启动ISO，请安装 Windows ADK"
}

# ============================================================
# 版本选择菜单
# ============================================================
Write-Host ""
Write-Host "  ════════════════════════════════════════════════════════════" -ForegroundColor Yellow
Write-Host "  请选择要构建的版本:" -ForegroundColor Yellow
Write-Host "  ════════════════════════════════════════════════════════════" -ForegroundColor Yellow
Write-Host ""
Write-Host "  [1] Alex版 (推荐)" -ForegroundColor Green
Write-Host "      完整Linux内核 + 自主GUI图形界面" -ForegroundColor Gray
Write-Host "      真正的操作系统，约25MB ISO" -ForegroundColor Gray
Write-Host "      适合: 体验真正的青柠OS" -ForegroundColor Gray
Write-Host ""
Write-Host "  [2] Windows版" -ForegroundColor Cyan
Write-Host "      基于Windows 10/11 ISO封装" -ForegroundColor Gray
Write-Host "      青柠主题 + 预配置，约4GB ISO" -ForegroundColor Gray
Write-Host "      适合: 需要完整Windows兼容性" -ForegroundColor Gray
Write-Host ""
Write-Host "  [3] 两个版本都构建" -ForegroundColor Magenta
Write-Host ""

$choice = Read-Host "  输入编号 (1/2/3)"

# ============================================================
# Alex版构建函数
# ============================================================
function Build-AlexVersion {
    Write-Host ""
    Write-Host "  ╔══════════════════════════════════════════════════════════════╗" -ForegroundColor Green
    Write-Host "  ║              构建 Alex版 (Linux内核 + GUI)                   ║" -ForegroundColor Green
    Write-Host "  ╚══════════════════════════════════════════════════════════════╝" -ForegroundColor Green
    Write-Host ""

    $buildDir = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
    $workDir = Join-Path $buildDir "work-alex"
    $isoDir = Join-Path $workDir "iso"
    $kernelDir = Join-Path $workDir "kernel"
    $overlayDir = Join-Path $workDir "overlay"
    $outputDir = Join-Path $buildDir "output"
    $srcDir = Join-Path $buildDir "src"

    # 清理并创建目录
    Remove-Item -Path $workDir -Recurse -Force -ErrorAction SilentlyContinue
    @($isoDir, $kernelDir, $overlayDir, $outputDir) | ForEach-Object {
        New-Item -ItemType Directory -Path $_ -Force | Out-Null
    }

    # 下载Linux内核
    $alpineVer = "3.22"
    $mirrors = @(
        "https://dl-cdn.alpinelinux.org/alpine/v${alpineVer}/releases/x86_64/netboot",
        "https://mirror.tuna.tsinghua.edu.cn/alpine/v${alpineVer}/releases/x86_64/netboot",
        "https://mirrors.aliyun.com/alpine/v${alpineVer}/releases/x86_64/netboot"
    )

    Write-Info "下载 Linux 内核..."
    $kernelOk = $false
    foreach ($mirror in $mirrors) {
        Write-Info "尝试镜像: $mirror"
        curl.exe -L -o "$kernelDir\vmlinuz-virt" "$mirror/vmlinuz-virt" --connect-timeout 15 --max-time 120 2>$null
        curl.exe -L -o "$kernelDir\initramfs-virt" "$mirror/initramfs-virt" --connect-timeout 15 --max-time 120 2>$null
        if ((Test-Path "$kernelDir\vmlinuz-virt") -and (Get-Item "$kernelDir\vmlinuz-virt").Length -gt 1MB) {
            $kernelOk = $true
            break
        }
    }
    if (-not $kernelOk) {
        Write-Err "内核下载失败！请检查网络连接。"
        return $false
    }
    Write-OK "内核下载完成"

    # 编译图形界面
    if ($gcc -and (Test-Path "$srcDir\qingning-desktop.c")) {
        Write-Info "编译青柠桌面环境..."
        Push-Location $srcDir
        & gcc -O2 -Wall -std=c99 -D_GNU_SOURCE -o qingning-desktop qingning-desktop.c 2>$null
        Pop-Location
        if (Test-Path "$srcDir\qingning-desktop") {
            Write-OK "编译成功"
        } else {
            Write-Warn "编译失败，将不包含图形界面"
        }
    }

    # 创建系统层
    Write-Info "创建青柠OS系统层..."

    # /etc/os-release
    $etcDir = Join-Path $overlayDir "etc"
    New-Item -ItemType Directory -Path $etcDir -Force | Out-Null
    @"
NAME="青柠OS"
VERSION="3.0.0-Alex"
ID=qingning-os
ID_LIKE=alpine
PRETTY_NAME="青柠OS 3.0.0 Alex版 (Linux)"
HOME_URL="https://3862242786-sudo.github.io/pan/qingning-os.html"
SUPPORT_URL="https://3862242786-sudo.github.io/pan/qingning-guide.html"
BUG_REPORT_URL="https://github.com/3862242786-sudo/qingning-os/issues"
LOGO=qingning-os
"@ | Set-Content -Path (Join-Path $etcDir "os-release") -Encoding UTF8

    # init系统
    $sbinDir = Join-Path $overlayDir "sbin"
    New-Item -ItemType Directory -Path $sbinDir -Force | Out-Null
    @"
#!/bin/sh
# 青柠OS Alex版 init
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

mount -t proc proc /proc 2>/dev/null
mount -t sysfs sysfs /sys 2>/dev/null
mount -t devtmpfs devtmpfs /dev 2>/dev/null
mkdir -p /dev/pts /dev/shm /tmp /run
mount -t devpts devpts /dev/pts 2>/dev/null
mount -t tmpfs tmpfs /tmp 2>/dev/null
mount -t tmpfs tmpfs /run 2>/dev/null
mount -t tmpfs tmpfs /dev/shm 2>/dev/null

hostname qingning-os 2>/dev/null

echo '[青柠OS] 加载显卡驱动...'
modprobe bochs_drm 2>/dev/null
modprobe virtio_gpu 2>/dev/null
modprobe vmwgfx 2>/dev/null
modprobe cirrus 2>/dev/null
sleep 1

if [ -c /dev/fb0 ] && [ -x /usr/bin/qingning-desktop ]; then
    echo '[青柠OS] 启动图形界面...'
    /usr/bin/qingning-desktop
else
    echo '[青柠OS] 无法启动图形界面，进入文本模式'
    echo '提示: 安装图形界面需要 gcc 编译 qingning-desktop.c'
    exec /bin/sh
fi
"@ | Set-Content -Path (Join-Path $sbinDir "init") -Encoding UTF8

    # Shell配置
    $profileDir = Join-Path $overlayDir "etc/profile.d"
    New-Item -ItemType Directory -Path $profileDir -Force | Out-Null
    @"
export PS1='\[\033[0;32m\]\u@青柠OS\[\033[0m\]:\[\033[0;34m\]\w\[\033[0m\]# '
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export TERM=linux
export HOME=/root
alias ll='ls -la --color=auto'
alias la='ls -a --color=auto'
echo ''
echo '  ╔══════════════════════════════════════════╗'
echo '  ║    青柠OS 3.0.0 Alex版 (Linux)          ║'
echo '  ║    Linux Kernel + 自主GUI图形界面        ║'
echo '  ╚══════════════════════════════════════════╝'
echo ''
"@ | Set-Content -Path (Join-Path $profileDir "qingning.sh") -Encoding UTF8

    # 复制桌面程序
    $usrBinDir = Join-Path $overlayDir "usr/bin"
    New-Item -ItemType Directory -Path $usrBinDir -Force | Out-Null
    if (Test-Path "$srcDir\qingning-desktop") {
        Copy-Item "$srcDir\qingning-desktop" $usrBinDir -Force
        Write-OK "复制图形界面程序"
    }

    # 创建ISO结构
    Write-Info "创建ISO结构..."
    $bootDir = Join-Path $isoDir "boot"
    New-Item -ItemType Directory -Path $bootDir -Force | Out-Null
    Copy-Item "$kernelDir\vmlinuz-virt" "$bootDir\vmlinuz" -Force
    Copy-Item "$kernelDir\initramfs-virt" "$bootDir\initramfs" -Force

    # ISOLINUX配置
    $isolinuxDir = Join-Path $isoDir "isolinux"
    New-Item -ItemType Directory -Path $isolinuxDir -Force | Out-Null
    @"
DEFAULT qingning
PROMPT 0
TIMEOUT 30
UI menu.c32

MENU TITLE 青柠OS 3.0.0 Alex版
MENU COLOR border       30;44 #40ffffff #a0000000 std
MENU COLOR title        1;36;44 #9033ccff #a0000000 std
MENU COLOR sel          7;37;40 #e0ffffff #20ffffff all
MENU COLOR unsel        37;44 #50ffffff #a0000000 std
MENU COLOR help         37;40 #c0ffffff #a0000000 std
MENU COLOR timeout_msg  37;40 #80ffffff #00000000 std
MENU COLOR timeout      1;37;40 #c0ffffff #00000000 std
MENU COLOR msg07        37;40 #90ffffff #a0000000 std
MENU COLOR tabmsg       31;40 #30ffffff #00000000 std

LABEL qingning
    MENU LABEL 青柠OS 3.0.0 Alex版 (图形界面)
    MENU DEFAULT
    KERNEL /boot/vmlinuz
    INITRD /boot/initramfs
    APPEND modules=loop,squashfs,sd-mod,usb-storage,bochs_drm,virtio_gpu,vmwgfx quiet nomodeset

LABEL qingning-text
    MENU LABEL 青柠OS 3.0.0 Alex版 (文本模式)
    KERNEL /boot/vmlinuz
    INITRD /boot/initramfs
    APPEND modules=loop,squashfs,sd-mod,usb-storage quiet nomodeset 3

LABEL qingning-debug
    MENU LABEL 青柠OS 3.0.0 Alex版 (调试模式)
    KERNEL /boot/vmlinuz
    INITRD /boot/initramfs
    APPEND modules=loop,squashfs,sd-mod,usb-storage,bochs_drm,virtio_gpu debug
"@ | Set-Content -Path (Join-Path $isolinuxDir "isolinux.cfg") -Encoding UTF8

    # 下载引导文件
    Write-Info "下载ISOLINUX引导文件..."
    $isolinuxBin = Join-Path $isolinuxDir "isolinux.bin"
    $ldlinuxC32 = Join-Path $isolinuxDir "ldlinux.c32"
    $menuC32 = Join-Path $isolinuxDir "menu.c32"
    $libutilC32 = Join-Path $isolinuxDir "libutil.c32"

    curl.exe -L -o "$isolinuxBin" "https://raw.githubusercontent.com/coreboot/syslinux/syslinux-6.04/bios/core/isolinux.bin" --connect-timeout 15 --max-time 60 2>$null
    curl.exe -L -o "$ldlinuxC32" "https://raw.githubusercontent.com/coreboot/syslinux/syslinux-6.04/bios/com32/elflink/ldlinux/ldlinux.c32" --connect-timeout 15 --max-time 60 2>$null
    curl.exe -L -o "$menuC32" "https://raw.githubusercontent.com/coreboot/syslinux/syslinux-6.04/bios/com32/menu/menu.c32" --connect-timeout 15 --max-time 60 2>$null
    curl.exe -L -o "$libutilC32" "https://raw.githubusercontent.com/coreboot/syslinux/syslinux-6.04/bios/com32/libutil/libutil.c32" --connect-timeout 15 --max-time 60 2>$null

    # 生成ISO
    Write-Info "生成ISO..."
    $finalIso = Join-Path $outputDir "QingningOS-Alex-v3.0.iso"

    if ($oscdimg -and (Test-Path $isolinuxBin) -and (Get-Item $isolinuxBin).Length -gt 0) {
        Write-Info "使用 oscdimg 生成可启动ISO..."
        & $oscdimg -m -o -u2 -udfver102 -bootdata:"2#p0,e,b`"$isolinuxBin`"" -l"QingningOS-Alex-3.0" "$isoDir" "$finalIso" 2>&1 | Out-Null
    }
    if (-not (Test-Path $finalIso) -or (Get-Item $finalIso).Length -lt 1MB) {
        Write-Warn "oscdimg 失败，使用 7-Zip 生成ISO..."
        & $7zip a -tiso "$finalIso" "$isoDir\*" 2>&1 | Out-Null
    }

    # 清理工作目录
    Remove-Item -Path $workDir -Recurse -Force -ErrorAction SilentlyContinue

    if (Test-Path $finalIso) {
        $sizeMB = [math]::Round((Get-Item $finalIso).Length / 1MB, 2)
        Write-OK "Alex版构建完成！"
        Write-OK "输出: $finalIso ($sizeMB MB)"
        return $true
    } else {
        Write-Err "ISO生成失败！"
        return $false
    }
}

# ============================================================
# Windows版构建函数
# ============================================================
function Build-WindowsVersion {
    Write-Host ""
    Write-Host "  ╔══════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "  ║              构建 Windows版 (基于Windows ISO)                ║" -ForegroundColor Cyan
    Write-Host "  ╚══════════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""

    $buildDir = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
    $workDir = Join-Path $buildDir "work-windows"
    $isoDir = Join-Path $workDir "iso"
    $outputDir = Join-Path $buildDir "output"
    $configDir = Join-Path $buildDir "config"
    $assetsDir = Join-Path $buildDir "assets"

    # 查找Windows ISO
    $isoFiles = Get-ChildItem -Path $buildDir -Filter "*.iso" -File
    $windowsISO = $null
    foreach ($iso in $isoFiles) {
        if ($iso.Name -notmatch "QingningOS") {
            $windowsISO = $iso.FullName
            break
        }
    }

    if (-not $windowsISO) {
        Write-Err "未找到Windows ISO！"
        Write-Info "请将Windows 10/11 ISO放到此文件夹"
        Write-Info "下载: https://www.microsoft.com/software-download/windows10"
        return $false
    }
    Write-OK "找到Windows ISO: $(Split-Path $windowsISO -Leaf)"

    # 准备工作目录
    Remove-Item -Path $workDir -Recurse -Force -ErrorAction SilentlyContinue
    @($isoDir, $outputDir) | ForEach-Object {
        New-Item -ItemType Directory -Path $_ -Force | Out-Null
    }

    # 解压ISO
    Write-Info "解压Windows ISO..."
    & $7zip x "$windowsISO" -o"$isoDir" -y | Out-Null
    Write-OK "解压完成"

    # 应用青柠品牌
    Write-Info "应用青柠OS品牌..."

    # 系统标识
    @"
NAME="青柠OS"
VERSION="3.0.0-Windows"
ID=qingning-os-windows
ID_LIKE=windows
PRETTY_NAME="青柠OS 3.0.0 Windows版"
HOME_URL="https://3862242786-sudo.github.io/pan/qingning-os.html"
SUPPORT_URL="https://3862242786-sudo.github.io/pan/qingning-guide.html"
"@ | Set-Content -Path "$isoDir\sources\qingning-os-release.txt" -Encoding UTF8 -Force

    # 修改启动菜单
    if (Test-Path "$isoDir\boot\grub\grub.cfg") {
        $content = Get-Content "$isoDir\boot\grub\grub.cfg" -Raw
        $content = $content -replace "Windows", "青柠OS Windows版" -replace "Install", "安装"
        Set-Content -Path "$isoDir\boot\grub\grub.cfg" -Value $content -Encoding UTF8 -Force
    }

    # 复制autounattend.xml（如果存在）
    if (Test-Path "$configDir\autounattend.xml") {
        Copy-Item "$configDir\autounattend.xml" "$isoDir\autounattend.xml" -Force
        Write-OK "添加无人值守安装配置"
    }

    # 复制设置脚本
    if (Test-Path "$assetsDir\qingning-setup.bat") {
        $qingningDir = "$isoDir\QingningOS"
        New-Item -ItemType Directory -Path $qingningDir -Force | Out-Null
        Copy-Item "$assetsDir\qingning-setup.bat" "$qingningDir\qingning-setup.bat" -Force
        Write-OK "添加青柠设置脚本"
    }

    # 生成ISO
    Write-Info "生成青柠OS Windows版 ISO..."
    $finalIso = Join-Path $outputDir "QingningOS-Windows-v3.0.iso"

    if ($oscdimg) {
        Write-Info "使用 oscdimg 生成可启动ISO..."
        & $oscdimg -m -o -u2 -udfver102 -l"QingningOS-Win-3.0" "$isoDir" "$finalIso" 2>&1 | Out-Null
    }
    if (-not (Test-Path $finalIso) -or (Get-Item $finalIso).Length -lt 1MB) {
        Write-Warn "oscdimg 失败，使用 7-Zip 生成ISO..."
        & $7zip a -tiso "$finalIso" "$isoDir\*" 2>&1 | Out-Null
    }

    # 清理工作目录
    Remove-Item -Path $workDir -Recurse -Force -ErrorAction SilentlyContinue

    if (Test-Path $finalIso) {
        $sizeGB = [math]::Round((Get-Item $finalIso).Length / 1GB, 2)
        Write-OK "Windows版构建完成！"
        Write-OK "输出: $finalIso ($sizeGB GB)"
        return $true
    } else {
        Write-Err "ISO生成失败！"
        return $false
    }
}

# ============================================================
# 执行构建
# ============================================================
$results = @()

switch ($choice) {
    "1" {
        $results += Build-AlexVersion
    }
    "2" {
        $results += Build-WindowsVersion
    }
    "3" {
        $results += Build-AlexVersion
        $results += Build-WindowsVersion
    }
    default {
        Write-Err "无效选择！"
        Read-Host "按回车退出"
        exit 1
    }
}

# ============================================================
# 完成
# ============================================================
Write-Host ""
Write-Host "  ╔══════════════════════════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "  ║                     构建完成！                               ║" -ForegroundColor Green
Write-Host "  ╚══════════════════════════════════════════════════════════════╝" -ForegroundColor Green
Write-Host ""

$outputDir = Join-Path (if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }) "output"
if (Test-Path $outputDir) {
    $isoFiles = Get-ChildItem -Path $outputDir -Filter "*.iso"
    if ($isoFiles.Count -gt 0) {
        Write-OK "生成的ISO文件:"
        foreach ($iso in $isoFiles) {
            $size = if ($iso.Length -gt 1GB) {
                "$([math]::Round($iso.Length / 1GB, 2)) GB"
            } else {
                "$([math]::Round($iso.Length / 1MB, 2)) MB"
            }
            Write-Host "    $($iso.Name) ($size)" -ForegroundColor White
        }
    }
}

Write-Host ""
Write-Host "  感谢使用青柠OS构建工具！" -ForegroundColor Green
Write-Host "  官网: https://3862242786-sudo.github.io/pan/qingning-os.html" -ForegroundColor Gray
Read-Host "  按回车退出"
exit 0
