# 青柠OS 统一构建工具 v3.0

一个 Windows 上的 PowerShell 脚本，支持构建两个版本的青柠OS：

- **Alex版** - 完整 Linux 内核 + 自主 GUI 图形界面（真正的操作系统）
- **Windows版** - 基于 Windows 10/11 ISO 封装（主题定制）

## 系统要求

- Windows 10/11 (64位)
- PowerShell 5.1 或更高版本
- 管理员权限
- [7-Zip](https://www.7-zip.org/)（必需）
- curl（Windows 10 自带）
- gcc/MinGW-w64（可选，用于编译 Alex 版图形界面）
- Windows ADK oscdimg（可选，用于生成可启动 ISO）

## 快速开始

1. 下载并解压本工具包
2. **右键** `Build-QingningOS.ps1` → **使用 PowerShell 运行**
3. 选择要构建的版本（1=Alex版, 2=Windows版, 3=两个都构建）
4. 等待构建完成，ISO 文件将生成在 `output/` 目录

## Alex版（Linux内核 + GUI）

基于 Alpine Linux 内核，包含自主开发的 framebuffer 图形界面。

**特性：**
- Linux Kernel 6.x
- 自主 GUI：任务栏、Dock、桌面图标、窗口管理
- 鼠标支持（通过 /dev/input/mice）
- 5x7 位图字体渲染
- 终端、浏览器、文件管理器、设置、关于窗口
- 约 25MB ISO

**构建流程：**
1. 从 Alpine 镜像下载 Linux 内核 (vmlinuz + initramfs)
2. 编译 `qingning-desktop.c` 图形界面程序
3. 创建系统层（init、profile、os-release）
4. 配置 ISOLINUX 引导
5. 生成可启动 ISO

## Windows版

基于官方 Windows 10/11 ISO，自动应用青柠主题。

**特性：**
- 青柠绿主题色 (#22c55e)
- 深色模式
- 居中任务栏
- 隐藏搜索/小组件
- 自动创建青柠网盘/商店/教程快捷方式
- OEM 信息定制
- 无人值守安装（自动分区、自动登录）

**使用方法：**
1. 将 Windows 10/11 ISO 文件放到工具包根目录
2. 运行脚本选择 "2) Windows版"
3. 生成的 ISO 可直接用于虚拟机安装

## 目录结构

```
qingning-os-builder/
├── Build-QingningOS.ps1      # 主构建脚本
├── README.md                  # 本文件
├── src/
│   ├── qingning-desktop.c    # Alex版 GUI 源代码
│   └── Makefile              # 编译配置
├── config/
│   └── autounattend.xml      # Windows版无人值守配置
├── assets/
│   └── qingning-setup.bat    # Windows版首次启动脚本
└── output/                    # 生成的 ISO 输出目录
```

## 手动编译 GUI

```bash
cd src
make          # 动态链接
cd ..
```

## 常见问题

**Q: 找不到 7-Zip？**
A: 请从 https://www.7-zip.org/ 下载安装。

**Q: Alex版没有图形界面？**
A: 需要安装 MinGW-w64 或 MSYS2 以获得 gcc 编译器。

**Q: ISO 无法启动？**
A: 安装 Windows ADK 以获得 oscdimg.exe，否则 7-Zip 生成的 ISO 可能无法引导。

**Q: Windows版提示找不到 ISO？**
A: 将 Windows 10/11 ISO 文件放到与脚本相同的文件夹中。

## 开源协议

MIT License - 青柠OS 开发团队
