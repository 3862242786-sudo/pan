@echo off
chcp 65001 >nul
title 青柠OS 首次启动配置
color 0A

:: ============================================================
:: 青柠OS Windows 首次启动配置脚本
:: 在系统安装完成后自动运行，应用青柠主题和设置
:: ============================================================

echo.
echo  ╔══════════════════════════════════════════════════════════════╗
echo  ║                  青柠OS 正在初始化...                        ║
echo  ╚══════════════════════════════════════════════════════════════╝
echo.

:: 创建青柠OS目录
mkdir "C:\QingningOS" 2>nul
mkdir "C:\QingningOS\Themes" 2>nul
mkdir "C:\QingningOS\Wallpapers" 2>nul
mkdir "C:\QingningOS\Icons" 2>nul

:: ============================================================
:: 1. 设置壁纸
:: ============================================================
echo  [1/6] 设置青柠壁纸...
if exist "C:\QingningOS\wallpaper.jpg" (
    reg add "HKCU\Control Panel\Desktop" /v Wallpaper /t REG_SZ /d "C:\QingningOS\wallpaper.jpg" /f >nul 2>&1
    reg add "HKCU\Control Panel\Desktop" /v WallpaperStyle /t REG_SZ /d "10" /f >nul 2>&1
    reg add "HKCU\Control Panel\Desktop" /v TileWallpaper /t REG_SZ /d "0" /f >nul 2>&1
    :: 刷新壁纸
    rundll32.exe user32.dll,UpdatePerUserSystemParameters
)

:: ============================================================
:: 2. 设置主题色（青柠绿）
:: ============================================================
echo  [2/6] 设置青柠主题色...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v AppsUseLightTheme /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v SystemUsesLightTheme /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v ColorPrevalence /t REG_DWORD /d 1 /f >nul 2>&1
:: 设置强调色为青柠绿 #22c55e
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v AccentColor /t REG_DWORD /d 0xff5ec522 /f >nul 2>&1

:: ============================================================
:: 3. 设置任务栏
:: ============================================================
echo  [3/6] 配置任务栏...
:: 任务栏居中（Windows 11）
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v TaskbarAl /t REG_DWORD /d 1 /f >nul 2>&1
:: 小任务栏图标
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v TaskbarSmallIcons /t REG_DWORD /d 0 /f >nul 2>&1
:: 隐藏任务视图按钮
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v ShowTaskViewButton /t REG_DWORD /d 0 /f >nul 2>&1
:: 隐藏搜索框
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Search" /v SearchboxTaskbarMode /t REG_DWORD /d 0 /f >nul 2>&1
:: 隐藏小组件按钮
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v TaskbarDa /t REG_DWORD /d 0 /f >nul 2>&1

:: ============================================================
:: 4. 设置桌面图标
:: ============================================================
echo  [4/6] 配置桌面...
:: 显示此电脑
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel" /v "{20D04FE0-3AEA-1069-A2D8-08002B30309D}" /t REG_DWORD /d 0 /f >nul 2>&1
:: 隐藏回收站（可选）
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\HideDesktopIcons\NewStartPanel" /v "{645FF040-5081-101B-9F08-00AA002F954E}" /t REG_DWORD /d 1 /f >nul 2>&1

:: ============================================================
:: 5. 创建青柠快捷方式
:: ============================================================
echo  [5/6] 创建青柠快捷方式...
set "DESKTOP=%USERPROFILE%\Desktop"

:: 青柠网盘快捷方式
(
echo [InternetShortcut]
echo URL=https://3862242786-sudo.github.io/pan/
echo IconFile=C:\Windows\System32\shell32.dll
echo IconIndex=14
) > "%DESKTOP%\青柠网盘.url"

:: 青柠应用商店快捷方式
(
echo [InternetShortcut]
echo URL=https://3862242786-sudo.github.io/pan/qingning-store.html
echo IconFile=C:\Windows\System32\shell32.dll
echo IconIndex=15
) > "%DESKTOP%\青柠应用商店.url"

:: 青柠教程快捷方式
(
echo [InternetShortcut]
echo URL=https://3862242786-sudo.github.io/pan/qingning-guide.html
echo IconFile=C:\Windows\System32\shell32.dll
echo IconIndex=23
) > "%DESKTOP%\青柠使用教程.url"

:: ============================================================
:: 6. 设置系统信息
:: ============================================================
echo  [6/6] 应用系统标识...
:: OEM 信息
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\OEMInformation" /v Manufacturer /t REG_SZ /d "青柠OS" /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\OEMInformation" /v Model /t REG_SZ /d "QingningOS 2.0" /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\OEMInformation" /v SupportURL /t REG_SZ /d "https://3862242786-sudo.github.io/pan/qingning-os.html" /f >nul 2>&1

:: 计算机描述
reg add "HKLM\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" /v srvcomment /t REG_SZ /d "青柠OS 计算机" /f >nul 2>&1

:: ============================================================
:: 7. 重启资源管理器
:: ============================================================
echo  [完成] 重启资源管理器应用更改...
taskkill /f /im explorer.exe >nul 2>&1
start explorer.exe

echo.
echo  ╔══════════════════════════════════════════════════════════════╗
echo  ║              青柠OS 初始化完成！                             ║
echo  ╚══════════════════════════════════════════════════════════════╝
echo.
echo  欢迎使用青柠OS！
echo  桌面已添加青柠网盘、应用商店、使用教程快捷方式。
echo.

:: 延迟后退出
timeout /t 3 /nobreak >nul
exit /b 0
