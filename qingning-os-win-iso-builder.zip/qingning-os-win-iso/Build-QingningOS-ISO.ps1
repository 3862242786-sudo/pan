# ============================================================
# 青柠OS Windows ISO 构建脚本 v1.0
# PowerShell 脚本 - 将 Windows ISO 重新封装为青柠OS
# 用法: 右键"使用 PowerShell 运行" 或管理员运行
# ============================================================

#Requires -RunAsAdministrator

param(
    [string]$WindowsISO = "",
    [string]$OutputPath = ".\output\QingningOS-Win10-v2.0.iso"
)

# 设置编码
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$Host.UI.RawUI.BackgroundColor = "Black"
$Host.UI.RawUI.ForegroundColor = "Green"
Clear-Host

# 颜色函数
function Write-QingningLogo {
    Write-Host ""
    Write-Host "  ╔══════════════════════════════════════════════════════════════╗" -ForegroundColor Green
    Write-Host "  ║                                                              ║" -ForegroundColor Green
    Write-Host "  ║         青柠OS Windows ISO 构建工具 v1.0                     ║" -ForegroundColor Green
    Write-Host "  ║         基于 Windows 10/11 ISO 重新封装                      ║" -ForegroundColor Green
    Write-Host "  ║                                                              ║" -ForegroundColor Green
    Write-Host "  ╚══════════════════════════════════════════════════════════════╝" -ForegroundColor Green
    Write-Host ""
}

function Write-Info { param([string]$msg) Write-Host "  [信息] $msg" -ForegroundColor Cyan }
function Write-OK { param([string]$msg) Write-Host "  [OK] $msg" -ForegroundColor Green }
function Write-Warn { param([string]$msg) Write-Host "  [警告] $msg" -ForegroundColor Yellow }
function Write-Error { param([string]$msg) Write-Host "  [错误] $msg" -ForegroundColor Red }

Write-QingningLogo

# ============================================================
# 1. 检查依赖
# ============================================================
Write-Info "检查构建依赖..."

# 检查 7-Zip
$7zipPaths = @(
    "C:\Program Files\7-Zip\7z.exe",
    "C:\Program Files (x86)\7-Zip\7z.exe",
    ".\tools\7z.exe"
)
$7zip = $null
foreach ($path in $7zipPaths) {
    if (Test-Path $path) {
        $7zip = $path
        break
    }
}
if (-not $7zip) {
    Write-Error "未找到 7-Zip！请安装后重试。"
    Write-Info "下载地址: https://www.7-zip.org/"
    Read-Host "按回车键退出"
    exit 1
}
Write-OK "7-Zip: $7zip"

# 检查 oscdimg (Windows ADK)
$oscdimgPaths = @(
    ".\tools\oscdimg.exe",
    "C:\Program Files (x86)\Windows Kits\10\Assessment and Deployment Kit\Deployment Tools\amd64\Oscdimg\oscdimg.exe",
    "C:\Program Files (x86)\Windows Kits\10\Assessment and Deployment Kit\Deployment Tools\x86\Oscdimg\oscdimg.exe"
)
$oscdimg = $null
foreach ($path in $oscdimgPaths) {
    if (Test-Path $path) {
        $oscdimg = $path
        break
    }
}
if (-not $oscdimg) {
    Write-Warn "未找到 oscdimg，将尝试下载或使用备用方案"
}
else {
    Write-OK "oscdimg: $oscdimg"
}

# 检查 DISM
$dism = Get-Command dism -ErrorAction SilentlyContinue
if (-not $dism) {
    Write-Warn "未找到 DISM，某些功能可能不可用"
}
else {
    Write-OK "DISM 已就绪"
}

# ============================================================
# 2. 查找 Windows ISO
# ============================================================
if (-not $WindowsISO) {
    $isoFiles = Get-ChildItem -Path "." -Filter "*.iso" -File
    if ($isoFiles.Count -eq 0) {
        Write-Error "未找到 Windows ISO 文件！"
        Write-Info "请将 Windows 10/11 ISO 放到此文件夹"
        Write-Info "下载地址: https://www.microsoft.com/software-download/windows10"
        Read-Host "按回车键退出"
        exit 1
    }
    elseif ($isoFiles.Count -eq 1) {
        $WindowsISO = $isoFiles[0].FullName
    }
    else {
        Write-Info "找到多个 ISO，请选择:"
        for ($i = 0; $i -lt $isoFiles.Count; $i++) {
            Write-Host "  [$($i+1)] $($isoFiles[$i].Name)"
        }
        $choice = Read-Host "输入编号"
        $WindowsISO = $isoFiles[[int]$choice - 1].FullName
    }
}

if (-not (Test-Path $WindowsISO)) {
    Write-Error "ISO 文件不存在: $WindowsISO"
    Read-Host "按回车键退出"
    exit 1
}
Write-OK "使用 ISO: $(Split-Path $WindowsISO -Leaf)"

# ============================================================
# 3. 准备工作目录
# ============================================================
$buildDir = $PSScriptRoot
if (-not $buildDir) { $buildDir = Get-Location }
$workDir = Join-Path $buildDir "work"
$isoDir = Join-Path $workDir "iso"
$wimDir = Join-Path $workDir "wim"
$mountDir = Join-Path $workDir "mount"
$assetsDir = Join-Path $buildDir "assets"
$configDir = Join-Path $buildDir "config"
$outputDir = Join-Path $buildDir "output"

Write-Info "准备工作目录..."
Remove-Item -Path $workDir -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Path $isoDir -Force | Out-Null
New-Item -ItemType Directory -Path $wimDir -Force | Out-Null
New-Item -ItemType Directory -Path $mountDir -Force | Out-Null
New-Item -ItemType Directory -Path $outputDir -Force | Out-Null
Write-OK "工作目录准备完成"

# ============================================================
# 4. 解压 ISO
# ============================================================
Write-Info "解压 Windows ISO..."
Write-Info "这可能需要 5-15 分钟，请耐心等待..."

& $7zip x "$WindowsISO" -o"$isoDir" -y | Out-Null
if ($LASTEXITCODE -ne 0) {
    Write-Error "ISO 解压失败！"
    Read-Host "按回车键退出"
    exit 1
}
Write-OK "ISO 解压完成"

# ============================================================
# 5. 查找 install.wim 或 install.esd
# ============================================================
$wimFile = Get-ChildItem -Path $isoDir -Recurse -Filter "install.wim" | Select-Object -First 1
$esdFile = Get-ChildItem -Path $isoDir -Recurse -Filter "install.esd" | Select-Object -First 1

$installImage = $null
$isESD = $false

if ($wimFile) {
    $installImage = $wimFile.FullName
    Write-OK "找到 install.wim"
}
elseif ($esdFile) {
    $installImage = $esdFile.FullName
    $isESD = $true
    Write-OK "找到 install.esd"
}
else {
    Write-Error "未找到 install.wim 或 install.esd！"
    Write-Info "此 ISO 可能不是标准的 Windows 安装镜像"
    Read-Host "按回车键退出"
    exit 1
}

# ============================================================
# 6. 应用青柠定制到 WIM/ESD
# ============================================================
Write-Info "应用青柠OS品牌定制..."

# 6.1 复制 autounattend.xml
if (Test-Path "$configDir\autounattend.xml") {
    Copy-Item "$configDir\autounattend.xml" "$isoDir\autounattend.xml" -Force
    Write-OK "添加无人值守安装配置"
}

# 6.2 创建 QingningOS 目录结构
$qingningDir = "$isoDir\QingningOS"
New-Item -ItemType Directory -Path $qingningDir -Force | Out-Null

# 复制设置脚本
if (Test-Path "$assetsDir\qingning-setup.bat") {
    Copy-Item "$assetsDir\qingning-setup.bat" "$qingningDir\qingning-setup.bat" -Force
}

# 复制壁纸
if (Test-Path "$assetsDir\wallpaper.jpg") {
    Copy-Item "$assetsDir\wallpaper.jpg" "$qingningDir\wallpaper.jpg" -Force
}

# 6.3 使用 DISM 修改 WIM（如果可用）
if ($dism -and (Test-Path $installImage)) {
    Write-Info "尝试使用 DISM 修改安装镜像..."
    
    try {
        # 获取镜像信息
        $imageInfo = & dism /Get-WimInfo /WimFile:"$installImage" /English 2>$null
        $imageIndex = 1
        
        # 查找 Pro 版本
        if ($imageInfo -match "Index : (\d+)") {
            $imageIndex = $matches[1]
        }
        
        Write-Info "挂载镜像索引 $imageIndex..."
        & dism /Mount-Wim /WimFile:"$installImage" /Index:$imageIndex /MountDir:"$mountDir" /English | Out-Null
        
        if ($LASTEXITCODE -eq 0) {
            Write-OK "镜像挂载成功"
            
            # 复制青柠文件到挂载的镜像
            $qingningMountDir = "$mountDir\QingningOS"
            New-Item -ItemType Directory -Path $qingningMountDir -Force | Out-Null
            
            if (Test-Path "$assetsDir\qingning-setup.bat") {
                Copy-Item "$assetsDir\qingning-setup.bat" "$qingningMountDir\qingning-setup.bat" -Force
            }
            if (Test-Path "$assetsDir\wallpaper.jpg") {
                Copy-Item "$assetsDir\wallpaper.jpg" "$qingningMountDir\wallpaper.jpg" -Force
            }
            
            # 复制 oobe 配置
            $oobeDir = "$mountDir\Windows\System32\oobe"
            if (Test-Path $oobeDir) {
                # 创建首次运行脚本
                $firstRun = "$mountDir\Windows\Setup\Scripts\SetupComplete.cmd"
                New-Item -ItemType Directory -Path (Split-Path $firstRun) -Force | Out-Null
                
                @"
@echo off
echo 青柠OS 安装完成，正在应用主题...
if exist C:\QingningOS\qingning-setup.bat (
    call C:\QingningOS\qingning-setup.bat
)
exit /b 0
"@ | Set-Content -Path $firstRun -Encoding ASCII -Force
                
                Write-OK "添加安装完成脚本"
            }
            
            # 保存并卸载镜像
            Write-Info "保存并卸载镜像..."
            & dism /Unmount-Wim /MountDir:"$mountDir" /Commit /English | Out-Null
            Write-OK "镜像修改完成"
        }
        else {
            Write-Warn "镜像挂载失败，将使用备用方案"
        }
    }
    catch {
        Write-Warn "DISM 操作失败: $_"
        # 确保卸载
        & dism /Unmount-Wim /MountDir:"$mountDir" /Discard /English 2>$null | Out-Null
    }
}
else {
    Write-Warn "DISM 不可用，使用文件级修改方案"
}

# ============================================================
# 7. 修改启动菜单
# ============================================================
Write-Info "修改启动菜单..."

# 修改 bootmgr 显示
$bcdFile = "$isoDir\boot\bcd"
if (Test-Path $bcdFile) {
    Write-Info "检测到 BCD 文件，启动菜单将在安装时显示"
}

# 修改 EFI 启动菜单
$efiBootDir = "$isoDir\efi\microsoft\boot"
if (Test-Path $efiBootDir) {
    $bcdEfi = "$efiBootDir\bcd"
    if (Test-Path $bcdEfi) {
        Write-Info "EFI 启动配置已找到"
    }
}

# 创建自定义启动提示
$bootMsg = @"
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║              青柠OS Windows 安装程序                         ║
║              QingningOS Windows Setup                        ║
║                                                              ║
║  基于 Windows 10/11 定制                                     ║
║  官网: https://3862242786-sudo.github.io/pan/               ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝

正在启动安装程序...
"@

$bootMsg | Set-Content -Path "$isoDir\QingningOS\boot-message.txt" -Encoding UTF8 -Force
Write-OK "启动菜单配置完成"

# ============================================================
# 8. 生成新的 ISO
# ============================================================
Write-Info "生成青柠OS ISO 镜像..."

$finalIso = Join-Path $outputDir "QingningOS-Win10-v2.0.iso"

if ($oscdimg) {
    Write-Info "使用 oscdimg 生成 ISO..."
    
    # 检测启动文件
    $bootFile = "$isoDir\boot\etfsboot.com"
    $efiFile = "$isoDir\efi\microsoft\boot\efisys.bin"
    
    $bootData = "2#p0,e,b`"$bootFile`""
    if (Test-Path $efiFile) {
        $bootData = "2#p0,e,b`"$bootFile`"#pEF,e,b`"$efiFile`""
    }
    
    & $oscdimg -m -o -u2 -udfver102 -bootdata:$bootData -l"QingningOS-2.0" "$isoDir" "$finalIso" 2>&1 | Out-Null
    
    if ($LASTEXITCODE -eq 0 -and (Test-Path $finalIso)) {
        Write-OK "ISO 生成成功！"
    }
    else {
        Write-Warn "oscdimg 失败，尝试备用方案..."
        $oscdimg = $null
    }
}

# 备用方案：使用 PowerShell 或 7-Zip
if (-not (Test-Path $finalIso)) {
    Write-Info "使用 7-Zip 创建 ISO..."
    & $7zip a -tiso "$finalIso" "$isoDir\*" | Out-Null
    
    if (Test-Path $finalIso) {
        Write-OK "ISO 创建成功（7-Zip模式）"
    }
    else {
        Write-Warn "ISO 创建失败，创建 ZIP 包作为备用..."
        $zipFile = Join-Path $outputDir "QingningOS-Win10-v2.0-files.zip"
        & $7zip a -tzip "$zipFile" "$isoDir\*" | Out-Null
        $finalIso = $zipFile
    }
}

# ============================================================
# 9. 完成
# ============================================================
Write-Host ""
Write-Host "  ╔══════════════════════════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "  ║                     构建完成！                               ║" -ForegroundColor Green
Write-Host "  ╚══════════════════════════════════════════════════════════════╝" -ForegroundColor Green
Write-Host ""

if (Test-Path $finalIso) {
    $fileSize = (Get-Item $finalIso).Length
    $sizeMB = [math]::Round($fileSize / 1MB, 2)
    
    Write-OK "输出文件: $finalIso"
    Write-OK "文件大小: $sizeMB MB"
    Write-Host ""
    Write-Host "  ════════════════════════════════════════════════════════════" -ForegroundColor Cyan
    Write-Host "  虚拟机使用方法:" -ForegroundColor Cyan
    Write-Host "  ════════════════════════════════════════════════════════════" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "  VMware:"
    Write-Host "    文件 → 新建虚拟机 → 典型 → 稍后安装操作系统"
    Write-Host "    → Microsoft Windows → Windows 10 x64"
    Write-Host "    → 2核 / 4GB内存 / 60GB磁盘"
    Write-Host "    → CD/DVD → 使用ISO镜像文件 → 选择此ISO"
    Write-Host ""
    Write-Host "  VirtualBox:"
    Write-Host "    新建 → 类型: Microsoft Windows → 版本: Windows 10 (64-bit)"
    Write-Host "    → 4096 MB内存 → 创建虚拟硬盘: 60 GB"
    Write-Host "    → 设置 → 存储 → 光驱 → 选择虚拟光盘文件"
    Write-Host "    → 选择此ISO → 确定 → 启动"
    Write-Host ""
    Write-Host "  ════════════════════════════════════════════════════════════" -ForegroundColor Cyan
    Write-Host "  安装后效果:" -ForegroundColor Cyan
    Write-Host "  ════════════════════════════════════════════════════════════" -ForegroundColor Cyan
    Write-Host "  ✓ 自动安装，无需手动操作"
    Write-Host "  ✓ 用户名: qingning / 密码: qingning"
    Write-Host "  ✓ 深色主题 + 青柠绿强调色"
    Write-Host "  ✓ 任务栏居中 + 隐藏搜索/小组件"
    Write-Host "  ✓ 桌面有青柠网盘/商店/教程快捷方式"
    Write-Host "  ✓ 系统信息中显示青柠OS"
    Write-Host ""
}

# 清理
$clean = Read-Host "  是否清理临时文件? (Y/N)"
if ($clean -eq "Y" -or $clean -eq "y") {
    Remove-Item -Path $workDir -Recurse -Force -ErrorAction SilentlyContinue
    Write-OK "临时文件已清理"
}

Write-Host ""
Read-Host "  按回车键退出"
exit 0
