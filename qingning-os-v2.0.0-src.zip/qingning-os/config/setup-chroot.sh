#!/bin/bash
# ============================================================
# 青柠OS Chroot 环境配置脚本 v2.0
# 支持 Debian Bookworm / XUbuntu 24.04
# 在 chroot 环境内运行，完成系统安装与配置
# ============================================================
set -euo pipefail

# ---------- 颜色定义 ----------
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
NC='\033[0m'

log()  { echo -e "${GREEN}[青柠OS]${NC} $1"; }
info() { echo -e "${CYAN}[信息]${NC} $1"; }
warn() { echo -e "${YELLOW}[警告]${NC} $1"; }

# ============================================================
# 1. 基本系统配置
# ============================================================
log "正在配置基本系统..."

# 设置主机名
echo "qingning-os" > /etc/hostname
echo "127.0.0.1   localhost" > /etc/hosts
echo "127.0.1.1   qingning-os" >> /etc/hosts

# 设置时区
ln -sf /usr/share/zoneinfo/Asia/Shanghai /etc/localtime
echo "Asia/Shanghai" > /etc/timezone

# 设置 locale
sed -i 's/# zh_CN.UTF-8 UTF-8/zh_CN.UTF-8 UTF-8/' /etc/locale.gen 2>/dev/null || true
sed -i 's/# en_US.UTF-8 UTF-8/en_US.UTF-8 UTF-8/' /etc/locale.gen 2>/dev/null || true
locale-gen zh_CN.UTF-8 en_US.UTF-8 2>/dev/null || true
update-locale LANG=zh_CN.UTF-8 LANGUAGE=zh_CN:en_US 2>/dev/null || true

# ============================================================
# 2. 配置 APT 源
# ============================================================
log "正在配置 APT 软件源..."

# 检测基础系统
if [ -f /etc/debian_version ]; then
    DEBIAN_VERSION=$(cat /etc/debian_version)
    info "检测到 Debian 版本: ${DEBIAN_VERSION}"
fi

# 配置国内镜像源（加速下载）
cat > /etc/apt/sources.list << 'EOF'
# 青柠OS - 软件源配置
deb https://mirrors.tuna.tsinghua.edu.cn/debian bookworm main contrib non-free-firmware
deb https://mirrors.tuna.tsinghua.edu.cn/debian bookworm-updates main contrib non-free-firmware
deb https://mirrors.tuna.tsinghua.edu.cn/debian-security bookworm-security main contrib non-free-firmware
EOF

# ============================================================
# 3. 更新软件包列表
# ============================================================
log "正在更新软件包列表..."
apt-get update -qq

# ============================================================
# 4. 安装内核
# ============================================================
log "正在安装 Linux 内核..."
apt-get install -y -qq linux-image-amd64 firmware-linux-free 2>/dev/null || true

# ============================================================
# 5. 读取并安装软件包列表
# ============================================================
log "正在安装 青柠OS 软件包..."
info "此步骤需要较长时间，请耐心等待..."

# 从 list.txt 读取软件包并安装
if [ -f /packages-list.txt ]; then
    PACKAGES=$(grep -v '^#' /packages-list.txt | grep -v '^$' | tr '\n' ' ')
    log "正在安装软件包..."
    DEBIAN_FRONTEND=noninteractive apt-get install -y -qq ${PACKAGES} 2>/dev/null || {
        warn "部分软件包安装失败，尝试逐个安装..."
        while read pkg; do
            [ -z "$pkg" ] && continue
            [[ "$pkg" =~ ^# ]] && continue
            DEBIAN_FRONTEND=noninteractive apt-get install -y -qq "$pkg" 2>/dev/null || warn "无法安装: $pkg"
        done < /packages-list.txt
    }
else
    warn "未找到软件包列表，安装默认 XFCE4 环境..."
    DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
        xfce4 xfce4-goodies lightdm network-manager-gnome 2>/dev/null || true
fi

# ============================================================
# 6. 安装额外青柠主题和工具
# ============================================================
log "安装青柠主题和工具..."
apt-get install -y -qq \
    plank \
    materia-gtk-theme \
    papirus-icon-theme \
    fonts-noto-cjk \
    fonts-hack-ttf \
    neofetch \
    htop \
    git \
    curl \
    wget \
    jq \
    2>/dev/null || true

# ============================================================
# 7. 安装 GRUB 引导器
# ============================================================
log "正在安装 GRUB 引导器..."
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
    grub-efi-amd64 grub-pc-bin os-prober 2>/dev/null || true

# ============================================================
# 8. 用户管理
# ============================================================
log "正在配置用户..."

# 设置 root 密码
echo "root:qingning" | chpasswd
info "root 密码已设置为: qingning"

# 创建普通用户 qingning
if ! id qingning &>/dev/null; then
    useradd -m -s /bin/bash -G sudo,cdrom,floppy,audio,dip,video,plugdev,netdev qingning
    echo "qingning:qingning" | chpasswd
    info "用户 qingning 已创建，密码: qingning"
else
    echo "qingning:qingning" | chpasswd
    info "用户 qingning 密码已更新"
fi

# ============================================================
# 9. 配置 LightDM 自动登录
# ============================================================
log "正在配置 LightDM 显示管理器..."

mkdir -p /etc/lightdm/lightdm.conf.d
cat > /etc/lightdm/lightdm.conf.d/01-qingning-autologin.conf << 'EOF'
[Seat:*]
autologin-user=qingning
autologin-user-timeout=0
greeter-session=lightdm-gtk-greeter
EOF

# 配置 LightDM GTK Greeter 主题 - 青柠风格
cat > /etc/lightdm/lightdm-gtk-greeter.conf << 'EOF'
[greeter]
theme-name=Materia-dark
icon-theme-name=Papirus
font-name=Noto Sans CJK SC 11
background=#0f172a
EOF

# ============================================================
# 10. 配置 XFCE4 青柠主题
# ============================================================
log "正在配置 XFCE4 桌面环境..."

# 创建 XFCE4 默认配置目录
QINGNING_HOME="/home/qingning"
mkdir -p "${QINGNING_HOME}/.config/xfce4/xfconf/xfce-perchannel-xml"
mkdir -p "${QINGNING_HOME}/.config/xfce4/panel"
mkdir -p "${QINGNING_HOME}/.config/xfce4/terminal"
mkdir -p "${QINGNING_HOME}/.config/plank"
mkdir -p "${QINGNING_HOME}/.config/neofetch"

# --- XFWM4 窗口管理器配置 ---
cat > "${QINGNING_HOME}/.config/xfce4/xfconf/xfce-perchannel-xml/xfwm4.xml" << 'XFWMEOF'
<?xml version="1.0" encoding="UTF-8"?>
<channel name="xfwm4" version="1.0">
  <property name="/general/theme" type="string" value="Materia-dark"/>
  <property name="/general/button_layout" type="string" value="O|SHMC"/>
  <property name="/general/title_font" type="string" value="Noto Sans CJK SC Bold 11"/>
  <property name="/general/placement_ratio" type="int" value="30"/>
  <property name="/general/snap_to_border" type="bool" value="true"/>
  <property name="/general/snap_to_windows" type="bool" value="true"/>
  <property name="/general/use_compositing" type="bool" value="true"/>
  <property name="/general/vblank_mode" type="string" value="auto"/>
  <property name="/general/workspace_names" type="array">
    <value type="string" value="工作区 1"/>
    <value type="string" value="工作区 2"/>
    <value type="string" value="工作区 3"/>
    <value type="string" value="工作区 4"/>
  </property>
</channel>
XFWMEOF

# --- XFCE4 桌面配置 - 青柠壁纸 ---
cat > "${QINGNING_HOME}/.config/xfce4/xfconf/xfce-perchannel-xml/xfce4-desktop.xml" << 'DESKEOF'
<?xml version="1.0" encoding="UTF-8"?>
<channel name="xfce4-desktop" version="1.0">
  <property name="/backdrop/screen0/monitorscreen/workspace0/last-image" type="string" value="/usr/share/backgrounds/qingning/qingning-default.svg"/>
  <property name="/backdrop/screen0/monitorscreen/workspace0/color-style" type="int" value="0"/>
  <property name="/backdrop/screen0/monitorscreen/workspace0/image-style" type="int" value="5"/>
  <property name="/backdrop/screen0/monitorscreen/workspace0/color1" type="array">
    <value type="double" value="0.059"/>
    <value type="double" value="0.090"/>
    <value type="double" value="0.165"/>
  </property>
  <property name="/backdrop/screen0/monitorscreen/workspace0/color2" type="array">
    <value type="double" value="0.133"/>
    <value type="double" value="0.773"/>
    <value type="double" value="0.369"/>
  </property>
</channel>
DESKEOF

# --- XFCE4 外观设置 ---
cat > "${QINGNING_HOME}/.config/xfce4/xfconf/xfce-perchannel-xml/xsettings.xml" << 'XSETTINGSEOF'
<?xml version="1.0" encoding="UTF-8"?>
<channel name="xsettings" version="1.0">
  <property name="Net/ThemeName" type="string" value="Materia-dark"/>
  <property name="Net/IconThemeName" type="string" value="Papirus"/>
  <property name="Gtk/FontName" type="string" value="Noto Sans CJK SC 11"/>
  <property name="Gtk/CursorThemeName" type="string" value="Adwaita"/>
  <property name="Gtk/CursorThemeSize" type="int" value="24"/>
  <property name="Gtk/MenusHaveIcons" type="bool" value="true"/>
  <property name="Gtk/ButtonImages" type="bool" value="true"/>
  <property name="Gtk/ToolbarStyle" type="string" value="icons"/>
  <property name="Xft/Antialias" type="int" value="1"/>
  <property name="Xft/Hinting" type="int" value="1"/>
  <property name="Xft/HintStyle" type="string" value="hintslight"/>
  <property name="Xft/RGBA" type="string" value="rgb"/>
</channel>
XSETTINGSEOF

# --- XFCE4 终端配置 - 青柠配色 ---
cat > "${QINGNING_HOME}/.config/xfce4/terminal/terminalrc" << 'TERMEOF'
[Configuration]
ColorForeground=#e2e8f0
ColorBackground=#0f172a
ColorCursor=#22c55e
ColorPalette=#0f172a;#ef4444;#22c55e;#eab308;#3b82f6;#a855f7;#06b6d4;#e2e8f0;#64748b;#f87171;#4ade80;#facc15;#60a5fa;#c084fc;#22d3ee;#ffffff
FontName=Hack 12
ScrollingMode=1
ScrollbackLines=5000
TabActivityColor=#22c55e
TERMEOF

# --- Plank Dock 配置 - 类似苹果Dock ---
mkdir -p "${QINGNING_HOME}/.config/plank/dock1"
cat > "${QINGNING_HOME}/.config/plank/dock1/settings" << 'PLANKEOF'
[PlankDockPreferences]
CurrentWorkspaceOnly=false
IconSize=48
ItemsAlign=center
LockItems=false
Monitor=
Offset=0
PinnedOnly=false
Position=bottom
Theme=Qingning
ZoomEnabled=true
ZoomPercent=150
HideMode=Intelligent
PLANKEOF

# ============================================================
# 11. 全局 Material Design 主题配置
# ============================================================
log "正在应用 Material Design 主题..."

# 全局 GTK 配置
mkdir -p /etc/gtk-3.0
cat > /etc/gtk-3.0/settings.ini << 'GTK3EOF'
[Settings]
gtk-theme-name=Materia-dark
gtk-icon-theme-name=Papirus
gtk-font-name=Noto Sans CJK SC 11
gtk-cursor-theme-name=Adwaita
gtk-cursor-theme-size=24
gtk-toolbar-style=GTK_TOOLBAR_ICONS
gtk-menu-images=1
gtk-button-images=1
gtk-application-prefer-dark-theme=true
GTK3EOF

# GTK2 全局配置
mkdir -p /etc/gtk-2.0
cat > /etc/gtk-2.0/gtkrc << 'GTK2EOF'
gtk-theme-name="Materia-dark"
gtk-icon-theme-name="Papirus"
gtk-font-name="Noto Sans CJK SC 11"
gtk-cursor-theme-name="Adwaita"
gtk-toolbar-style=GTK_TOOLBAR_ICONS
gtk-menu-images=1
gtk-button-images=1
GTK2EOF

# ============================================================
# 12. 青柠OS 品牌标识
# ============================================================
log "正在设置 青柠OS 品牌标识..."

# 确保 os-release 已正确设置
cat > /etc/os-release << 'OSRELEOF'
NAME="青柠OS"
VERSION="2.0.0"
ID=qingning-os
ID_LIKE=debian
PRETTY_NAME="青柠OS 2.0.0 (XUbuntu)"
HOME_URL="https://3862242786-sudo.github.io/pan/qingning-os.html"
SUPPORT_URL="https://3862242786-sudo.github.io/pan/qingning-guide.html"
BUG_REPORT_URL="https://github.com/3862242786-sudo/qingning-os/issues"
LOGO=qingning-os
OSRELEOF

# 设置 lsb-release
cat > /etc/lsb-release << 'LSBEOF'
DISTRIB_ID=QingningOS
DISTRIB_RELEASE=2.0.0
DISTRIB_CODENAME=XUbuntu
DISTRIB_DESCRIPTION="青柠OS 2.0.0 (XUbuntu)"
LSBEOF

# 设置 issue 文件
cat > /etc/issue << 'ISSUEEOF'
青柠OS 2.0.0 (XUbuntu) \n \l

ISSUEEOF
cat > /etc/issue.net << 'ISSUENETEOF'
青柠OS 2.0.0 (XUbuntu)
ISSUENETEOF

# ============================================================
# 13. 创建青柠壁纸
# ============================================================
log "创建青柠品牌壁纸..."
mkdir -p /usr/share/backgrounds/qingning

cat > /usr/share/backgrounds/qingning/qingning-default.svg << 'WALLPAPEREOF'
<svg xmlns="http://www.w3.org/2000/svg" width="1920" height="1080" viewBox="0 0 1920 1080">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#0f172a"/>
      <stop offset="50%" style="stop-color:#1e293b"/>
      <stop offset="100%" style="stop-color:#0f172a"/>
    </linearGradient>
    <radialGradient id="glow" cx="50%" cy="50%" r="50%">
      <stop offset="0%" style="stop-color:#22c55e;stop-opacity:0.15"/>
      <stop offset="100%" style="stop-color:#22c55e;stop-opacity:0"/>
    </radialGradient>
  </defs>
  <rect width="1920" height="1080" fill="url(#bg)"/>
  <circle cx="960" cy="400" r="400" fill="url(#glow)"/>
  <g transform="translate(860, 320) scale(8)">
    <path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z" fill="none" stroke="#22c55e" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
  </g>
  <text x="960" y="580" text-anchor="middle" font-family="Noto Sans CJK SC, sans-serif" font-size="48" font-weight="bold" fill="#e2e8f0">青柠OS</text>
  <text x="960" y="630" text-anchor="middle" font-family="Noto Sans CJK SC, sans-serif" font-size="20" fill="#64748b">QingningOS 2.0.0 · Powered by XUbuntu</text>
  <line x1="760" y1="680" x2="1160" y2="680" stroke="#22c55e" stroke-width="2" opacity="0.5"/>
</svg>
WALLPAPEREOF

# 转换壁纸为PNG（如果有转换工具）
if command -v rsvg-convert &>/dev/null; then
    rsvg-convert -w 1920 -h 1080 /usr/share/backgrounds/qingning/qingning-default.svg -o /usr/share/backgrounds/qingning/qingning-default.png 2>/dev/null || true
fi

# ============================================================
# 14. 创建青柠应用启动器
# ============================================================
log "创建青柠应用启动器..."
mkdir -p /usr/share/applications/qingning

# 青柠网盘 Web 启动器
cat > /usr/share/applications/qingning/qingning-pan.desktop << 'EOF'
[Desktop Entry]
Version=1.0
Type=Application
Name=青柠网盘
Comment=青柠云存储服务
Exec=firefox https://3862242786-sudo.github.io/pan/
Icon=folder-remote
Terminal=false
Categories=Network;FileTransfer;
EOF

# 青柠应用商店启动器
cat > /usr/share/applications/qingning/qingning-store.desktop << 'EOF'
[Desktop Entry]
Version=1.0
Type=Application
Name=青柠应用商店
Comment=下载青柠系列应用
Exec=firefox https://3862242786-sudo.github.io/pan/qingning-store.html
Icon=applications-system
Terminal=false
Categories=Network;
EOF

# 青柠教程启动器
cat > /usr/share/applications/qingning/qingning-guide.desktop << 'EOF'
[Desktop Entry]
Version=1.0
Type=Application
Name=青柠使用教程
Comment=青柠OS使用指南
Exec=firefox https://3862242786-sudo.github.io/pan/qingning-guide.html
Icon=help-browser
Terminal=false
Categories=Network;
EOF

# ============================================================
# 15. GRUB 配置
# ============================================================
log "正在配置 GRUB 引导器..."

mkdir -p /etc/default/grub.d
cat > /etc/default/grub.d/99-qingning.cfg << 'GRUBEOF'
# 青柠OS GRUB 自定义配置
GRUB_DEFAULT=0
GRUB_TIMEOUT=5
GRUB_TIMEOUT_STYLE=menu
GRUB_DISTRIBUTOR="青柠OS"
GRUB_CMDLINE_LINUX_DEFAULT="quiet splash"
GRUB_CMDLINE_LINUX=""
GRUB_TERMINAL_OUTPUT="gfxterm"
GRUB_GFXMODE=1920x1080x32
GRUB_GFXPAYLOAD_LINUX=keep
GRUB_BACKGROUND="/usr/share/backgrounds/qingning/qingning-default.svg"
GRUB_DISABLE_OS_PROBER=false
GRUBEOF

# ============================================================
# 16. 网络配置
# ============================================================
log "正在配置网络..."

# 启用 NetworkManager
systemctl enable NetworkManager 2>/dev/null || true

# 配置 /etc/network/interfaces (备用)
cat > /etc/network/interfaces << 'NETEOF'
# 青柠OS 网络配置
# 由 NetworkManager 管理
auto lo
iface lo inet loopback
NETEOF

# ============================================================
# 17. 系统服务配置
# ============================================================
log "正在配置系统服务..."

# 启用必要服务
systemctl enable lightdm    2>/dev/null || true
systemctl enable bluetooth  2>/dev/null || true

# 禁用不必要的服务 (虚拟机环境)
systemctl disable modemmanager 2>/dev/null || true

# ============================================================
# 18. 安装后脚本 (首次启动)
# ============================================================
log "正在配置首次启动脚本..."

if [ -f /usr/local/bin/qingning-post-install.sh ]; then
    chmod +x /usr/local/bin/qingning-post-install.sh

    # 创建 systemd 服务用于首次启动
    cat > /etc/systemd/system/qingning-welcome.service << 'SVCEOF'
[Unit]
Description=青柠OS 欢迎信息
After=graphical.target
ConditionPathExists=/usr/local/bin/qingning-post-install.sh

[Service]
Type=oneshot
ExecStart=/usr/local/bin/qingning-post-install.sh
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
SVCEOF

    systemctl enable qingning-welcome 2>/dev/null || true
fi

# ============================================================
# 19. Bash 配置
# ============================================================
log "正在配置 Shell..."

# 全局 bashrc 追加 青柠OS 信息
cat >> /etc/bash.bashrc << 'BASHEOF'

# ===== 青柠OS 自定义配置 =====
export PS1='\[\033[0;32m\]\u@青柠OS\[\033[0m\]:\[\033[0;34m\]\w\[\033[0m\]\$ '
alias ll='ls -alh --color=auto'
alias la='ls -A --color=auto'
alias l='ls -CF --color=auto'
alias cls='clear'
alias update='sudo apt update && sudo apt upgrade -y'
alias neofetch='neofetch --source ~/.config/neofetch/qingningos 2>/dev/null || neofetch'

# 青柠OS 欢迎信息 (仅在交互式 Shell 中显示)
if [ -z "${debian_chroot:-}" ] && [ -t 0 ]; then
    echo -e "\033[0;32m"
    echo "  ╔══════════════════════════════════════╗"
    echo "  ║           青柠OS 2.0.0               ║"
    echo "  ║      Debian + XFCE4 + 青柠定制       ║"
    echo "  ╚══════════════════════════════════════╝"
    echo -e "\033[0m"
fi
BASHEOF

# ============================================================
# 20. Neofetch 自定义配置
# ============================================================
log "正在配置 Neofetch..."

mkdir -p "${QINGNING_HOME}/.config/neofetch"
cat > "${QINGNING_HOME}/.config/neofetch/config.conf" << 'NEOFETCHEOF'
print_info() {
    info title
    info underline

    info "OS" distro
    info "Kernel" kernel
    info "Uptime" uptime
    info "Packages" packages
    info "Shell" shell
    info "DE" de
    info "WM" wm
    info "Theme" theme
    info "Icons" icons
    info "Terminal" term
    info "CPU" cpu
    info "Memory" memory

    info underline
    info cols
}

image_source="auto"
NEOFETCHEOF

# 青柠OS ASCII logo
cat > "${QINGNING_HOME}/.config/neofetch/qingningos" << 'LOGOEOF'
${c1}  ██████████
${c1}  ██${c2}░░░░░░░░${c1}██
${c1}  ██${c2}░${c3}████${c2}░░░░${c1}██
${c1}  ██${c2}░${c3}██${c2}░░░░░░${c1}██
${c1}  ██${c2}░${c3}████${c2}░░░░${c1}██
${c1}  ██${c2}░░░░░░░░${c1}██
${c1}  ██████████
${c2}  ═══════════════
${c2}  青柠OS
${c2}  v2.0.0 XUbuntu
LOGOEOF

# ============================================================
# 21. 设置文件权限
# ============================================================
log "正在设置文件权限..."
chown -R qingning:qingning "${QINGNING_HOME}"
chmod 755 /usr/local/bin/qingning-post-install.sh 2>/dev/null || true

# ============================================================
# 22. 清理 APT 缓存
# ============================================================
log "正在清理系统..."
apt-get clean
apt-get autoremove -y -qq 2>/dev/null || true
rm -f /packages-list.txt
rm -f /setup-chroot.sh

# ============================================================
# 完成
# ============================================================
log "Chroot 环境配置完成!"
echo ""
info "青柠OS 系统已配置完毕。"
info "用户: qingning / qingning"
info "Root: root / qingning"
