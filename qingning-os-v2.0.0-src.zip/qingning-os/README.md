# QingningOS - 清宁操作系统

基于 Debian Bookworm 的 Material Design 风格 Linux 发行版，专为 VMware/VirtualBox 虚拟机优化。

## 系统信息

| 项目 | 说明 |
|------|------|
| 基础系统 | Debian 12 (Bookworm) |
| 桌面环境 | XFCE4 |
| 主题风格 | Material Design (Materia-dark + Papirus) |
| 目标架构 | amd64 (x86_64) |
| 启动方式 | UEFI (支持 BIOS 兼容) |
| 目标平台 | VMware / VirtualBox 虚拟机 |

## 构建要求

### 硬件要求

- CPU: x86_64 架构
- 内存: 至少 2GB (建议 4GB)
- 磁盘空间: 至少 10GB 可用空间
- 网络: 需要网络连接以下载软件包

### 软件要求

- **宿主系统**: Debian 11/12 或 Ubuntu 20.04/22.04/24.04
- **权限**: 需要 root 权限
- **构建工具**: debootstrap, xorriso, grub-mkrescue 等 (脚本会自动安装)

## 构建步骤

### 1. 克隆项目

```bash
git clone https://github.com/3862242786-sudo/qingning-os.git
cd qingning-os
```

### 2. 运行构建脚本

```bash
sudo ./build.sh
```

构建过程说明:

1. **安装构建依赖** - 自动安装 debootstrap、xorriso 等工具
2. **创建磁盘镜像** - 创建 4GB ext4 格式磁盘镜像
3. **引导 Debian** - 使用 debootstrap 安装最小化 Debian 系统
4. **系统配置** - 进入 chroot 环境完成系统安装与配置
5. **生成 ISO** - 使用 xorriso 创建可启动 ISO 镜像

> 构建过程需要较长时间 (约 30-60 分钟，取决于网络速度)

### 3. 获取 ISO

构建完成后，ISO 文件位于:

```
output/qingning-os-1.0.0-amd64.iso
```

## 虚拟机配置建议

### VMware

| 配置项 | 建议值 |
|--------|--------|
| 内存 | 2048MB (最低) / 4096MB (推荐) |
| 处理器 | 2 核 |
| 磁盘 | 20GB (动态增长) |
| 网络 | NAT 或 桥接模式 |
| 固件类型 | UEFI |
| 3D 加速 | 启用 |

### VirtualBox

| 配置项 | 建议值 |
|--------|--------|
| 内存 | 2048MB (最低) / 4096MB (推荐) |
| 处理器 | 2 核 |
| 磁盘 | 20GB (动态分配) |
| 网络 | NAT 或 桥接网卡 |
| 固件类型 | EFI (启用) |
| 3D 加速 | 启用 |
| 客户机增强 | 安装 Guest Additions |

## 默认账户

| 用户名 | 密码 | 权限 |
|--------|------|------|
| qingning | qingning | 普通用户 (sudo) |
| root | qingning | 管理员 |

## 预装软件

### 桌面环境
- XFCE4 + XFCE4 Goodies
- Whisker 菜单插件

### Material Design 主题
- Materia GTK 主题 (深色)
- Papirus 图标主题

### 办公软件
- Firefox ESR (浏览器)
- Thunderbird (邮件)
- LibreOffice (办公套件)

### 多媒体
- VLC (媒体播放器)
- Ristretto (图片查看器)

### 系统工具
- HTop (进程管理)
- Neofetch (系统信息)
- GNOME Disk Utility (磁盘管理)
- NetworkManager (网络管理)
- PulseAudio 音量控制

### 字体
- Noto CJK (中日韩字体)
- Noto Color Emoji (彩色表情)
- Hack (编程字体)

## 项目结构

```
qingning-os/
├── build.sh                    # 主构建脚本
├── config/
│   ├── setup-chroot.sh         # Chroot 环境配置脚本
│   ├── os-release              # 系统标识文件
│   ├── brand/
│   │   └── grub-theme.cfg      # GRUB 主题配置
│   ├── packages/
│   │   └── list.txt            # 软件包列表
│   └── boot/
│       ├── grub.cfg            # GRUB 启动配置
│       └── isolinux.cfg        # ISOLINUX 启动配置
├── scripts/
│   └── post-install.sh         # 首次启动脚本
├── output/                     # 构建输出目录 (ISO)
├── README.md                   # 本文件
└── LICENSE                     # GPL-3.0 许可证
```

## 自定义

### 修改软件包列表

编辑 `config/packages/list.txt`，添加或删除需要的软件包。

### 修改主题

编辑 `config/setup-chroot.sh` 中的 XFCE4 配置部分，更换 GTK 主题和图标主题。

### 修改 GRUB 主题

编辑 `config/brand/grub-theme.cfg`，调整启动菜单的颜色和布局。

## 许可证

本项目基于 [GPL-3.0](LICENSE) 许可证开源。

## 贡献

欢迎提交 Issue 和 Pull Request。

- 项目主页: https://3862242786-sudo.github.io/pan/qingning-os.html
- 问题反馈: https://github.com/3862242786-sudo/qingning-os/issues
