#!/bin/bash
# ============================================================
# QingningOS 首次启动后脚本
# 显示欢迎信息、系统状态和网络配置检查
# ============================================================

# ASCII Art 欢迎信息
clear

echo -e "\033[0;32m"
cat << 'ART'
  ████████╗██╗███╗   ███╗███████╗
  ╚══██╔══╝██║████╗ ████║██╔════╝
     ██║   ██║██╔████╔██║█████╗
     ██║   ██║██║╚██╔╝██║██╔══╝
     ██║   ██║██║ ╚═╝ ██║███████╗
     ╚═╝   ╚═╝╚═╝     ╚═╝╚══════╝
ART
echo -e "\033[0m"

echo -e "\033[0;36m"
echo "  ╔══════════════════════════════════════════════╗"
echo "  ║          QingningOS 1.0.0 (Material)         ║"
echo "  ║    Debian Bookworm + XFCE4 + Material Design  ║"
echo "  ╚══════════════════════════════════════════════╝"
echo -e "\033[0m"
echo ""

# ---------- 系统信息 ----------
echo -e "\033[1;33m  [系统信息]${NC}"
echo -e "\033[0;36m  ────────────────────────────────────────${NC}"
echo "  主机名:     $(hostname)"
echo "  内核版本:   $(uname -r)"
echo "  系统架构:   $(uname -m)"
echo "  运行时间:   $(uptime -p 2>/dev/null || uptime)"
echo "  内存使用:   $(free -h | awk '/Mem:/{print "已用 "$3" / 总计 "$2}')"
echo "  磁盘使用:   $(df -h / | awk 'NR==2{print "已用 "$3" / 总计 "$2" ("$5")"}')"
echo ""

# ---------- 网络状态检查 ----------
echo -e "\033[1;33m  [网络状态]${NC}"
echo -e "\033[0;36m  ────────────────────────────────────────${NC}"

# 检查网络接口
INTERFACES=$(ip -o link show | awk '$2 != "lo:" {print $2}' | tr -d ':')
if [ -n "$INTERFACES" ]; then
    for iface in $INTERFACES; do
        IP_ADDR=$(ip -4 addr show "$iface" 2>/dev/null | grep -oP '(?<=inet\s)\d+(\.\d+){3}' | head -1)
        if [ -n "$IP_ADDR" ]; then
            echo "  $iface: $IP_ADDR (已连接)"
        else
            echo "  $iface: 未获取 IP 地址"
        fi
    done
else
    echo "  未检测到网络接口"
fi

# 检查网络连通性
echo ""
echo -n "  网络连通性测试: "
if ping -c 1 -W 2 223.5.5.5 &>/dev/null; then
    echo -e "\033[0;32m正常${NC}"
else
    echo -e "\033[0;31m无法连接${NC}"
    echo "  提示: 请检查网络设置或连接 Wi-Fi"
fi

# 检查 DNS
echo -n "  DNS 解析测试:   "
if nslookup baidu.com &>/dev/null 2>&1; then
    echo -e "\033[0;32m正常${NC}"
else
    echo -e "\033[0;31m失败${NC}"
fi
echo ""

# ---------- 显示管理器状态 ----------
echo -e "\033[1;33m  [桌面环境]${NC}"
echo -e "\033[0;36m  ────────────────────────────────────────${NC}"
if systemctl is-active --quiet display-manager 2>/dev/null; then
    echo "  桌面环境:   XFCE4"
    echo "  显示管理器: $(systemctl show display-manager -p MainPID --value 2>/dev/null && echo "运行中" || echo "未运行")"
    echo "  主题:       Materia-dark"
    echo "  图标:       Papirus"
else
    echo "  显示管理器: 未运行 (使用 startx 启动)"
fi
echo ""

# ---------- 提示信息 ----------
echo -e "\033[1;33m  [使用提示]${NC}"
echo -e "\033[0;36m  ────────────────────────────────────────${NC}"
echo "  默认用户: qingning / qingning"
echo "  Root 密码: qingning"
echo "  更新系统: sudo apt update && sudo apt upgrade"
echo "  系统监控: htop"
echo "  系统信息: neofetch"
echo ""

echo -e "\033[0;32m  感谢使用 QingningOS!${NC}"
echo -e "\033[0;32m  项目主页: https://github.com/3862242786-sudo/qingning-os${NC}"
echo ""

# 标记已运行完成，避免重复执行
mkdir -p /var/lib/qingning-os
touch /var/lib/qingning-os/welcome-shown
