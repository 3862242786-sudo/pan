# 青柠OS 系统架构

## 概述

QingningOS（青柠OS）是一款基于 Debian Linux 的轻量级桌面操作系统，专为虚拟机环境设计。系统采用 Material Design 视觉风格，提供美观、高效的桌面体验。

## 基础系统

| 组件 | 说明 |
|------|------|
| **基础发行版** | Debian 12 (Bookworm) |
| **内核** | Linux Kernel (Debian 官方稳定内核) |
| **架构** | amd64 (64位) |
| **目标平台** | VMware / VirtualBox 虚拟机 |

## 桌面环境

| 组件 | 说明 |
|------|------|
| **桌面环境** | XFCE4 |
| **显示管理器** | LightDM |
| **窗口管理器** | XFWM4 (XFCE 默认) |
| **面板** | XFCE Panel |

XFCE4 是一款轻量级的桌面环境，具有以下优势：

- 内存占用低，适合虚拟机环境
- 启动速度快，响应敏捷
- 高度可定制，支持插件扩展
- 稳定成熟，社区活跃

## 主题与视觉

QingningOS 采用 Google Material Design 设计语言，通过以下组件实现统一的深色主题视觉风格：

| 组件 | 说明 |
|------|------|
| **GTK3 主题** | Materia (深色变体) |
| **图标主题** | Papirus Icons |
| **自定义样式** | 额外的 GTK3 CSS 覆盖，统一青柠绿 (#22c55e) 强调色 |
| **光标主题** | 默认系统光标 |

主题文件位于 `theme/` 目录，包括：

- `theme/gtk.css` — 自定义 GTK3 样式覆盖
- `theme/xfwm4/` — 窗口装饰主题
- `theme/assets/` — 壁纸、Logo 等资源文件

## Init 系统

| 组件 | 说明 |
|------|------|
| **Init 系统** | systemd |
| **日志系统** | journald |
| **服务管理** | systemctl |

## 软件包管理

| 组件 | 说明 |
|------|------|
| **包管理器** | apt (Advanced Package Tool) |
| **包格式** | .deb |
| **软件源** | Debian Bookworm 官方仓库 |

预装应用列表配置于 `config/packages/list.txt`，默认包含以下常用软件：

- **浏览器**: Firefox ESR
- **办公套件**: LibreOffice
- **媒体播放**: VLC Media Player
- **文本编辑**: Mousepad (XFCE 默认)
- **终端**: XFCE Terminal
- **文件管理**: Thunar (XFCE 默认)
- **图片查看**: Ristretto
- **PDF 阅读器**: Evince
- **压缩工具**: File Roller

## 目录结构

```
qingning-os/
├── build.sh                # 主构建脚本
├── config/
│   ├── packages/
│   │   └── list.txt        # 预装软件包列表
│   └── system/             # 系统配置文件
├── theme/
│   ├── gtk.css             # 自定义 GTK3 样式
│   ├── xfwm4/              # 窗口装饰
│   └── assets/             # 壁纸与资源
├── output/                 # 构建输出目录
│   └── qingning-os-1.0.0-amd64.iso
└── docs/
    ├── BUILD.md            # 构建指南
    └── ARCHITECTURE.md     # 本文档
```

## 构建流程

1. **环境准备** — 安装 debootstrap、squashfs-tools 等构建依赖
2. **Bootstrap** — 使用 debootstrap 创建 Debian 基础系统
3. **系统配置** — 写入 fstab、hostname、网络等配置
4. **软件安装** — 根据 list.txt 安装预装软件包
5. **主题应用** — 复制自定义主题文件到系统目录
6. **ISO 打包** — 使用 xorriso/grub-mkrescue 生成可启动 ISO 镜像
7. **输出** — 将 ISO 文件写入 output/ 目录

## 虚拟机优化

QingningOS 针对虚拟机环境进行了以下优化：

- 禁用不必要的系统服务，减少资源占用
- 预装 VMware Tools / VirtualBox Guest Additions 支持
- 调整内核参数以适配虚拟硬件
- 精简预装软件，仅保留常用应用
- 优化 XFCE 桌面配置，关闭动画效果以提升流畅度

## 许可证

QingningOS 基于开源软件构建，遵循各组件的原始开源许可证发布。
