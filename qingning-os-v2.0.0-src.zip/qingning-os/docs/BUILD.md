# 青柠OS 构建指南

## 系统要求

- Debian 12 (Bookworm) 或 Ubuntu 22.04+ 主机系统
- root 权限
- 至少 10GB 可用磁盘空间
- 稳定的网络连接

## 快速开始

```bash
git clone https://github.com/3862242786-sudo/qingning-os.git
cd qingning-os
chmod +x build.sh
sudo ./build.sh
```

构建完成后，ISO 文件位于 `output/qingning-os-1.0.0-amd64.iso`

## 在虚拟机中安装

1. 打开 VMware / VirtualBox
2. 创建新的虚拟机
3. 选择 "使用ISO镜像"
4. 分配 2GB+ 内存，10GB+ 磁盘
5. 启动虚拟机并按照提示安装

## 自定义

- 主题文件位于 `theme/` 目录
- 预装应用列表位于 `config/packages/list.txt`
- 系统配置位于 `config/` 目录
