#!/bin/bash
# ============================================================
# QingningOS 构建脚本 v1.0.0
# 基于 Debian Bookworm + XFCE4 + Material Design
# 目标平台: VMware / VirtualBox 虚拟机 (UEFI 启动)
# ============================================================
set -euo pipefail

# ---------- 版本与架构 ----------
VERSION="1.0.0"
ARCH="amd64"
DISTRO="bookworm"
MIRROR="https://deb.debian.org/debian"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORKDIR="/tmp/qingning-os-build"
OUTPUT_DIR="${SCRIPT_DIR}/output"
OUTPUT="${OUTPUT_DIR}/qingning-os-${VERSION}-${ARCH}.iso"
DISK_SIZE="4G"

# ---------- 颜色定义 ----------
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

# ---------- 日志函数 ----------
log()   { echo -e "${GREEN}[QingningOS]${NC} $1"; }
info()  { echo -e "${CYAN}[信息]${NC} $1"; }
warn()  { echo -e "${YELLOW}[警告]${NC} $1"; }
error() { echo -e "${RED}[错误]${NC} $1" >&2; }

# ---------- 错误处理 ----------
trap 'error "构建失败! 请检查上方错误信息。"; exit 1' ERR

# ============================================================
# 前置检查
# ============================================================
log "QingningOS ${VERSION} 构建系统"
log "==============================="

if [ "$EUID" -ne 0 ]; then
    error "请使用 root 权限运行此脚本: sudo ./build.sh"
    exit 1
fi

if [ ! -f "${SCRIPT_DIR}/config/setup-chroot.sh" ]; then
    error "找不到 config/setup-chroot.sh，请确认文件完整。"
    exit 1
fi

if [ ! -f "${SCRIPT_DIR}/config/packages/list.txt" ]; then
    error "找不到 config/packages/list.txt，请确认文件完整。"
    exit 1
fi

# ============================================================
# 安装构建依赖
# ============================================================
log "正在安装构建依赖..."
apt-get update -qq
apt-get install -y -qq \
    debootstrap \
    xorriso \
    isolinux \
    grub-pc-bin \
    grub-efi-amd64-bin \
    grub-common \
    squashfs-tools \
    dosfstools \
    mtools \
    memtester \
    2>/dev/null || true

info "构建依赖安装完成。"

# ============================================================
# 准备工作目录
# ============================================================
log "正在准备工作目录..."
if [ -d "${WORKDIR}" ]; then
    warn "工作目录已存在，正在清理..."
    umount "${WORKDIR}/rootfs/dev"  2>/dev/null || true
    umount "${WORKDIR}/rootfs/sys"  2>/dev/null || true
    umount "${WORKDIR}/rootfs/proc" 2>/dev/null || true
    umount "${WORKDIR}/rootfs"      2>/dev/null || true
    rm -rf "${WORKDIR}"
fi

mkdir -p "${WORKDIR}"
mkdir -p "${OUTPUT_DIR}"

# ============================================================
# 创建磁盘镜像
# ============================================================
log "正在创建 ${DISK_SIZE} 磁盘镜像..."
truncate -s ${DISK_SIZE} "${WORKDIR}/qingning-os.img"
mkfs.ext4 -L "QingningOS" -F "${WORKDIR}/qingning-os.img"
mkdir -p "${WORKDIR}/rootfs"
mount -o loop "${WORKDIR}/qingning-os.img" "${WORKDIR}/rootfs"

# ============================================================
# 使用 debootstrap 引导 Debian 系统
# ============================================================
log "正在使用 debootstrap 引导 Debian ${DISTRO} (${ARCH})..."
info "此步骤可能需要较长时间，请耐心等待..."
debootstrap --arch=${ARCH} ${DISTRO} "${WORKDIR}/rootfs" ${MIRROR}

# ============================================================
# 挂载虚拟文件系统并进入 chroot
# ============================================================
log "正在挂载虚拟文件系统..."
mount --bind /proc  "${WORKDIR}/rootfs/proc"
mount --bind /sys   "${WORKDIR}/rootfs/sys"
mount --bind /dev   "${WORKDIR}/rootfs/dev"
mount --bind /dev/pts "${WORKDIR}/rootfs/dev/pts"

# 复制配置文件到 chroot 环境
log "正在复制配置文件..."
cp "${SCRIPT_DIR}/config/setup-chroot.sh"    "${WORKDIR}/rootfs/setup-chroot.sh"
cp "${SCRIPT_DIR}/config/os-release"         "${WORKDIR}/rootfs/etc/os-release"
cp "${SCRIPT_DIR}/config/packages/list.txt"  "${WORKDIR}/rootfs/packages-list.txt"
cp "${SCRIPT_DIR}/scripts/post-install.sh"   "${WORKDIR}/rootfs/usr/local/bin/qingning-post-install.sh"
chmod +x "${WORKDIR}/rootfs/setup-chroot.sh"
chmod +x "${WORKDIR}/rootfs/usr/local/bin/qingning-post-install.sh"

# 复制 GRUB 主题配置
if [ -f "${SCRIPT_DIR}/config/brand/grub-theme.cfg" ]; then
    mkdir -p "${WORKDIR}/rootfs/boot/grub/theme"
    cp "${SCRIPT_DIR}/config/brand/grub-theme.cfg" "${WORKDIR}/rootfs/boot/grub/theme/theme.cfg"
fi

# 复制 GRUB 配置
if [ -f "${SCRIPT_DIR}/config/boot/grub.cfg" ]; then
    cp "${SCRIPT_DIR}/config/boot/grub.cfg" "${WORKDIR}/rootfs/boot/grub/grub.cfg"
fi

# ============================================================
# 执行 chroot 配置
# ============================================================
log "正在进入 chroot 环境进行系统配置..."
info "此步骤将安装所有软件包，可能需要 30 分钟以上..."

chroot "${WORKDIR}/rootfs" /setup-chroot.sh

# ============================================================
# 卸载虚拟文件系统
# ============================================================
log "正在卸载虚拟文件系统..."
umount "${WORKDIR}/rootfs/dev/pts" 2>/dev/null || true
umount "${WORKDIR}/rootfs/dev"     2>/dev/null || true
umount "${WORKDIR}/rootfs/sys"     2>/dev/null || true
umount "${WORKDIR}/rootfs/proc"    2>/dev/null || true
umount "${WORKDIR}/rootfs"         2>/dev/null || true

# ============================================================
# 创建可启动 ISO 镜像
# ============================================================
log "正在创建可启动 ISO 镜像..."
info "正在准备 EFI 引导文件..."

ISO_DIR="${WORKDIR}/iso"
mkdir -p "${ISO_DIR}"

# 重新挂载磁盘镜像以复制文件
mount -o loop,ro "${WORKDIR}/qingning-os.img" "${WORKDIR}/rootfs"

# 创建 ISO 目录结构
mkdir -p "${ISO_DIR}/boot/grub"
mkdir -p "${ISO_DIR}/boot/grub/efi"
mkdir -p "${ISO_DIR}/EFI/BOOT"

# 复制内核和 initramfs
if [ -f "${WORKDIR}/rootfs/boot/vmlinuz-"* ]; then
    cp "${WORKDIR}/rootfs}/boot/vmlinuz-"* "${ISO_DIR}/boot/vmlinuz" 2>/dev/null || \
    cp "${WORKDIR}/rootfs}/boot/vmlinuz"   "${ISO_DIR}/boot/vmlinuz" 2>/dev/null || true
fi

if [ -f "${WORKDIR}/rootfs}/boot/initrd.img-"* ]; then
    cp "${WORKDIR}/rootfs}/boot/initrd.img-"* "${ISO_DIR}/boot/initrd.img" 2>/dev/null || \
    cp "${WORKDIR}/rootfs}/boot/initrd.img"   "${ISO_DIR}/boot/initrd.img" 2>/dev/null || true
fi

# 复制 GRUB EFI 模块
GRUB_DIR="/usr/lib/grub"
if [ -d "${GRUB_DIR}/x86_64-efi" ]; then
    cp -r "${GRUB_DIR}/x86_64-efi" "${ISO_DIR}/boot/grub/x86_64-efi"
fi

# 创建 EFI 启动镜像
if command -v grub-mkstandalone &>/dev/null; then
    log "正在生成 EFI 启动镜像..."
    grub-mkstandalone \
        --format=x86_64-efi \
        --output="${ISO_DIR}/EFI/BOOT/BOOTX64.EFI" \
        --locales="" \
        --fonts="" \
        "boot/grub/grub.cfg=${SCRIPT_DIR}/config/boot/grub-efi.cfg"
fi

# 复制 ISOLINUX 文件 (BIOS 兼容)
if [ -d "/usr/lib/ISOLINUX" ]; then
    mkdir -p "${ISO_DIR}/isolinux"
    cp /usr/lib/ISOLINUX/isolinux.bin "${ISO_DIR}/isolinux/"
    cp /usr/lib/syslinux/modules/bios/ldlinux.c32 "${ISO_DIR}/isolinux/"
    cp "${SCRIPT_DIR}/config/boot/isolinux.cfg" "${ISO_DIR}/isolinux/isolinux.cfg"
fi

# 复制 GRUB 配置到 ISO
cp "${SCRIPT_DIR}/config/boot/grub.cfg" "${ISO_DIR}/boot/grub/grub.cfg" 2>/dev/null || true

# 复制 GRUB 主题到 ISO
if [ -f "${SCRIPT_DIR}/config/brand/grub-theme.cfg" ]; then
    mkdir -p "${ISO_DIR}/boot/grub/theme"
    cp "${SCRIPT_DIR}/config/brand/grub-theme.cfg" "${ISO_DIR}/boot/grub/theme/theme.cfg"
fi

# 卸载
umount "${WORKDIR}/rootfs"

# ============================================================
# 使用 xorriso 生成 ISO
# ============================================================
log "正在使用 xorriso 生成 ISO 镜像..."
info "输出文件: ${OUTPUT}"

xorriso -as mkisofs \
    -r \
    -V "QingningOS ${VERSION}" \
    -partition_offset 16 \
    -append_partition 2 C12A7328-F81F-11D2-BA4B-00A0C93EC93B \
        "${ISO_DIR}/EFI/BOOT/BOOTX64.EFI" \
    -appended_part_as_gpt \
    -iso_mbr_part_type 0x00 \
    -c "/boot/grub/boot.cat" \
    -b "/boot/grub/bios.img" \
    -no-emul-boot \
    -boot-load-size 4 \
    -boot-info-table \
    --efi-boot boot \
    --efi-boot-part --protective-msdos-label \
    -o "${OUTPUT}" \
    "${ISO_DIR}" \
    2>/dev/null || {

    # 备用方案: 简单 ISO 生成
    warn "高级 ISO 生成失败，尝试备用方案..."
    xorriso -as mkisofs \
        -r \
        -V "QingningOS ${VERSION}" \
        -o "${OUTPUT}" \
        "${ISO_DIR}"
}

# ============================================================
# 清理工作目录
# ============================================================
log "正在清理临时文件..."
rm -rf "${WORKDIR}"

# ============================================================
# 构建完成
# ============================================================
log "==============================="
log "QingningOS ${VERSION} 构建完成!"
log "==============================="
info "ISO 镜像位置: ${OUTPUT}"
info "文件大小: $(du -h "${OUTPUT}" | cut -f1)"
echo ""
info "使用方法:"
echo "  1. 在 VMware 中: 文件 -> 打开虚拟机 -> 选择 ISO 文件"
echo "  2. 在 VirtualBox 中: 新建虚拟机 -> 使用 ISO 作为光驱"
echo "  3. 默认用户: qingning / qingning"
echo "  4. 默认密码: root / qingning"
echo ""
log "感谢使用 QingningOS!"
